# General information
This task is adopted from (Lin et al., 2021) DOI: 10.1038/s41467-021-25500-y
*Author*: Shangcheng Zhao. *Date*: 03/2024

## condition
| session_serial | slider_judge_img |
|:----------------:|------------------|
| 0 | critical.png|
| 1 | competent.png|
| 2 | strong.png|
| 3 | youthful.png|