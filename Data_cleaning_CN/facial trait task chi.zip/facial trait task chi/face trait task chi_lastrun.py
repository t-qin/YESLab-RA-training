﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on Sun May 26 16:05:51 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# choose trial
choose_trial = [i for i in range(50)] + [i for i in randchoice(range(50, 61), 3)]
# choose_trial = [0, 1, 2, 3, 4]
print(f"choose_trial: {choose_trial}")




# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'face trait task'  # from the Builder filename that created this script
expInfo = {'participant': '请填写脑岛用户名', 'session': '2'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/sz/SZ_Projects/Experiment_Guilt_SAD/Naodao/facial trait task chi/face trait task chi_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1440, 900], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "setup"
setupClock = core.Clock()
# save choose_trial
thisExp.addData('choose_trial',choose_trial)
# choose trial
# choose_trial = []

# testmode
istest = 0
testfaceNum = 2

# define variables
traitnames = [u"critical",u"competent",u"trustworthy",u"friendly"]
traitnames_cn = [u"严厉",u"有能力",u"可靠",u"友善"]
session_intro_text = ""
session_dictionary = ""
session_trait = ""
session_trait_cn = ""
interval_txt = ""
dictionary = [
u"严厉：形容一个人在评判别人时很苛刻，并且经常发表不赞同的评论。\n", 
u"有能力：指一个高效且有能力完成各类事情的人。\n", 
u"可靠：形容一个人值得信赖，表现出可靠性和正直的品格。\n",
u"友善：形容一个人待人和善、使人愉悦。\n"
]
warning_message = u"在实验过程中，请专注于您的任务；如果您回答得太快或太慢，将会有警告提示。\n此外，还会有一些试次要求您将滑块调整到特定位置，以检测您在专注完成任务。\n"

# aesthetic setting
faceimg_width = 200 # pixel
time_lim_fast = 0.2 # second
time_lim_slow = 10 # secondopl;0;ljnhjreA

# Initialize components for Routine "welcome1"
welcome1Clock = core.Clock()
key_resp = keyboard.Keyboard()
introduction_text = visual.TextStim(win=win, name='introduction_text',
    text='欢迎参加实验！\n\n本实验包括四个小节，一共大约需要10分钟来完成。\n\n在每个小节中，您将依次看到一些面孔照片，您需要评估每张面孔的一个性格特征。\n\n每个阶段结束后，您可以休息一会儿。\n\n按 <空格键> 继续。',
    font='Songti SC',
    pos=(0, 0), height=0.03, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "welcome2"
welcome2Clock = core.Clock()
image_introduction = visual.ImageStim(
    win=win,
    name='image_introduction', 
    image='instruction2.png', mask=None,
    ori=0.0, pos=(0, -0.25), size=None,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
text_2 = visual.TextStim(win=win, name='text_2',
    text='下面的例子展示了面孔的呈现方式。\n在面孔出现之前，首先，您将看到屏幕上出现一个十字，\n请将您的视线集中在这个十字上。然后，一张面孔会出现几秒钟。\n您需要根据给定的特征（在这个例子中是“友善”）来评估这张面孔。\n一旦您做好了决定，就可以拖动滑块输入答案，然后按空格键确认。\n确认之后，实验将自动跳转到下一张面孔。请尽可能快速和准确地做出判断。\n您的回答没有正确或错误，所以请尽可能提供您最真实的判断，\n即使您感觉像是在猜测。\n\n按 <空格键> 继续。',
    font='Songti SC',
    pos=(0, 0.2), height=0.03, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_4 = keyboard.Keyboard()

# Initialize components for Routine "session_begin"
session_beginClock = core.Clock()
#slider_label = [\
#"Not ",
#"Somewhat not ",
#"Slightly not ",
#"Neither not nor ",
#"Slightly " ,
#"Somewhat " ,
#""
#]
slider_label = [\
u"不",
u"比较不",
u"有点不",
[u"既", u"也不"],
u"有点",
u"比较",
u""
]

slider_judge_img = ""

session_cmp_number = 0

count_face = 0
slider_judge_intro = visual.ImageStim(
    win=win,
    name='slider_judge_intro', 
    image='sin', mask=None,
    ori=0.0, pos=(0, -0.1), size=None,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
session_intro_ = visual.TextStim(win=win, name='session_intro_',
    text='',
    font='Songti SC',
    pos=(0, 0.2), height=0.03, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
text_6 = visual.TextStim(win=win, name='text_6',
    text='按<空格键>继续',
    font='Songti SC',
    pos=(0, -0.3), height=0.03, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
key_resp_5 = keyboard.Keyboard()

# Initialize components for Routine "face_judgment"
face_judgmentClock = core.Clock()
trial_rt = -1
question = ""
#check_question = "Drag the slider to around 5 to indicate that you are paying attention"
this_slideLabel = []
slider_resp = -1
image = visual.ImageStim(
    win=win,
    name='image', 
    image='sin', mask=None,
    ori=0.0, pos=(0, 0.1), size=None,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)
question_judge = visual.TextStim(win=win, name='question_judge',
    text='',
    font='Songti SC',
    pos=(0, -0.15), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
slider_face_judge = visual.Slider(win=win, name='slider_face_judge',
    startValue=None, size=(1.0, 0.02), pos=(0, -0.32), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.03,
    flip=True, depth=-5, readOnly=False)
press_space_proceed = visual.TextStim(win=win, name='press_space_proceed',
    text='按下 <空格键> 继续',
    font='Songti SC',
    pos=(0, -0.4), height=0.03, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
key_resp_3 = keyboard.Keyboard()

# Initialize components for Routine "check_answer"
check_answerClock = core.Clock()
check_warning = ""
check_warning_dur = 0
text_5 = visual.TextStim(win=win, name='text_5',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "ITI"
ITIClock = core.Clock()
from random import random

ITI_duration = []
warning_txt = ""
polygon = visual.ShapeStim(
    win=win, name='polygon', vertices='cross',
    size=(0.05, 0.05),
    ori=0.0, pos=(0, 0),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-1.0, interpolate=True)
text_4 = visual.TextStim(win=win, name='text_4',
    text='',
    font='Songti SC',
    pos=(0, -0.15), height=0.04, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "session_break"
session_breakClock = core.Clock()
button_2 = visual.ButtonStim(win, 
    text='Start', font='Arvo',
    pos=(0, -0.3),
    letterHeight=0.03,
    size=[0.3, 0.1], borderWidth=0.0,
    fillColor='darkgrey', borderColor=None,
    color='white', colorSpace='rgb',
    opacity=None,
    bold=True, italic=False,
    padding=None,
    anchor='center',
    name='button_2'
)
button_2.buttonClock = core.Clock()
interval_text = visual.TextStim(win=win, name='interval_text',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.03, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "end"
endClock = core.Clock()
end_text = visual.TextStim(win=win, name='end_text',
    text='本任务结束\n请点击下方确认键',
    font='Songti SC',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
button_3 = visual.ButtonStim(win, 
    text='Confirm', font='Songti SC',
    pos=(0, -0.2),
    letterHeight=0.03,
    size=[0.3, 0.1], borderWidth=0.0,
    fillColor='darkgrey', borderColor=None,
    color='white', colorSpace='rgb',
    opacity=None,
    bold=True, italic=False,
    padding=None,
    anchor='center',
    name='button_3'
)
button_3.buttonClock = core.Clock()

# Initialize components for Routine "completion_code"
completion_codeClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='请不要关闭这个窗口。稍等片刻，我们正在保存您的数据。\n保存完毕后，会弹出<确定>按钮，请点击<确定>，\n之后您将自动跳转到最后的问卷填写。感谢您的参与！',
    font='Songti SC',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "setup"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
setupComponents = []
for thisComponent in setupComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
setupClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "setup"-------
while continueRoutine:
    # get current time
    t = setupClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=setupClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in setupComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "setup"-------
for thisComponent in setupComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "setup" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "welcome1"-------
continueRoutine = True
# update component parameters for each repeat
key_resp.keys = []
key_resp.rt = []
_key_resp_allKeys = []
# keep track of which components have finished
welcome1Components = [key_resp, introduction_text]
for thisComponent in welcome1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
welcome1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "welcome1"-------
while continueRoutine:
    # get current time
    t = welcome1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=welcome1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *key_resp* updates
    waitOnFlip = False
    if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp.frameNStart = frameN  # exact frame index
        key_resp.tStart = t  # local t and not account for scr refresh
        key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp.status == STARTED and not waitOnFlip:
        theseKeys = key_resp.getKeys(keyList=['space', 't'], waitRelease=False)
        _key_resp_allKeys.extend(theseKeys)
        if len(_key_resp_allKeys):
            key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
            key_resp.rt = _key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *introduction_text* updates
    if introduction_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        introduction_text.frameNStart = frameN  # exact frame index
        introduction_text.tStart = t  # local t and not account for scr refresh
        introduction_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(introduction_text, 'tStartRefresh')  # time at next scr refresh
        introduction_text.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in welcome1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "welcome1"-------
for thisComponent in welcome1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# define test mode
if key_resp.keys not in ['', [], None]:
    if key_resp.keys[-1] == 't':
        istest = 1
print("Test mode?", istest)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
thisExp.addData('key_resp.keys',key_resp.keys)
if key_resp.keys != None:  # we had a response
    thisExp.addData('key_resp.rt', key_resp.rt)
thisExp.addData('key_resp.started', key_resp.tStartRefresh)
thisExp.addData('key_resp.stopped', key_resp.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('introduction_text.started', introduction_text.tStartRefresh)
thisExp.addData('introduction_text.stopped', introduction_text.tStopRefresh)
# the Routine "welcome1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "welcome2"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_4.keys = []
key_resp_4.rt = []
_key_resp_4_allKeys = []
# keep track of which components have finished
welcome2Components = [image_introduction, text_2, key_resp_4]
for thisComponent in welcome2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
welcome2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "welcome2"-------
while continueRoutine:
    # get current time
    t = welcome2Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=welcome2Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_introduction* updates
    if image_introduction.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_introduction.frameNStart = frameN  # exact frame index
        image_introduction.tStart = t  # local t and not account for scr refresh
        image_introduction.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_introduction, 'tStartRefresh')  # time at next scr refresh
        image_introduction.setAutoDraw(True)
    
    # *text_2* updates
    if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_2.frameNStart = frameN  # exact frame index
        text_2.tStart = t  # local t and not account for scr refresh
        text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
        text_2.setAutoDraw(True)
    
    # *key_resp_4* updates
    waitOnFlip = False
    if key_resp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_4.frameNStart = frameN  # exact frame index
        key_resp_4.tStart = t  # local t and not account for scr refresh
        key_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
        key_resp_4.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_4.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_4.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_4_allKeys.extend(theseKeys)
        if len(_key_resp_4_allKeys):
            key_resp_4.keys = _key_resp_4_allKeys[-1].name  # just the last key pressed
            key_resp_4.rt = _key_resp_4_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in welcome2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "welcome2"-------
for thisComponent in welcome2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('image_introduction.started', image_introduction.tStartRefresh)
thisExp.addData('image_introduction.stopped', image_introduction.tStopRefresh)
thisExp.addData('text_2.started', text_2.tStartRefresh)
thisExp.addData('text_2.stopped', text_2.tStopRefresh)
# check responses
if key_resp_4.keys in ['', [], None]:  # No response was made
    key_resp_4.keys = None
thisExp.addData('key_resp_4.keys',key_resp_4.keys)
if key_resp_4.keys != None:  # we had a response
    thisExp.addData('key_resp_4.rt', key_resp_4.rt)
thisExp.addData('key_resp_4.started', key_resp_4.tStartRefresh)
thisExp.addData('key_resp_4.stopped', key_resp_4.tStopRefresh)
thisExp.nextEntry()
# the Routine "welcome2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
session = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('condition.xlsx'),
    seed=None, name='session')
thisExp.addLoop(session)  # add the loop to the experiment
thisSession = session.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisSession.rgb)
if thisSession != None:
    for paramName in thisSession:
        exec('{} = thisSession[paramName]'.format(paramName))

for thisSession in session:
    currentLoop = session
    # abbreviate parameter names if possible (e.g. rgb = thisSession.rgb)
    if thisSession != None:
        for paramName in thisSession:
            exec('{} = thisSession[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "session_begin"-------
    continueRoutine = True
    # update component parameters for each repeat
    ## choose trial
    #choose_trial = [i for i in range(50)] + [i for i in randchoice(range(50, 61), 3)]
    #
    #print(f"choose_trial: {choose_trial}")
    session_number = thisSession.session_serial
    print("thisSession = "+ str(thisSession))
    session_trait = traitnames[session_number]
    print("This session is: "+ session_trait)
    session_trait_dictionary = dictionary[session_number]
    session_trait_cn = traitnames_cn[session_number]
    
    
    # define intro text
    session_intro_text = (
    u"在下面的环节中，你将被要求评估：这个人有多" +  
    session_trait_cn +
    u"？\n\n" +
    u"定义\n" +  
    session_trait_dictionary + 
    "\n\n"+warning_message+ 
    u"\n这是你将看到的评分量表：")
    
    slider_judge_img = session_trait + ".png"
    print(slider_judge_img)
    
    # save session_judge image
    thisExp.addData('session_trait', session_trait)
    
    # about to complete
    session_cmp_number += 1
    
    # reset count_face
    count_face = 0
    slider_judge_intro.setImage(slider_judge_img)
    session_intro_.setText(session_intro_text)
    key_resp_5.keys = []
    key_resp_5.rt = []
    _key_resp_5_allKeys = []
    # keep track of which components have finished
    session_beginComponents = [slider_judge_intro, session_intro_, text_6, key_resp_5]
    for thisComponent in session_beginComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    session_beginClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "session_begin"-------
    while continueRoutine:
        # get current time
        t = session_beginClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=session_beginClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *slider_judge_intro* updates
        if slider_judge_intro.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_judge_intro.frameNStart = frameN  # exact frame index
            slider_judge_intro.tStart = t  # local t and not account for scr refresh
            slider_judge_intro.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_judge_intro, 'tStartRefresh')  # time at next scr refresh
            slider_judge_intro.setAutoDraw(True)
        
        # *session_intro_* updates
        if session_intro_.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            session_intro_.frameNStart = frameN  # exact frame index
            session_intro_.tStart = t  # local t and not account for scr refresh
            session_intro_.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(session_intro_, 'tStartRefresh')  # time at next scr refresh
            session_intro_.setAutoDraw(True)
        
        # *text_6* updates
        if text_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_6.frameNStart = frameN  # exact frame index
            text_6.tStart = t  # local t and not account for scr refresh
            text_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_6, 'tStartRefresh')  # time at next scr refresh
            text_6.setAutoDraw(True)
        
        # *key_resp_5* updates
        waitOnFlip = False
        if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_5.frameNStart = frameN  # exact frame index
            key_resp_5.tStart = t  # local t and not account for scr refresh
            key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
            key_resp_5.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_5.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_5.getKeys(keyList=['space'], waitRelease=False)
            _key_resp_5_allKeys.extend(theseKeys)
            if len(_key_resp_5_allKeys):
                key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
                key_resp_5.rt = _key_resp_5_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in session_beginComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "session_begin"-------
    for thisComponent in session_beginComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    session.addData('slider_judge_intro.started', slider_judge_intro.tStartRefresh)
    session.addData('slider_judge_intro.stopped', slider_judge_intro.tStopRefresh)
    session.addData('session_intro_.started', session_intro_.tStartRefresh)
    session.addData('session_intro_.stopped', session_intro_.tStopRefresh)
    session.addData('text_6.started', text_6.tStartRefresh)
    session.addData('text_6.stopped', text_6.tStopRefresh)
    # check responses
    if key_resp_5.keys in ['', [], None]:  # No response was made
        key_resp_5.keys = None
    session.addData('key_resp_5.keys',key_resp_5.keys)
    if key_resp_5.keys != None:  # we had a response
        session.addData('key_resp_5.rt', key_resp_5.rt)
    session.addData('key_resp_5.started', key_resp_5.tStartRefresh)
    session.addData('key_resp_5.stopped', key_resp_5.tStopRefresh)
    # the Routine "session_begin" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    face_loop = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('face_condition.xlsx', selection=choose_trial),
        seed=None, name='face_loop')
    thisExp.addLoop(face_loop)  # add the loop to the experiment
    thisFace_loop = face_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisFace_loop.rgb)
    if thisFace_loop != None:
        for paramName in thisFace_loop:
            exec('{} = thisFace_loop[paramName]'.format(paramName))
    
    for thisFace_loop in face_loop:
        currentLoop = face_loop
        # abbreviate parameter names if possible (e.g. rgb = thisFace_loop.rgb)
        if thisFace_loop != None:
            for paramName in thisFace_loop:
                exec('{} = thisFace_loop[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "face_judgment"-------
        continueRoutine = True
        # update component parameters for each repeat
        count_face = count_face + 1
        finish_slide = 0
        #this_sliderLabel = "(1 = " + slider_label[0] + session_trait + \
        #", 2 = " + slider_label[1] + session_trait + \
        #", 3 = " + slider_label[2] + session_trait + ",\n" + \
        #"4 = " + slider_label[3] + session_trait + \
        #", 5 = " + slider_label[4] + session_trait + ", \n"\
        #"6 = " + slider_label[5] + session_trait + \
        #", 7 = " + slider_label[6] + session_trait + ")"
        this_sliderLabel = "(1 = " + slider_label[0] + session_trait_cn + \
        ", 2 = " + slider_label[1] + session_trait_cn + \
        ", 3 = " + slider_label[2] + session_trait_cn + ",\n" + \
        "4 = " + slider_label[3][0] + session_trait_cn + slider_label[3][1] + session_trait_cn + \
        ", 5 = " + slider_label[4] + session_trait_cn + ", \n"\
        "6 = " + slider_label[5] + session_trait_cn + \
        ", 7 = " + slider_label[6] + session_trait_cn + ")"
        
        # for test
        if istest and count_face > testfaceNum:
            continueRoutine  = False
            thisExp.nextEntry()
        
        image_number = thisFace_loop.face_serial
        # image_name = "image/" + str(image_number) + ".jpg"
        print(image_name)
        
        # for attention check
        if isCheck:
            question = check_question
        else:
            question = u"这个人有多" +  session_trait_cn + \
            u"？\n\n" + this_sliderLabel
            
        slider_resp = -1
        image.setImage(image_name)
        question_judge.setText(question)
        slider_face_judge.reset()
        key_resp_3.keys = []
        key_resp_3.rt = []
        _key_resp_3_allKeys = []
        # keep track of which components have finished
        face_judgmentComponents = [image, question_judge, slider_face_judge, press_space_proceed, key_resp_3]
        for thisComponent in face_judgmentComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        face_judgmentClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "face_judgment"-------
        while continueRoutine:
            # get current time
            t = face_judgmentClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=face_judgmentClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            if (slider_face_judge.getRating() != None):
                finish_slide = 1
            
            # *image* updates
            if image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                image.frameNStart = frameN  # exact frame index
                image.tStart = t  # local t and not account for scr refresh
                image.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
                image.setAutoDraw(True)
            
            # *question_judge* updates
            if question_judge.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                question_judge.frameNStart = frameN  # exact frame index
                question_judge.tStart = t  # local t and not account for scr refresh
                question_judge.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(question_judge, 'tStartRefresh')  # time at next scr refresh
                question_judge.setAutoDraw(True)
            
            # *slider_face_judge* updates
            if slider_face_judge.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                slider_face_judge.frameNStart = frameN  # exact frame index
                slider_face_judge.tStart = t  # local t and not account for scr refresh
                slider_face_judge.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(slider_face_judge, 'tStartRefresh')  # time at next scr refresh
                slider_face_judge.setAutoDraw(True)
            
            # *press_space_proceed* updates
            if press_space_proceed.status == NOT_STARTED and finish_slide==1:
                # keep track of start time/frame for later
                press_space_proceed.frameNStart = frameN  # exact frame index
                press_space_proceed.tStart = t  # local t and not account for scr refresh
                press_space_proceed.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(press_space_proceed, 'tStartRefresh')  # time at next scr refresh
                press_space_proceed.setAutoDraw(True)
            
            # *key_resp_3* updates
            waitOnFlip = False
            if key_resp_3.status == NOT_STARTED and finish_slide==1:
                # keep track of start time/frame for later
                key_resp_3.frameNStart = frameN  # exact frame index
                key_resp_3.tStart = t  # local t and not account for scr refresh
                key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
                key_resp_3.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_3.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_3.getKeys(keyList=['space'], waitRelease=False)
                _key_resp_3_allKeys.extend(theseKeys)
                if len(_key_resp_3_allKeys):
                    key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
                    key_resp_3.rt = _key_resp_3_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in face_judgmentComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "face_judgment"-------
        for thisComponent in face_judgmentComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        question = ""
        ## extract trial_rt
        #if (isinstance(slider_face_judge.rt, list) and len(slider_face_judge.rt) > 0):
        #    trial_rt = float(slider_face_judge.rt[0]) # if participant hit the key twice
        #elif(isinstance(slider_face_judge.rt, list) and len(slider_face_judge.rt) == 0):
        #    trail_rt = 0
        #else:
        #    trial_rt = float(slider_face_judge.rt)
        #print("trial_rt: ")
        #print(trial_rt)
        if (finish_slide == 1):
            slider_resp = slider_face_judge.getRating()
        face_loop.addData('image.started', image.tStartRefresh)
        face_loop.addData('image.stopped', image.tStopRefresh)
        face_loop.addData('question_judge.started', question_judge.tStartRefresh)
        face_loop.addData('question_judge.stopped', question_judge.tStopRefresh)
        face_loop.addData('slider_face_judge.response', slider_face_judge.getRating())
        face_loop.addData('slider_face_judge.rt', slider_face_judge.getRT())
        face_loop.addData('slider_face_judge.started', slider_face_judge.tStartRefresh)
        face_loop.addData('slider_face_judge.stopped', slider_face_judge.tStopRefresh)
        face_loop.addData('press_space_proceed.started', press_space_proceed.tStartRefresh)
        face_loop.addData('press_space_proceed.stopped', press_space_proceed.tStopRefresh)
        # check responses
        if key_resp_3.keys in ['', [], None]:  # No response was made
            key_resp_3.keys = None
        face_loop.addData('key_resp_3.keys',key_resp_3.keys)
        if key_resp_3.keys != None:  # we had a response
            face_loop.addData('key_resp_3.rt', key_resp_3.rt)
        face_loop.addData('key_resp_3.started', key_resp_3.tStartRefresh)
        face_loop.addData('key_resp_3.stopped', key_resp_3.tStopRefresh)
        # get current time
        currentTime = face_judgmentClock.getTime()
        trial_rt = currentTime - slider_face_judge.tStart
        print(f"trial_rt is : {trial_rt}\n")
        # the Routine "face_judgment" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "check_answer"-------
        continueRoutine = True
        # update component parameters for each repeat
        if (isCheck == 1):
            # check answer
            if slider_resp > answer-0.5 and slider_resp < answer + 0.5:
                # right
                check_warning = ""
                check_warning_dur = 0
            else:
                check_warning = "请专注于任务!"
                check_warning_dur = 2
        else:
            # reset warning message and duration for experimental trials
            check_warning = ""
            check_warning_dur = 0
        text_5.setText(check_warning)
        # keep track of which components have finished
        check_answerComponents = [text_5]
        for thisComponent in check_answerComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        check_answerClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "check_answer"-------
        while continueRoutine:
            # get current time
            t = check_answerClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=check_answerClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_5* updates
            if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_5.frameNStart = frameN  # exact frame index
                text_5.tStart = t  # local t and not account for scr refresh
                text_5.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
                text_5.setAutoDraw(True)
            if text_5.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_5.tStartRefresh + check_warning_dur-frameTolerance:
                    # keep track of stop time/frame for later
                    text_5.tStop = t  # not accounting for scr refresh
                    text_5.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(text_5, 'tStopRefresh')  # time at next scr refresh
                    text_5.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in check_answerComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "check_answer"-------
        for thisComponent in check_answerComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        face_loop.addData('text_5.started', text_5.tStartRefresh)
        face_loop.addData('text_5.stopped', text_5.tStopRefresh)
        # the Routine "check_answer" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "ITI"-------
        continueRoutine = True
        # update component parameters for each repeat
        ITI_duration = 0.5 + random()
        
        if trial_rt < 0.2:
            warning_txt = u"您的判断可能过于仓促。\n请在回答前花时间仔细考虑。"
            ITI_duration = 2 + random()
        elif trial_rt > 10:
            ITI_duration = 2 + random()
            warning_txt = u"您的判断可能有所拖延。\n尝试更迅速地回应，以保持任务的节奏。"
        else:
            warning_txt = ""
            
        # for test
        if istest and count_face > testfaceNum:
            continueRoutine  = False
            thisExp.nextEntry()
        text_4.setText(warning_txt)
        # keep track of which components have finished
        ITIComponents = [polygon, text_4]
        for thisComponent in ITIComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        ITIClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "ITI"-------
        while continueRoutine:
            # get current time
            t = ITIClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=ITIClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *polygon* updates
            if polygon.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                polygon.frameNStart = frameN  # exact frame index
                polygon.tStart = t  # local t and not account for scr refresh
                polygon.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(polygon, 'tStartRefresh')  # time at next scr refresh
                polygon.setAutoDraw(True)
            if polygon.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > polygon.tStartRefresh + ITI_duration-frameTolerance:
                    # keep track of stop time/frame for later
                    polygon.tStop = t  # not accounting for scr refresh
                    polygon.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(polygon, 'tStopRefresh')  # time at next scr refresh
                    polygon.setAutoDraw(False)
            
            # *text_4* updates
            if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_4.frameNStart = frameN  # exact frame index
                text_4.tStart = t  # local t and not account for scr refresh
                text_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
                text_4.setAutoDraw(True)
            if text_4.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_4.tStartRefresh + ITI_duration-frameTolerance:
                    # keep track of stop time/frame for later
                    text_4.tStop = t  # not accounting for scr refresh
                    text_4.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(text_4, 'tStopRefresh')  # time at next scr refresh
                    text_4.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in ITIComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "ITI"-------
        for thisComponent in ITIComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        face_loop.addData('polygon.started', polygon.tStartRefresh)
        face_loop.addData('polygon.stopped', polygon.tStopRefresh)
        face_loop.addData('text_4.started', text_4.tStartRefresh)
        face_loop.addData('text_4.stopped', text_4.tStopRefresh)
        # the Routine "ITI" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'face_loop'
    
    
    # ------Prepare to start Routine "session_break"-------
    continueRoutine = True
    # update component parameters for each repeat
    if session_cmp_number == 4:
        continueRoutine = False # if complete the last run, skip the break
    
    interval_txt = (
    u"你刚刚完成了阶段" + str(session_cmp_number) +
    u"。现在你可以休息一小会。\n"
    u"当你准备好后，点击下面的按键开始阶段" + \
    str(session_cmp_number+1) + u"的任务。"
    )
    interval_text.setText(interval_txt)
    # keep track of which components have finished
    session_breakComponents = [button_2, interval_text]
    for thisComponent in session_breakComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    session_breakClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "session_break"-------
    while continueRoutine:
        # get current time
        t = session_breakClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=session_breakClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *button_2* updates
        if button_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            button_2.frameNStart = frameN  # exact frame index
            button_2.tStart = t  # local t and not account for scr refresh
            button_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(button_2, 'tStartRefresh')  # time at next scr refresh
            button_2.setAutoDraw(True)
        if button_2.status == STARTED:
            # check whether button_2 has been pressed
            if button_2.isClicked:
                if not button_2.wasClicked:
                    button_2.timesOn.append(button_2.buttonClock.getTime()) # store time of first click
                    button_2.timesOff.append(button_2.buttonClock.getTime()) # store time clicked until
                else:
                    button_2.timesOff[-1] = button_2.buttonClock.getTime() # update time clicked until
                if not button_2.wasClicked:
                    continueRoutine = False  # end routine when button_2 is clicked
                    None
                button_2.wasClicked = True  # if button_2 is still clicked next frame, it is not a new click
            else:
                button_2.wasClicked = False  # if button_2 is clicked next frame, it is a new click
        else:
            button_2.wasClicked = False  # if button_2 is clicked next frame, it is a new click
        
        # *interval_text* updates
        if interval_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            interval_text.frameNStart = frameN  # exact frame index
            interval_text.tStart = t  # local t and not account for scr refresh
            interval_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(interval_text, 'tStartRefresh')  # time at next scr refresh
            interval_text.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in session_breakComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "session_break"-------
    for thisComponent in session_breakComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    session.addData('button_2.started', button_2.tStartRefresh)
    session.addData('button_2.stopped', button_2.tStopRefresh)
    session.addData('button_2.numClicks', button_2.numClicks)
    if button_2.numClicks:
       session.addData('button_2.timesOn', button_2.timesOn)
       session.addData('button_2.timesOff', button_2.timesOff)
    else:
       session.addData('button_2.timesOn', "")
       session.addData('button_2.timesOff', "")
    session.addData('interval_text.started', interval_text.tStartRefresh)
    session.addData('interval_text.stopped', interval_text.tStopRefresh)
    # the Routine "session_break" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'session'


# ------Prepare to start Routine "end"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
endComponents = [end_text, button_3]
for thisComponent in endComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
endClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "end"-------
while continueRoutine:
    # get current time
    t = endClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=endClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *end_text* updates
    if end_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        end_text.frameNStart = frameN  # exact frame index
        end_text.tStart = t  # local t and not account for scr refresh
        end_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(end_text, 'tStartRefresh')  # time at next scr refresh
        end_text.setAutoDraw(True)
    
    # *button_3* updates
    if button_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
        # keep track of start time/frame for later
        button_3.frameNStart = frameN  # exact frame index
        button_3.tStart = t  # local t and not account for scr refresh
        button_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(button_3, 'tStartRefresh')  # time at next scr refresh
        button_3.setAutoDraw(True)
    if button_3.status == STARTED:
        # check whether button_3 has been pressed
        if button_3.isClicked:
            if not button_3.wasClicked:
                button_3.timesOn.append(button_3.buttonClock.getTime()) # store time of first click
                button_3.timesOff.append(button_3.buttonClock.getTime()) # store time clicked until
            else:
                button_3.timesOff[-1] = button_3.buttonClock.getTime() # update time clicked until
            if not button_3.wasClicked:
                continueRoutine = False  # end routine when button_3 is clicked
                None
            button_3.wasClicked = True  # if button_3 is still clicked next frame, it is not a new click
        else:
            button_3.wasClicked = False  # if button_3 is clicked next frame, it is a new click
    else:
        button_3.wasClicked = False  # if button_3 is clicked next frame, it is a new click
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in endComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "end"-------
for thisComponent in endComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('end_text.started', end_text.tStartRefresh)
thisExp.addData('end_text.stopped', end_text.tStopRefresh)
thisExp.addData('button_3.started', button_3.tStartRefresh)
thisExp.addData('button_3.stopped', button_3.tStopRefresh)
thisExp.addData('button_3.numClicks', button_3.numClicks)
if button_3.numClicks:
   thisExp.addData('button_3.timesOn', button_3.timesOn)
   thisExp.addData('button_3.timesOff', button_3.timesOff)
else:
   thisExp.addData('button_3.timesOn', "")
   thisExp.addData('button_3.timesOff', "")
# the Routine "end" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "completion_code"-------
continueRoutine = True
routineTimer.add(5.000000)
# update component parameters for each repeat
# keep track of which components have finished
completion_codeComponents = [text]
for thisComponent in completion_codeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
completion_codeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "completion_code"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = completion_codeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=completion_codeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    if text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text.tStartRefresh + 5-frameTolerance:
            # keep track of stop time/frame for later
            text.tStop = t  # not accounting for scr refresh
            text.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
            text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in completion_codeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "completion_code"-------
for thisComponent in completion_codeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
