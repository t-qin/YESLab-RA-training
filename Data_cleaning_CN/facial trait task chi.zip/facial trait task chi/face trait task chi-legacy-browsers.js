﻿/**************************** 
 * Face Trait Task Chi Test *
 ****************************/


// store info about the experiment session:
let expName = 'face trait task chi';  // from the Builder filename that created this script
let expInfo = {'participant': '请填写脑岛用户名', 'session': '2'};

// Start code blocks for 'Before Experiment'
// Choose trial
var choose_trial = Array.from({length: 50}, (_, i) => i);
var randChoice = [...Array(3)].map(() => Math.floor(Math.random() * 11) + 50); // Generating 3 random choices between 50 and 61
choose_trial.push(...randChoice);

console.log(`choose_trial: ${choose_trial}`);



// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0, 0, 0]),
  units: 'height',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(setupRoutineBegin());
flowScheduler.add(setupRoutineEachFrame());
flowScheduler.add(setupRoutineEnd());
flowScheduler.add(welcome1RoutineBegin());
flowScheduler.add(welcome1RoutineEachFrame());
flowScheduler.add(welcome1RoutineEnd());
flowScheduler.add(welcome2RoutineBegin());
flowScheduler.add(welcome2RoutineEachFrame());
flowScheduler.add(welcome2RoutineEnd());
const sessionLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(sessionLoopBegin(sessionLoopScheduler));
flowScheduler.add(sessionLoopScheduler);
flowScheduler.add(sessionLoopEnd);
flowScheduler.add(endRoutineBegin());
flowScheduler.add(endRoutineEachFrame());
flowScheduler.add(endRoutineEnd());
flowScheduler.add(completion_codeRoutineBegin());
flowScheduler.add(completion_codeRoutineEachFrame());
flowScheduler.add(completion_codeRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    {'name': 'image/4.jpg', 'path': 'image/4.jpg'},
    {'name': 'image/39.jpg', 'path': 'image/39.jpg'},
    {'name': 'image/50.jpg', 'path': 'image/50.jpg'},
    {'name': 'image/9.jpg', 'path': 'image/9.jpg'},
    {'name': 'image/27.jpg', 'path': 'image/27.jpg'},
    {'name': 'image/36.jpg', 'path': 'image/36.jpg'},
    {'name': 'image/8.jpg', 'path': 'image/8.jpg'},
    {'name': 'image/21.jpg', 'path': 'image/21.jpg'},
    {'name': 'image/35.jpg', 'path': 'image/35.jpg'},
    {'name': 'image/59.jpg', 'path': 'image/59.jpg'},
    {'name': 'image/57.jpg', 'path': 'image/57.jpg'},
    {'name': 'face_condition_test.xlsx', 'path': 'face_condition_test.xlsx'},
    {'name': 'image/16.jpg', 'path': 'image/16.jpg'},
    {'name': 'image/25.jpg', 'path': 'image/25.jpg'},
    {'name': 'image/41.jpg', 'path': 'image/41.jpg'},
    {'name': 'image/43.jpg', 'path': 'image/43.jpg'},
    {'name': 'critical.png', 'path': 'critical.png'},
    {'name': 'image/20.jpg', 'path': 'image/20.jpg'},
    {'name': 'image/44.jpg', 'path': 'image/44.jpg'},
    {'name': 'face_condition.xlsx', 'path': 'face_condition.xlsx'},
    {'name': 'image/38.jpg', 'path': 'image/38.jpg'},
    {'name': 'competent.png', 'path': 'competent.png'},
    {'name': 'image/17.jpg', 'path': 'image/17.jpg'},
    {'name': 'image/33.jpg', 'path': 'image/33.jpg'},
    {'name': 'image/10.jpg', 'path': 'image/10.jpg'},
    {'name': 'image/5.jpg', 'path': 'image/5.jpg'},
    {'name': 'image/61.jpg', 'path': 'image/61.jpg'},
    {'name': 'image/3.jpg', 'path': 'image/3.jpg'},
    {'name': 'image/14.jpg', 'path': 'image/14.jpg'},
    {'name': 'image/6.jpg', 'path': 'image/6.jpg'},
    {'name': 'image/55.jpg', 'path': 'image/55.jpg'},
    {'name': 'condition.xlsx', 'path': 'condition.xlsx'},
    {'name': 'image/51.jpg', 'path': 'image/51.jpg'},
    {'name': 'image/34.jpg', 'path': 'image/34.jpg'},
    {'name': 'image/60.jpg', 'path': 'image/60.jpg'},
    {'name': 'image/2.jpg', 'path': 'image/2.jpg'},
    {'name': 'image/54.jpg', 'path': 'image/54.jpg'},
    {'name': 'image/24.jpg', 'path': 'image/24.jpg'},
    {'name': 'friendly.png', 'path': 'friendly.png'},
    {'name': 'image/19.jpg', 'path': 'image/19.jpg'},
    {'name': 'image/23.jpg', 'path': 'image/23.jpg'},
    {'name': 'image/45.jpg', 'path': 'image/45.jpg'},
    {'name': 'image/40.jpg', 'path': 'image/40.jpg'},
    {'name': 'image/47.jpg', 'path': 'image/47.jpg'},
    {'name': 'image/52.jpg', 'path': 'image/52.jpg'},
    {'name': 'image/22.jpg', 'path': 'image/22.jpg'},
    {'name': 'image/49.jpg', 'path': 'image/49.jpg'},
    {'name': 'image/12.jpg', 'path': 'image/12.jpg'},
    {'name': 'image/42.jpg', 'path': 'image/42.jpg'},
    {'name': 'image/13.jpg', 'path': 'image/13.jpg'},
    {'name': 'image/29.jpg', 'path': 'image/29.jpg'},
    {'name': 'image/37.jpg', 'path': 'image/37.jpg'},
    {'name': 'image/58.jpg', 'path': 'image/58.jpg'},
    {'name': 'image/15.jpg', 'path': 'image/15.jpg'},
    {'name': 'trustworthy.png', 'path': 'trustworthy.png'},
    {'name': 'image/1.jpg', 'path': 'image/1.jpg'},
    {'name': 'image/fill_img.png', 'path': 'image/fill_img.png'},
    {'name': 'image/31.jpg', 'path': 'image/31.jpg'},
    {'name': 'image/32.jpg', 'path': 'image/32.jpg'},
    {'name': 'image/56.jpg', 'path': 'image/56.jpg'},
    {'name': 'image/53.jpg', 'path': 'image/53.jpg'},
    {'name': 'image/11.jpg', 'path': 'image/11.jpg'},
    {'name': 'image/26.jpg', 'path': 'image/26.jpg'},
    {'name': 'instruction2.png', 'path': 'instruction2.png'},
    {'name': 'image/7.jpg', 'path': 'image/7.jpg'},
    {'name': 'image/18.jpg', 'path': 'image/18.jpg'},
    {'name': 'image/46.jpg', 'path': 'image/46.jpg'},
    {'name': 'image/28.jpg', 'path': 'image/28.jpg'},
    {'name': 'image/48.jpg', 'path': 'image/48.jpg'},
    {'name': 'image/30.jpg', 'path': 'image/30.jpg'}
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var frameDur;
async function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2021.2.3';
  expInfo['OS'] = window.navigator.platform;

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}


var setupClock;
var random;
var randint;
var range;
var istest;
var testfaceNum;
var traitnames;
var traitnames_cn;
var session_intro_text;
var session_dictionary;
var session_trait;
var session_trait_cn;
var interval_txt;
var dictionary;
var warning_message;
var faceimg_width;
var time_lim_fast;
var time_lim_slow;
var welcome1Clock;
var key_resp;
var introduction_text;
var welcome2Clock;
var image_introduction;
var text_2;
var key_resp_4;
var session_beginClock;
var slider_label;
var slider_judge_img;
var session_cmp_number;
var count_face;
var slider_judge_intro;
var session_intro;
var text_6;
var key_resp_5;
var face_judgmentClock;
var trial_rt;
var question;
var this_slideLabel;
var slider_resp;
var image;
var question_judge;
var slider_face_judge;
var press_space_proceed;
var key_resp_3;
var check_answerClock;
var check_warning;
var check_warning_dur;
var text_5;
var ITIClock;
var polygon;
var text_4;
var session_breakClock;
var button_2;
var interval_text;
var endClock;
var end_text;
var button_3;
var completion_codeClock;
var text;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "setup"
  setupClock = new util.Clock();
  random = Math.random;
  randint = function(min, maxplusone) {
    return Math.floor(Math.random() * (maxplusone - min) ) + min;
  }
  range = function (size, startAt = 0) {
      return [...Array(size).keys()].map(i => i + startAt);
  }
  
  // save choose_trial
  psychoJS.experiment.addData("choose_trial", choose_trial);
  istest = 0;
  testfaceNum = 2;
  traitnames = ["critical", "competent", "trustworthy", "friendly"];
  traitnames_cn = ["\u4e25\u5389", "\u6709\u80fd\u529b", "\u53ef\u9760", "\u53cb\u5584"];
  session_intro_text = "";
  session_dictionary = "";
  session_trait = "";
  session_trait_cn = "";
  interval_txt = "";
  dictionary = ["\u4e25\u5389\uff1a\u5f62\u5bb9\u4e00\u4e2a\u4eba\u5728\u8bc4\u5224\u522b\u4eba\u65f6\u5f88\u82db\u523b\uff0c\u5e76\u4e14\u7ecf\u5e38\u53d1\u8868\u4e0d\u8d5e\u540c\u7684\u8bc4\u8bba\u3002\n", "\u6709\u80fd\u529b\uff1a\u6307\u4e00\u4e2a\u9ad8\u6548\u4e14\u6709\u80fd\u529b\u5b8c\u6210\u5404\u7c7b\u4e8b\u60c5\u7684\u4eba\u3002\n", "\u53ef\u9760\uff1a\u5f62\u5bb9\u4e00\u4e2a\u4eba\u503c\u5f97\u4fe1\u8d56\uff0c\u8868\u73b0\u51fa\u53ef\u9760\u6027\u548c\u6b63\u76f4\u7684\u54c1\u683c\u3002\n", "\u53cb\u5584\uff1a\u5f62\u5bb9\u4e00\u4e2a\u4eba\u5f85\u4eba\u548c\u5584\u3001\u4f7f\u4eba\u6109\u60a6\u3002\n"];
  warning_message = "\u5728\u5b9e\u9a8c\u8fc7\u7a0b\u4e2d\uff0c\u8bf7\u4e13\u6ce8\u4e8e\u60a8\u7684\u4efb\u52a1\uff1b\u5982\u679c\u60a8\u56de\u7b54\u5f97\u592a\u5feb\u6216\u592a\u6162\uff0c\u5c06\u4f1a\u6709\u8b66\u544a\u63d0\u793a\u3002\n\u6b64\u5916\uff0c\u8fd8\u4f1a\u6709\u4e00\u4e9b\u8bd5\u6b21\u8981\u6c42\u60a8\u5c06\u6ed1\u5757\u8c03\u6574\u5230\u7279\u5b9a\u4f4d\u7f6e\uff0c\u4ee5\u68c0\u6d4b\u60a8\u5728\u4e13\u6ce8\u5b8c\u6210\u4efb\u52a1\u3002\n";
  faceimg_width = 200;
  time_lim_fast = 0.2;
  time_lim_slow = 10;
  
  // Initialize components for Routine "welcome1"
  welcome1Clock = new util.Clock();
  key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  introduction_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'introduction_text',
    text: '欢迎参加实验！\n\n本实验包括四个小节，一共大约需要10分钟来完成。\n\n在每个小节中，您将依次看到一些面孔照片，您需要评估每张面孔的一个性格特征。\n\n每个阶段结束后，您可以休息一会儿。\n\n按 <空格键> 继续。',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, 0], height: 0.03,  wrapWidth: 1.0, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -2.0 
  });
  
  // Initialize components for Routine "welcome2"
  welcome2Clock = new util.Clock();
  image_introduction = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_introduction', units : undefined, 
    image : 'instruction2.png', mask : undefined,
    ori : 0.0, pos : [0, (- 0.25)], size : undefined,
    color : new util.Color([1, 1, 1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_2',
    text: '下面的例子展示了面孔的呈现方式。\n在面孔出现之前，首先，您将看到屏幕上出现一个十字，\n请将您的视线集中在这个十字上。然后，一张面孔会出现几秒钟。\n您需要根据给定的特征（在这个例子中是“友善”）来评估这张面孔。\n一旦您做好了决定，就可以拖动滑块输入答案，然后按空格键确认。\n确认之后，实验将自动跳转到下一张面孔。请尽可能快速和准确地做出判断。\n您的回答没有正确或错误，所以请尽可能提供您最真实的判断，\n即使您感觉像是在猜测。\n\n按 <空格键> 继续。',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, 0.2], height: 0.03,  wrapWidth: 1.0, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  key_resp_4 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "session_begin"
  session_beginClock = new util.Clock();
  slider_label = ["\u4e0d", "\u6bd4\u8f83\u4e0d", "\u6709\u70b9\u4e0d", ["\u65e2", "\u4e5f\u4e0d"], "\u6709\u70b9", "\u6bd4\u8f83", ""];
  slider_judge_img = "";
  session_cmp_number = 0;
  count_face = 0;
  
  slider_judge_intro = new visual.ImageStim({
    win : psychoJS.window,
    name : 'slider_judge_intro', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, (- 0.1)], size : undefined,
    color : new util.Color([1, 1, 1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  session_intro = new visual.TextStim({
    win: psychoJS.window,
    name: 'session_intro',
    text: '',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, 0.2], height: 0.03,  wrapWidth: 1.0, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -3.0 
  });
  
  text_6 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_6',
    text: '按<空格键>继续',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, (- 0.3)], height: 0.03,  wrapWidth: 1.0, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -4.0 
  });
  
  key_resp_5 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "face_judgment"
  face_judgmentClock = new util.Clock();
  trial_rt = (- 1);
  question = "";
  this_slideLabel = [];
  
  slider_resp = (- 1);
  
  image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0.1], size : undefined,
    color : new util.Color([1, 1, 1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -3.0 
  });
  question_judge = new visual.TextStim({
    win: psychoJS.window,
    name: 'question_judge',
    text: '',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, (- 0.15)], height: 0.03,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('black'),  opacity: undefined,
    depth: -4.0 
  });
  
  slider_face_judge = new visual.Slider({
    win: psychoJS.window, name: 'slider_face_judge',
    size: [1.0, 0.02], pos: [0, (- 0.32)], units: 'height',
    labels: [1, 2, 3, 4, 5, 6, 7], ticks: [1, 2, 3, 4, 5, 6, 7],
    granularity: 0.0, style: ["RATING"],
    color: new util.Color('white'), markerColor: new util.Color('Red'), lineColor: new util.Color('White'), 
    fontFamily: 'Open Sans', bold: true, italic: false, depth: -5, 
    flip: true,
  });
  
  press_space_proceed = new visual.TextStim({
    win: psychoJS.window,
    name: 'press_space_proceed',
    text: '按下 <空格键> 继续',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, (- 0.4)], height: 0.03,  wrapWidth: 1.3, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -6.0 
  });
  
  key_resp_3 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "check_answer"
  check_answerClock = new util.Clock();
  check_warning = "";
  check_warning_dur = 0;
  
  text_5 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_5',
    text: '',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: 1.3, ori: 0.0,
    color: new util.Color('red'),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "ITI"
  ITIClock = new util.Clock();
  var ITI_duration = 0.5;
  var warning_txt = ""
  polygon = new visual.ShapeStim ({
    win: psychoJS.window, name: 'polygon', 
    vertices: 'cross', size:[0.05, 0.05],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('white'),
    fillColor: new util.Color('white'),
    opacity: undefined, depth: -1, interpolate: true,
  });
  
  text_4 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_4',
    text: '',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, (- 0.15)], height: 0.04,  wrapWidth: 1.0, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -2.0 
  });
  
  // Initialize components for Routine "session_break"
  session_breakClock = new util.Clock();
  button_2 = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'button_2',
    text: 'Start',
    pos: [0, (- 0.3)], letterHeight: 0.03,
    size: [0.3, 0.1]
  });
  button_2.clock = new util.Clock();
  
  interval_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'interval_text',
    text: '',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, 0], height: 0.03,  wrapWidth: 1.0, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: -2.0 
  });
  
  // Initialize components for Routine "end"
  endClock = new util.Clock();
  end_text = new visual.TextStim({
    win: psychoJS.window,
    name: 'end_text',
    text: '本任务结束\n请点击下方确认键',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  button_3 = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'button_3',
    text: 'Confirm',
    pos: [0, (- 0.2)], letterHeight: 0.03,
    size: [0.3, 0.1]
  });
  button_3.clock = new util.Clock();
  
  // Initialize components for Routine "completion_code"
  completion_codeClock = new util.Clock();
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: '请不要关闭这个窗口。稍等片刻，我们正在保存您的数据。\n保存完毕后，会弹出<确定>按钮，请点击<确定>，\n之后您将自动跳转到最后的问卷填写。感谢您的参与！',
    font: 'Songti SC',
    units: undefined, 
    pos: [0, 0], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var setupComponents;
function setupRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'setup'-------
    t = 0;
    setupClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // keep track of which components have finished
    setupComponents = [];
    
    setupComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function setupRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'setup'-------
    // get current time
    t = setupClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    setupComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function setupRoutineEnd() {
  return async function () {
    //------Ending Routine 'setup'-------
    setupComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // the Routine "setup" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_allKeys;
var welcome1Components;
function welcome1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'welcome1'-------
    t = 0;
    welcome1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp.keys = undefined;
    key_resp.rt = undefined;
    _key_resp_allKeys = [];
    // keep track of which components have finished
    welcome1Components = [];
    welcome1Components.push(key_resp);
    welcome1Components.push(introduction_text);
    
    welcome1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function welcome1RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'welcome1'-------
    // get current time
    t = welcome1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *key_resp* updates
    if (t >= 0.0 && key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp.tStart = t;  // (not accounting for frame time here)
      key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp.clearEvents(); });
    }

    if (key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp.getKeys({keyList: ['space', 't'], waitRelease: false});
      _key_resp_allKeys = _key_resp_allKeys.concat(theseKeys);
      if (_key_resp_allKeys.length > 0) {
        key_resp.keys = _key_resp_allKeys[_key_resp_allKeys.length - 1].name;  // just the last key pressed
        key_resp.rt = _key_resp_allKeys[_key_resp_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *introduction_text* updates
    if (t >= 0.0 && introduction_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      introduction_text.tStart = t;  // (not accounting for frame time here)
      introduction_text.frameNStart = frameN;  // exact frame index
      
      introduction_text.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    welcome1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var _pj;
function welcome1RoutineEnd() {
  return async function () {
    //------Ending Routine 'welcome1'-------
    welcome1Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    if ((! _pj.in_es6(key_resp.keys, ["", [], null]))) {
        if ((key_resp.keys.slice((- 1))[0] === "t")) {
            istest = 1;
        }
    }
    console.log("Test mode?", istest);
    
    psychoJS.experiment.addData('key_resp.keys', key_resp.keys);
    if (typeof key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp.rt', key_resp.rt);
        routineTimer.reset();
        }
    
    key_resp.stop();
    // the Routine "welcome1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var _key_resp_4_allKeys;
var welcome2Components;
function welcome2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'welcome2'-------
    t = 0;
    welcome2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_4.keys = undefined;
    key_resp_4.rt = undefined;
    _key_resp_4_allKeys = [];
    // keep track of which components have finished
    welcome2Components = [];
    welcome2Components.push(image_introduction);
    welcome2Components.push(text_2);
    welcome2Components.push(key_resp_4);
    
    welcome2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function welcome2RoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'welcome2'-------
    // get current time
    t = welcome2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_introduction* updates
    if (t >= 0.0 && image_introduction.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_introduction.tStart = t;  // (not accounting for frame time here)
      image_introduction.frameNStart = frameN;  // exact frame index
      
      image_introduction.setAutoDraw(true);
    }

    
    // *text_2* updates
    if (t >= 0.0 && text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_2.tStart = t;  // (not accounting for frame time here)
      text_2.frameNStart = frameN;  // exact frame index
      
      text_2.setAutoDraw(true);
    }

    
    // *key_resp_4* updates
    if (t >= 0.0 && key_resp_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_4.tStart = t;  // (not accounting for frame time here)
      key_resp_4.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_4.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_4.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_4.clearEvents(); });
    }

    if (key_resp_4.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_4.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_4_allKeys = _key_resp_4_allKeys.concat(theseKeys);
      if (_key_resp_4_allKeys.length > 0) {
        key_resp_4.keys = _key_resp_4_allKeys[_key_resp_4_allKeys.length - 1].name;  // just the last key pressed
        key_resp_4.rt = _key_resp_4_allKeys[_key_resp_4_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    welcome2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function welcome2RoutineEnd() {
  return async function () {
    //------Ending Routine 'welcome2'-------
    welcome2Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('key_resp_4.keys', key_resp_4.keys);
    if (typeof key_resp_4.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_4.rt', key_resp_4.rt);
        routineTimer.reset();
        }
    
    key_resp_4.stop();
    // the Routine "welcome2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var session;
var currentLoop;
function sessionLoopBegin(sessionLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    session = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'condition.xlsx',
      seed: undefined, name: 'session'
    });
    psychoJS.experiment.addLoop(session); // add the loop to the experiment
    currentLoop = session;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    session.forEach(function() {
      const snapshot = session.getSnapshot();
    
      sessionLoopScheduler.add(importConditions(snapshot));
      sessionLoopScheduler.add(session_beginRoutineBegin(snapshot));
      sessionLoopScheduler.add(session_beginRoutineEachFrame());
      sessionLoopScheduler.add(session_beginRoutineEnd());
      const face_loopLoopScheduler = new Scheduler(psychoJS);
      sessionLoopScheduler.add(face_loopLoopBegin(face_loopLoopScheduler, snapshot));
      sessionLoopScheduler.add(face_loopLoopScheduler);
      sessionLoopScheduler.add(face_loopLoopEnd);
      sessionLoopScheduler.add(session_breakRoutineBegin(snapshot));
      sessionLoopScheduler.add(session_breakRoutineEachFrame());
      sessionLoopScheduler.add(session_breakRoutineEnd());
      sessionLoopScheduler.add(endLoopIteration(sessionLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


var face_loop;
function face_loopLoopBegin(face_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    face_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: TrialHandler.importConditions(psychoJS.serverManager, 'face_condition.xlsx', choose_trial),
      seed: undefined, name: 'face_loop'
    });
    psychoJS.experiment.addLoop(face_loop); // add the loop to the experiment
    currentLoop = face_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    face_loop.forEach(function() {
      const snapshot = face_loop.getSnapshot();
    
      face_loopLoopScheduler.add(importConditions(snapshot));
      face_loopLoopScheduler.add(face_judgmentRoutineBegin(snapshot));
      face_loopLoopScheduler.add(face_judgmentRoutineEachFrame());
      face_loopLoopScheduler.add(face_judgmentRoutineEnd());
      face_loopLoopScheduler.add(check_answerRoutineBegin(snapshot));
      face_loopLoopScheduler.add(check_answerRoutineEachFrame());
      face_loopLoopScheduler.add(check_answerRoutineEnd());
      face_loopLoopScheduler.add(ITIRoutineBegin(snapshot));
      face_loopLoopScheduler.add(ITIRoutineEachFrame());
      face_loopLoopScheduler.add(ITIRoutineEnd());
      face_loopLoopScheduler.add(endLoopIteration(face_loopLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function face_loopLoopEnd() {
  psychoJS.experiment.removeLoop(face_loop);

  return Scheduler.Event.NEXT;
}


async function sessionLoopEnd() {
  psychoJS.experiment.removeLoop(session);

  return Scheduler.Event.NEXT;
}


var session_number;
var session_trait_dictionary;
var _key_resp_5_allKeys;
var session_beginComponents;
function session_beginRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'session_begin'-------
    t = 0;
    session_beginClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    //const _ = require('lodash');
    //
    //// Generate an array containing numbers from 0 to 49
    //const choose_trial = Array.from({ length: 50 }, (_, i) => i);
    //
    //// Add 3 randomly chosen numbers from 50 to 60 (inclusive)
    //const randomNumbers = _.sampleSize(_.range(50, 61), 3);
    //choose_trial.push(...randomNumbers);
    //
    //console.log("choose trial: ", choose_trial);
    //
    session_number = thisSession.session_serial;
    console.log(("thisSession = " + thisSession.toString()));
    session_trait = traitnames[session_number];
    console.log(("This session is: " + session_trait));
    session_trait_dictionary = dictionary[session_number];
    session_trait_cn = traitnames_cn[session_number];
    session_intro_text = ((((((("\u5728\u4e0b\u9762\u7684\u73af\u8282\u4e2d\uff0c\u4f60\u5c06\u88ab\u8981\u6c42\u8bc4\u4f30\uff1a\u8fd9\u4e2a\u4eba\u6709\u591a" + session_trait_cn) + "\uff1f\n\n") + "\u5b9a\u4e49\n") + session_trait_dictionary) + "\n\n") + warning_message) + "\n\u8fd9\u662f\u4f60\u5c06\u770b\u5230\u7684\u8bc4\u5206\u91cf\u8868\uff1a");
    slider_judge_img = (session_trait + ".png");
    console.log(slider_judge_img);
    psychoJS.experiment.addData("session_trait", session_trait);
    session_cmp_number += 1;
    count_face = 0;
    
    slider_judge_intro.setImage(slider_judge_img);
    session_intro.setText(session_intro_text);
    key_resp_5.keys = undefined;
    key_resp_5.rt = undefined;
    _key_resp_5_allKeys = [];
    // keep track of which components have finished
    session_beginComponents = [];
    session_beginComponents.push(slider_judge_intro);
    session_beginComponents.push(session_intro);
    session_beginComponents.push(text_6);
    session_beginComponents.push(key_resp_5);
    
    session_beginComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function session_beginRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'session_begin'-------
    // get current time
    t = session_beginClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *slider_judge_intro* updates
    if (t >= 0.0 && slider_judge_intro.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      slider_judge_intro.tStart = t;  // (not accounting for frame time here)
      slider_judge_intro.frameNStart = frameN;  // exact frame index
      
      slider_judge_intro.setAutoDraw(true);
    }

    
    // *session_intro* updates
    if (t >= 0.0 && session_intro.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      session_intro.tStart = t;  // (not accounting for frame time here)
      session_intro.frameNStart = frameN;  // exact frame index
      
      session_intro.setAutoDraw(true);
    }

    
    // *text_6* updates
    if (t >= 0.0 && text_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_6.tStart = t;  // (not accounting for frame time here)
      text_6.frameNStart = frameN;  // exact frame index
      
      text_6.setAutoDraw(true);
    }

    
    // *key_resp_5* updates
    if (t >= 0.0 && key_resp_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_5.tStart = t;  // (not accounting for frame time here)
      key_resp_5.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_5.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_5.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_5.clearEvents(); });
    }

    if (key_resp_5.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_5.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_5_allKeys = _key_resp_5_allKeys.concat(theseKeys);
      if (_key_resp_5_allKeys.length > 0) {
        key_resp_5.keys = _key_resp_5_allKeys[_key_resp_5_allKeys.length - 1].name;  // just the last key pressed
        key_resp_5.rt = _key_resp_5_allKeys[_key_resp_5_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    session_beginComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function session_beginRoutineEnd() {
  return async function () {
    //------Ending Routine 'session_begin'-------
    session_beginComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    psychoJS.experiment.addData('key_resp_5.keys', key_resp_5.keys);
    if (typeof key_resp_5.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_5.rt', key_resp_5.rt);
        routineTimer.reset();
        }
    
    key_resp_5.stop();
    // the Routine "session_begin" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var finish_slide;
var this_sliderLabel;
var image_number;
var _key_resp_3_allKeys;
var face_judgmentComponents;
function face_judgmentRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'face_judgment'-------
    t = 0;
    face_judgmentClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    count_face = (count_face + 1);
    finish_slide = 0;
    this_sliderLabel = (((((((((((((((((((((((("(1 = " + slider_label[0]) + session_trait_cn) + ", 2 = ") + slider_label[1]) + session_trait_cn) + ", 3 = ") + slider_label[2]) + session_trait_cn) + ",\n") + "4 = ") + slider_label[3][0]) + session_trait_cn) + slider_label[3][1]) + session_trait_cn) + ", 5 = ") + slider_label[4]) + session_trait_cn) + ", \n6 = ") + slider_label[5]) + session_trait_cn) + ", 7 = ") + slider_label[6]) + session_trait_cn) + ")");
    if ((istest && (count_face > testfaceNum))) {
        continueRoutine = false;
        psychoJS.experiment.nextEntry();
    }
    image_number = thisFace_loop.face_serial;
    console.log(image_name);
    if (isCheck) {
        question = check_question;
    } else {
        question = ((("\u8fd9\u4e2a\u4eba\u6709\u591a" + session_trait_cn) + "\uff1f\n\n") + this_sliderLabel);
    }
    
    slider_resp = (- 1);
    
    image.setImage(image_name);
    question_judge.setText(question);
    slider_face_judge.reset()
    key_resp_3.keys = undefined;
    key_resp_3.rt = undefined;
    _key_resp_3_allKeys = [];
    // keep track of which components have finished
    face_judgmentComponents = [];
    face_judgmentComponents.push(image);
    face_judgmentComponents.push(question_judge);
    face_judgmentComponents.push(slider_face_judge);
    face_judgmentComponents.push(press_space_proceed);
    face_judgmentComponents.push(key_resp_3);
    
    face_judgmentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function face_judgmentRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'face_judgment'-------
    // get current time
    t = face_judgmentClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // this can't be auto translated to JS
    if ((slider_face_judge.getRating() !== undefined)){
        finish_slide = 1;
    }
    
    // *image* updates
    if (t >= 0.0 && image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image.tStart = t;  // (not accounting for frame time here)
      image.frameNStart = frameN;  // exact frame index
      
      image.setAutoDraw(true);
    }

    
    // *question_judge* updates
    if (t >= 0.5 && question_judge.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      question_judge.tStart = t;  // (not accounting for frame time here)
      question_judge.frameNStart = frameN;  // exact frame index
      
      question_judge.setAutoDraw(true);
    }

    
    // *slider_face_judge* updates
    if (t >= 0.5 && slider_face_judge.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      slider_face_judge.tStart = t;  // (not accounting for frame time here)
      slider_face_judge.frameNStart = frameN;  // exact frame index
      
      slider_face_judge.setAutoDraw(true);
    }

    
    // *press_space_proceed* updates
    if (((finish_slide == 1)) && press_space_proceed.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      press_space_proceed.tStart = t;  // (not accounting for frame time here)
      press_space_proceed.frameNStart = frameN;  // exact frame index
      
      press_space_proceed.setAutoDraw(true);
    }

    
    // *key_resp_3* updates
    if (((finish_slide == 1)) && key_resp_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_3.tStart = t;  // (not accounting for frame time here)
      key_resp_3.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_3.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_3.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_3.clearEvents(); });
    }

    if (key_resp_3.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_3.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_3_allKeys = _key_resp_3_allKeys.concat(theseKeys);
      if (_key_resp_3_allKeys.length > 0) {
        key_resp_3.keys = _key_resp_3_allKeys[_key_resp_3_allKeys.length - 1].name;  // just the last key pressed
        key_resp_3.rt = _key_resp_3_allKeys[_key_resp_3_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    face_judgmentComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var currentTime;
function face_judgmentRoutineEnd() {
  return async function () {
    //------Ending Routine 'face_judgment'-------
    face_judgmentComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    question = "";
    
    //// there is no 'list' in js. we should use 'Array' instead
    //if (Array.isArray(slider_face_judge.rt) && slider_face_judge.rt.length > 0) {
    //    trial_rt = Number.parseFloat(key_resp_3.rt[0]);
    //} else {
    //    if (Array.isArray(slider_face_judge.rt) && slider_face_judge.rt.length === 0) {
    //        trail_rt = 0;
    //    } else {
    //        trial_rt = Number.parseFloat(slider_face_judge.rt);
    //    }
    //}
    //
    if ((finish_slide === 1)) {
        slider_resp = slider_face_judge.getRating();
    }
    
    psychoJS.experiment.addData('slider_face_judge.response', slider_face_judge.getRating());
    psychoJS.experiment.addData('slider_face_judge.rt', slider_face_judge.getRT());
    psychoJS.experiment.addData('key_resp_3.keys', key_resp_3.keys);
    if (typeof key_resp_3.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_3.rt', key_resp_3.rt);
        routineTimer.reset();
        }
    
    key_resp_3.stop();
    currentTime = face_judgmentClock.getTime();
    trial_rt = (currentTime - slider_face_judge.tStart);
    console.log(`trial_rt is : ${trial_rt}
    `);
    
    // the Routine "face_judgment" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var check_answerComponents;
function check_answerRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'check_answer'-------
    t = 0;
    check_answerClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    if ((isCheck === 1)) {
        if (((slider_resp > (answer - 0.5)) && (slider_resp < (answer + 0.5)))) {
            check_warning = "";
            check_warning_dur = 0;
        } else {
            check_warning = "\u8bf7\u4e13\u6ce8\u4e8e\u4efb\u52a1!";
            check_warning_dur = 2;
        }
    } else {
        check_warning = "";
        check_warning_dur = 0;
    }
    
    text_5.setText(check_warning);
    // keep track of which components have finished
    check_answerComponents = [];
    check_answerComponents.push(text_5);
    
    check_answerComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function check_answerRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'check_answer'-------
    // get current time
    t = check_answerClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text_5* updates
    if (t >= 0.0 && text_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_5.tStart = t;  // (not accounting for frame time here)
      text_5.frameNStart = frameN;  // exact frame index
      
      text_5.setAutoDraw(true);
    }

    frameRemains = 0.0 + check_warning_dur - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (text_5.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text_5.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    check_answerComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function check_answerRoutineEnd() {
  return async function () {
    //------Ending Routine 'check_answer'-------
    check_answerComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // the Routine "check_answer" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var ITI_duration;
var warning_txt;
var ITIComponents;
function ITIRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'ITI'-------
    t = 0;
    ITIClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // Define ITI_duration
    ITI_duration = 0.5 + Math.random();
    
    // Determine warning message based on trial_rt
    if ((trial_rt < 0.2)) {
        warning_txt = "\u60a8\u7684\u5224\u65ad\u53ef\u80fd\u8fc7\u4e8e\u4ed3\u4fc3\u3002\n\u8bf7\u5728\u56de\u7b54\u524d\u82b1\u65f6\u95f4\u4ed4\u7ec6\u8003\u8651\u3002";
        ITI_duration = (2 + Math.random());
    } else {
        if ((trial_rt > 10)) {
            ITI_duration = (2 + Math.random());
            warning_txt = "\u60a8\u7684\u5224\u65ad\u53ef\u80fd\u6709\u6240\u62d6\u5ef6\u3002\n\u5c1d\u8bd5\u66f4\u8fc5\u901f\u5730\u56de\u5e94\uff0c\u4ee5\u4fdd\u6301\u4efb\u52a1\u7684\u8282\u594f\u3002";
        } else {
            warning_txt = "";
        }
    }
    
    if ((istest && (count_face > testfaceNum))) {
        continueRoutine = false;
        psychoJS.experiment.nextEntry();
    }
    text_4.setText(warning_txt);
    // keep track of which components have finished
    ITIComponents = [];
    ITIComponents.push(polygon);
    ITIComponents.push(text_4);
    
    ITIComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function ITIRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'ITI'-------
    // get current time
    t = ITIClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *polygon* updates
    if (t >= 0.0 && polygon.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      polygon.tStart = t;  // (not accounting for frame time here)
      polygon.frameNStart = frameN;  // exact frame index
      
      polygon.setAutoDraw(true);
    }

    frameRemains = 0.0 + ITI_duration - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (polygon.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      polygon.setAutoDraw(false);
    }
    
    // *text_4* updates
    if (t >= 0.0 && text_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_4.tStart = t;  // (not accounting for frame time here)
      text_4.frameNStart = frameN;  // exact frame index
      
      text_4.setAutoDraw(true);
    }

    frameRemains = 0.0 + ITI_duration - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (text_4.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text_4.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ITIComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ITIRoutineEnd() {
  return async function () {
    //------Ending Routine 'ITI'-------
    ITIComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // the Routine "ITI" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var session_breakComponents;
function session_breakRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'session_break'-------
    t = 0;
    session_breakClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    if ((session_cmp_number === 4)) {
        continueRoutine = false;
    }
    interval_txt = (((("\u4f60\u521a\u521a\u5b8c\u6210\u4e86\u9636\u6bb5" + session_cmp_number.toString()) + "\u3002\u73b0\u5728\u4f60\u53ef\u4ee5\u4f11\u606f\u4e00\u5c0f\u4f1a\u3002\n\u5f53\u4f60\u51c6\u5907\u597d\u540e\uff0c\u70b9\u51fb\u4e0b\u9762\u7684\u6309\u952e\u5f00\u59cb\u9636\u6bb5") + (session_cmp_number + 1).toString()) + "\u7684\u4efb\u52a1\u3002");
    
    interval_text.setText(interval_txt);
    // keep track of which components have finished
    session_breakComponents = [];
    session_breakComponents.push(button_2);
    session_breakComponents.push(interval_text);
    
    session_breakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function session_breakRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'session_break'-------
    // get current time
    t = session_breakClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *button_2* updates
    if (t >= 0 && button_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_2.tStart = t;  // (not accounting for frame time here)
      button_2.frameNStart = frameN;  // exact frame index
      
      button_2.setAutoDraw(true);
    }

    if (button_2.status === PsychoJS.Status.STARTED) {
      // check whether button_2 has been pressed
      if (button_2.isClicked) {
        if (!button_2.wasClicked) {
          // store time of first click
          button_2.timesOn.push(button_2.clock.getTime());
          // store time clicked until
          button_2.timesOff.push(button_2.clock.getTime());
        } else {
          // update time clicked until;
          button_2.timesOff[button_2.timesOff.length - 1] = button_2.clock.getTime();
        }
        if (!button_2.wasClicked) {
          // end routine when button_2 is clicked
          continueRoutine = false;
          null;
        }
        // if button_2 is still clicked next frame, it is not a new click
        button_2.wasClicked = true;
      } else {
        // if button_2 is clicked next frame, it is a new click
        button_2.wasClicked = false
      }
    } else {
      // keep clock at 0 if button_2 hasn't started / has finished
      button_2.clock.reset();
      // if button_2 is clicked next frame, it is a new click
      button_2.wasClicked = false;
    }
    
    // *interval_text* updates
    if (t >= 0.0 && interval_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      interval_text.tStart = t;  // (not accounting for frame time here)
      interval_text.frameNStart = frameN;  // exact frame index
      
      interval_text.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    session_breakComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function session_breakRoutineEnd() {
  return async function () {
    //------Ending Routine 'session_break'-------
    session_breakComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // the Routine "session_break" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var endComponents;
function endRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'end'-------
    t = 0;
    endClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // keep track of which components have finished
    endComponents = [];
    endComponents.push(end_text);
    endComponents.push(button_3);
    
    endComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function endRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'end'-------
    // get current time
    t = endClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *end_text* updates
    if (t >= 0.0 && end_text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      end_text.tStart = t;  // (not accounting for frame time here)
      end_text.frameNStart = frameN;  // exact frame index
      
      end_text.setAutoDraw(true);
    }

    
    // *button_3* updates
    if (t >= 0 && button_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      button_3.tStart = t;  // (not accounting for frame time here)
      button_3.frameNStart = frameN;  // exact frame index
      
      button_3.setAutoDraw(true);
    }

    if (button_3.status === PsychoJS.Status.STARTED) {
      // check whether button_3 has been pressed
      if (button_3.isClicked) {
        if (!button_3.wasClicked) {
          // store time of first click
          button_3.timesOn.push(button_3.clock.getTime());
          // store time clicked until
          button_3.timesOff.push(button_3.clock.getTime());
        } else {
          // update time clicked until;
          button_3.timesOff[button_3.timesOff.length - 1] = button_3.clock.getTime();
        }
        if (!button_3.wasClicked) {
          // end routine when button_3 is clicked
          continueRoutine = false;
          null;
        }
        // if button_3 is still clicked next frame, it is not a new click
        button_3.wasClicked = true;
      } else {
        // if button_3 is clicked next frame, it is a new click
        button_3.wasClicked = false
      }
    } else {
      // keep clock at 0 if button_3 hasn't started / has finished
      button_3.clock.reset();
      // if button_3 is clicked next frame, it is a new click
      button_3.wasClicked = false;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    endComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function endRoutineEnd() {
  return async function () {
    //------Ending Routine 'end'-------
    endComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // the Routine "end" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    return Scheduler.Event.NEXT;
  };
}


var completion_codeComponents;
function completion_codeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //------Prepare to start Routine 'completion_code'-------
    t = 0;
    completion_codeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(5.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    completion_codeComponents = [];
    completion_codeComponents.push(text);
    
    completion_codeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function completion_codeRoutineEachFrame() {
  return async function () {
    //------Loop for each frame of Routine 'completion_code'-------
    // get current time
    t = completion_codeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text* updates
    if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    frameRemains = 0.0 + 5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    completion_codeComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function completion_codeRoutineEnd() {
  return async function () {
    //------Ending Routine 'completion_code'-------
    completion_codeComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    return Scheduler.Event.NEXT;
  };
}


function endLoopIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        const thisTrial = snapshot.getCurrentTrial();
        if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
          psychoJS.experiment.nextEntry(snapshot);
        }
      }
    return Scheduler.Event.NEXT;
    }
  };
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
