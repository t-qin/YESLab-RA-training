﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2021.2.3),
    on Sun May 26 16:46:00 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

import psychopy
psychopy.useVersion('2021.2.3')


from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2021.2.3'
expName = 'Interaction Game'  # from the Builder filename that created this script
expInfo = {'participant': '请输入脑岛用户名', 'session': '1'}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/sz/SZ_Projects/Experiment_Guilt_SAD/Naodao/interactive game chinese/interaction task chi_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# Setup the Window
win = visual.Window(
    size=[1440, 900], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color='black', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='norm')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# Setup eyetracking
ioDevice = ioConfig = ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "PreDef"
PreDefClock = core.Clock()
# for testing
testing = 0

# save the share choice
share_choice = []

# redo?
redo_flag = 0

# experimental design - practice
import random as random
pracrow = random.sample(range(10), 3)

# exp design - formal procedure
chunks = [range(i, i+12) for i in range(0, 192, 12)]
chunks.append(range(192, 198))
chunks.append(range(198, 204))

# Initialize a list to store the selected trials
chooserow = []

# For the both_right condition, randomly choose 1 trials from each DV
for chunk in chunks[:4]:
    choose = random.sample(chunk, 1)
    chooserow.extend(choose)
    print(f"experiment: {chunk}, choose: {choose}")

# Randomly choose items from the first 16 chunks (3 items per chunk)
for chunk in chunks[4:len(chunks)-2]:
    choose = random.sample(chunk, 3)
    print(f"experiment: {chunk}, choose: {choose}")
    chooserow.extend(choose)

# Randomly choose items from the last 2 chunks (1 item per chunk)
for chunk in chunks[len(chunks)-2:]:
    choose = random.sample(chunk, 1)
    chooserow.extend(choose)
    print(f"experiment: {chunk}, choose: {choose}")

chooserow = random.sample(chooserow, len(chooserow))
for i in range(len(chooserow) - 2):  # Iterate over the entire length of chooserow
    while i < len(chooserow) - 2 and chooserow[i] // 12 % 4 == chooserow[i+1] // 12 % 4 == chooserow[i+2] // 12 % 4:
        tail = chooserow[i+2:]
        newtail = random.sample(tail, len(tail))
        chooserow = chooserow[:i+2] + newtail  # Update chooserow properly

print(f"chooserow: {chooserow}")

# List for incomplete trials
incompleteTrials = []  

# count current trial
countTrial = 0

# save the index
# thisExp.addData('rannum',rannum)
thisExp.addData('chooserow',chooserow)
thisExp.addData('ParID',expInfo[u'participant'])
# aesthetic
bottom_textsize = 0.08
scrhig = win.size[1]
scrwid = win.size[0]
pairsize0 = [scrhig/364*825/scrwid*0.7,0.7]
pairsize1 = [scrhig/364*673/scrwid*0.7,0.7] # image: three agents
pairsize2 = [scrhig/273*357/scrwid*0.3,0.3] # image: two agents两人一阶段
pairsize3 = [pairsize2[0]/2, pairsize2[1]/2] # in the DV phase
dotsize = [scrhig/scrwid*0.7,0.7]
resultsize = [scrhig/110*279/scrwid*0.16,0.16]
resultsize_DV = [resultsize[0]/2, resultsize[1]/2] # in the DV phase
resultpos = [0, -0.05]
resultpos_DV = [-0.7, 0.65]
punishpicsize = [scrhig/scrwid*0.2,0.2]
ypos1 = 0.5 #phase cue
ypos2 = 0.2 # pari pos
cuepos = [0,ypos1]
pairpos = [0,ypos2]
pairpos_DV = [-0.7, 0.75]

# complete instruction
comp_text = u"感谢您完成当前任务！\n请稍候片刻，我们正在保存您的数据。\n保存完成后，会弹出一个<OK>按钮，\n请点击这个按钮，之后您将自动跳转到下一个任务。\n感谢您的合作！"
# "Thank you for completing this game! Please wait briefly while we save your data. Once complete, click the <OK> button when it appears. You will be directed to the next game automatically. Your cooperation is greatly appreciated."

# Initialize components for Routine "Welcome"
WelcomeClock = core.Clock()
welcome = visual.TextStim(win=win, name='welcome',
    text='欢迎参加本次实验！\n\n\n',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp_2 = keyboard.Keyboard()
press_space = visual.TextStim(win=win, name='press_space',
    text='按“空格键”继续',
    font='Songti SC',
    pos=(0, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "check_testing"
check_testingClock = core.Clock()

# Initialize components for Routine "ins_1"
ins_1Clock = core.Clock()
ins1 = visual.TextStim(win=win, name='ins1',
    text='请仔细阅读以下说明。理解任务内容对您非常重要。\n稍后您需要回答说明中提到的任务细节。',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=1.75, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp_3 = keyboard.Keyboard()
press_space1 = visual.TextStim(win=win, name='press_space1',
    text='按“空格键”继续',
    font='Songti SC',
    pos=(0, -0.7), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "ins__2"
ins__2Clock = core.Clock()
ins1_4 = visual.TextStim(win=win, name='ins1_4',
    text='请设想你正在和其他三个人一同参与一项实验，\n你不知道这三个人的身份，但他们和你一样是参与实验的被试。\n实验中会有多轮互动，你会和其他人交替配对。\n在每轮游戏开始前，计算机程序将从其他4名参与者中\n为你随机匹配一名匿名对家与你共同完成一项“点估计”的任务。',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp_9 = keyboard.Keyboard()
press_space1_4 = visual.TextStim(win=win, name='press_space1_4',
    text='请按“空格键”继续',
    font='Songti SC',
    pos=(0, -0.7), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "ins_3"
ins_3Clock = core.Clock()
ins1_3 = visual.TextStim(win=win, name='ins1_3',
    text='具体来说，你和你的伙伴将在屏幕上看到一些白色的点。\n你们的任务是估计这些点的总数。点消失后，你会在屏幕上看到一个数字。\n你需要判断你刚才看到的点的数量是大于还是小于屏幕上呈现的数字。\n如果你认为点的数量比屏幕上的数字少，那么使用鼠标点击“小于”；\n如果你认为点的数量比屏幕上的数字多，那么使用鼠标点击“大于”。\n你需要在5秒内做出选择，否则你的回答将被记录为“未完成”，\n并提示你下一轮更快回答。',
    font='Songti SC',
    pos=(0, 0), height=0.05, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp_8 = keyboard.Keyboard()
press_space1_3 = visual.TextStim(win=win, name='press_space1_3',
    text='按“空格键”继续',
    font='Songti SC',
    pos=(0, -0.7), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "ins_4"
ins_4Clock = core.Clock()
ins2 = visual.TextStim(win=win, name='ins2',
    text='一旦你和你的伙伴都提交了回答，你们将看到本轮的表现。\n如果回答正确，你们的身份图标下面会显示绿色对勾；\n反之，则会显示红色叉号。如果你和你的伙伴的回答都正确，\n则没有人会受到惩罚。然而，如果你们中的任何一个或两个人都回答错误，\n那么你的伙伴（而不包括你）将必须观看一张负性情绪的图片5秒作为惩罚。\n下面的表格总结了惩罚的执行方式。请仔细阅读表格。\n在下一页，你将看到一个负性情绪图片的示例。\n这可能会让你感到不适，所以如果你不想看到它，你可以现在退出实验。',
    font='Songti SC',
    pos=(0, 0.35), height=0.05, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp_4 = keyboard.Keyboard()
press_space2 = visual.TextStim(win=win, name='press_space2',
    text='按“空格键”继续',
    font='Songti SC',
    pos=(0, -0.9), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
Rule = visual.ImageStim(
    win=win,
    name='Rule', units='norm', 
    image='Resp_pic.png', mask=None,
    ori=0.0, pos=(0, -0.37), size=[scrhig/400*1187/scrwid*0.8,0.8],
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)

# Initialize components for Routine "aver_ima"
aver_imaClock = core.Clock()
text_18 = visual.TextStim(win=win, name='text_18',
    text='负性情绪图片呈现中……',
    font='Songti SC',
    pos=(0, -0.65), height=0.07, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
aver_image = visual.ImageStim(
    win=win,
    name='aver_image', 
    image='9290.JPG', mask=None,
    ori=0.0, pos=(0, 0), size=[1024/768*0.5,0.5],
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)

# Initialize components for Routine "ins_5"
ins_5Clock = core.Clock()
ins3 = visual.TextStim(win=win, name='ins3',
    text='在“点估计”任务结束后，屏幕上会出现一些关于你当时的感受和想法的问题，\n请使用鼠标将滑块拖动到你认为合适的位置来回答。\n请尽可能保证你的回答真实。\n回答完屏幕上的所有问题后，请按“空格键”确认你的答案并继续实验。',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp_5 = keyboard.Keyboard()

# Initialize components for Routine "ins_6"
ins_6Clock = core.Clock()
ins3_2 = visual.TextStim(win=win, name='ins3_2',
    text='请回答以下问题，以确保你正确理解了任务内容。\n如果你回答错误，你将需要重新阅读任务说明。\n按“空格键”继续。',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp_6 = keyboard.Keyboard()

# Initialize components for Routine "Check_1"
Check_1Clock = core.Clock()
check1 = visual.TextStim(win=win, name='check1',
    text='在设想的游戏中，不包括你自己，共有多少名参与者参与这项任务？\n（按键盘上相应的数字选择答案）\n',
    font='Songti SC',
    pos=(0, 0.3), height=0.07, wrapWidth=1.65, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
a1 = visual.TextStim(win=win, name='a1',
    text='1) 一个人     2) 两个人     3) 三个人     4) 四个人',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_resp_3 = keyboard.Keyboard()

# Initialize components for Routine "ins_fb"
ins_fbClock = core.Clock()
feedback_2 = visual.TextStim(win=win, name='feedback_2',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
feedback_time = 2

# Initialize components for Routine "Check_2"
Check_2Clock = core.Clock()
check2 = visual.TextStim(win=win, name='check2',
    text='2. 每一轮游戏中你的伙伴是如何确定的？\n\n（按键盘上相应的数字选择答案）\n\n',
    font='Songti SC',
    pos=(0, 0.3), height=0.07, wrapWidth=1.65, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
b1 = visual.TextStim(win=win, name='b1',
    text='1) 从其他三名参与者中随机选择一人。\n\n\n2) 整个游戏中，你的伙伴始终是同一个人。\n\n\n3) 三名参与者将轮流成为你的伙伴。',
    font='Songti SC',
    pos=[0,0], height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
k1=[0.2,-0.1]
key_resp_4 = keyboard.Keyboard()

# Initialize components for Routine "ins_fb_2"
ins_fb_2Clock = core.Clock()
feedback_3 = visual.TextStim(win=win, name='feedback_3',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
feedback_time = 2

# Initialize components for Routine "Check_3"
Check_3Clock = core.Clock()
check3 = visual.TextStim(win=win, name='check3',
    text='3. 在“点估计”任务中，如果你在5秒内没有做出判断，会发生什么？\n\n（按键盘上相应的数字选择答案）',
    font='Songti SC',
    pos=(0, 0.3), height=0.07, wrapWidth=1.65, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
c1 = visual.TextStim(win=win, name='c1',
    text='1) 你将不得不观看1张负性情绪图片5秒作为惩罚\n\n\n2) 你的伙伴将不得不观看1张负性情绪图片5秒作为惩罚\n\n\n3) 你的回答将被记录为“未完成”，并且你将被提醒在下一轮中更快地回答\n',
    font='Songti SC',
    pos=[0,0], height=0.07, wrapWidth=1.8, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
k2=[0.1,-0.3]

key_resp_5 = keyboard.Keyboard()

# Initialize components for Routine "ins_fb_3"
ins_fb_3Clock = core.Clock()
feedback_4 = visual.TextStim(win=win, name='feedback_4',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
feedback_time = 2

# Initialize components for Routine "Check_4"
Check_4Clock = core.Clock()
check4 = visual.TextStim(win=win, name='check4',
    text='4.下图显示了一次“点估计”任务的表现。在这种情况下，谁将接受惩罚？\n\n（按键盘上相应的数字选择答案）',
    font='Songti SC',
    pos=(0, 0.5), height=0.07, wrapWidth=1.65, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
d1 = visual.TextStim(win=win, name='d1',
    text='1) 你\n\n\n2) 你的伙伴\n\n\n3) 没有人需要接受惩罚\n\n',
    font='Songti SC',
    pos=[0,0], height=0.07, wrapWidth=1.8, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
k3=[0.1,-0.6]

key_resp_6 = keyboard.Keyboard()
pairing_sub_7 = visual.ImageStim(
    win=win,
    name='pairing_sub_7', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-5.0)
result_2 = visual.ImageStim(
    win=win,
    name='result_2', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=(0, -0.05), size=resultsize,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)

# Initialize components for Routine "ins_fb_4"
ins_fb_4Clock = core.Clock()
feedback_5 = visual.TextStim(win=win, name='feedback_5',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
feedback_time = 2


# Initialize components for Routine "Check_5"
Check_5Clock = core.Clock()
check5 = visual.TextStim(win=win, name='check5',
    text='5.下图显示了一次“点估计”任务的表现。在这种情况下，谁将接受惩罚？\n\n（按键盘上相应的数字选择答案）',
    font='Songti SC',
    pos=(0, 0.5), height=0.07, wrapWidth=1.65, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
e1 = visual.TextStim(win=win, name='e1',
    text='1) 你\n\n\n2) 你的伙伴\n\n\n3) 没有人需要接受惩罚',
    font='Songti SC',
    pos=[0,0], height=0.07, wrapWidth=1.8, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
k3=[0.1,-0.6]
key_resp_7 = keyboard.Keyboard()
pairing_sub_8 = visual.ImageStim(
    win=win,
    name='pairing_sub_8', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-5.0)
result_3 = visual.ImageStim(
    win=win,
    name='result_3', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=(0, -0.05), size=resultsize,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)

# Initialize components for Routine "ins_fb_5"
ins_fb_5Clock = core.Clock()
feedback_6 = visual.TextStim(win=win, name='feedback_6',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
feedback_time = 2

# Initialize components for Routine "end_ins"
end_insClock = core.Clock()

# Initialize components for Routine "read_again"
read_againClock = core.Clock()
text_15 = visual.TextStim(win=win, name='text_15',
    text='你至少回答错误了一个问题！\n\n请再仔细阅读一遍说明！',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "prac_ins"
prac_insClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='在正式游戏开始之前，请你首先单独进行“点估计”任务练习，\n一边更好地熟悉该任务，并提高反应正确率\n按“空格键”开始练习\n',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
pre_instru_resp = keyboard.Keyboard()

# Initialize components for Routine "prac_sta"
prac_staClock = core.Clock()
start_prac_text = visual.TextStim(win=win, name='start_prac_text',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "prac_sti"
prac_stiClock = core.Clock()
image = visual.ImageStim(
    win=win,
    name='image', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=(0, 0), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Initialize components for Routine "prac_judge"
prac_judgeClock = core.Clock()
prac_acc = 0
prac_judge_text = visual.TextStim(win=win, name='prac_judge_text',
    text='屏幕上的点数是大于还是小于以下数字？\n\n\n10\n',
    font='Songti SC',
    pos=(0, 0.1), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
judge_2 = event.Mouse(win=win)
x, y = [None, None]
judge_2.mouseClock = core.Clock()
rect1 = visual.Line(
    win=win, name='rect1',
    start=(-[0.22,0.01][0]/2.0, 0), end=(+[0.22,0.01][0]/2.0, 0),
    ori=0.0, pos=(-0.3,-0.38),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-3.0, interpolate=True)
rect2 = visual.Line(
    win=win, name='rect2',
    start=(-[0.22,0.01][0]/2.0, 0), end=(+[0.22,0.01][0]/2.0, 0),
    ori=0.0, pos=(0.3,-0.38),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-4.0, interpolate=True)
RightButton_2 = visual.TextStim(win=win, name='RightButton_2',
    text='',
    font='Songti SC',
    pos=(0.3, -0.3), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
LeftButton_2 = visual.TextStim(win=win, name='LeftButton_2',
    text='',
    font='Songti SC',
    pos=(-0.3, -0.3), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);

# Initialize components for Routine "prac_fb"
prac_fbClock = core.Clock()
feedback = visual.TextStim(win=win, name='feedback',
    text='',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
feedback_time = 1

# Initialize components for Routine "phase_ins"
phase_insClock = core.Clock()
instru_text_2 = visual.TextStim(win=win, name='instru_text_2',
    text='接下来将开始正式游戏。\n在游戏中，请注意观察点的数量，并尽可能准确地估计。\n准备好后，请按“空格键”开始游戏。',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
instru_resp_2 = keyboard.Keyboard()

# Initialize components for Routine "first_guilt_sta"
first_guilt_staClock = core.Clock()
text_10 = visual.TextStim(win=win, name='text_10',
    text='游戏马上开始\n请做好准备！',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "guilt_pairing"
guilt_pairingClock = core.Clock()
timejitter = [round(i*0.2, 1) for i in range(60)]
#timejitter = [0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8,8.5,9,9.5,10,10.5]
ellis = ['.','..','...']
pairing_sub = visual.ImageStim(
    win=win,
    name='pairing_sub', units='norm', 
    image='pairing_sub.png', mask=None,
    ori=0.0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
pairing_wait = visual.TextStim(win=win, name='pairing_wait',
    text='正在匹配本轮玩家\n\n\n请等待',
    font='Songti SC',
    pos=(0, -0.3), height=0.07, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
Ellipsis_2 = visual.TextStim(win=win, name='Ellipsis_2',
    text='',
    font='Open Sans',
    pos=(0, -0.5), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "guilt_cue"
guilt_cueClock = core.Clock()
pairing_sub_2 = visual.ImageStim(
    win=win,
    name='pairing_sub_2', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
attention = visual.TextStim(win=win, name='attention',
    text='“点估计”任务马上开始',
    font='Songti SC',
    pos=(0, -0.3), height=1.0, wrapWidth=1.5, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "guilt_sti"
guilt_stiClock = core.Clock()
pairing_sub_3 = visual.ImageStim(
    win=win,
    name='pairing_sub_3', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
dotstipic = visual.ImageStim(
    win=win,
    name='dotstipic', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=(0, -0.4), size=dotsize,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)

# Initialize components for Routine "guilt_judge"
guilt_judgeClock = core.Clock()
pairing_sub_4 = visual.ImageStim(
    win=win,
    name='pairing_sub_4', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=0.0)
sti_text1 = visual.TextStim(win=win, name='sti_text1',
    text='',
    font='Open Sans',
    pos=(0, -0.3), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
judge = event.Mouse(win=win)
x, y = [None, None]
judge.mouseClock = core.Clock()
RightButton = visual.TextStim(win=win, name='RightButton',
    text='',
    font='Songti SC',
    pos=(0.3, -0.5), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
LeftButton = visual.TextStim(win=win, name='LeftButton',
    text='',
    font='Songti SC',
    pos=(-0.3, -0.5), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
rect1_2 = visual.Line(
    win=win, name='rect1_2',
    start=(-[0.22,0.01][0]/2.0, 0), end=(+[0.22,0.01][0]/2.0, 0),
    ori=0.0, pos=(-0.3,-0.58),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-6.0, interpolate=True)
rect2_2 = visual.Line(
    win=win, name='rect2_2',
    start=(-[0.22,0.01][0]/2.0, 0), end=(+[0.22,0.01][0]/2.0, 0),
    ori=0.0, pos=(0.3,-0.58),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-7.0, interpolate=True)
text_16 = visual.TextStim(win=win, name='text_16',
    text='屏幕上的点数是大于还是小于下方的数字？',
    font='Songti SC',
    pos=(0, -0.2), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);

# Initialize components for Routine "guilt_check_answer"
guilt_check_answerClock = core.Clock()
pairing_sub_5 = visual.ImageStim(
    win=win,
    name='pairing_sub_5', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=0.0)
wait_check_text = visual.TextStim(win=win, name='wait_check_text',
    text='检测双方选择中',
    font='Songti SC',
    pos=(0, -0.2), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
Ellipsis_3 = visual.TextStim(win=win, name='Ellipsis_3',
    text='',
    font='Open Sans',
    pos=(0, -0.3), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "warn_incomplete"
warn_incompleteClock = core.Clock()
text_14 = visual.TextStim(win=win, name='text_14',
    text='本轮回答为空，请更快做出回答！',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "warn_wrong"
warn_wrongClock = core.Clock()
text_12 = visual.TextStim(win=win, name='text_12',
    text='请集中注意力！',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "guilt_result"
guilt_resultClock = core.Clock()
pairing_sub_6 = visual.ImageStim(
    win=win,
    name='pairing_sub_6', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
result = visual.ImageStim(
    win=win,
    name='result', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=(0, -0.05), size=resultsize,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
punish_text2 = visual.TextStim(win=win, name='punish_text2',
    text='',
    font='Songti SC',
    pos=(0, -0.33), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-3.0);
FillerText = visual.TextStim(win=win, name='FillerText',
    text='无人需观看负性情绪图片',
    font='Songti SC',
    pos=(0, -0.33), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-4.0);
PuPicText = visual.TextStim(win=win, name='PuPicText',
    text='负性情绪图片呈现中',
    font='Songti SC',
    pos=(0, -0.75), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
PunishImg = visual.ImageStim(
    win=win,
    name='PunishImg', units='norm', 
    image='punishpic.png', mask=None,
    ori=0.0, pos=(0, -0.55), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)
Ellipsis = visual.TextStim(win=win, name='Ellipsis',
    text='',
    font='Open Sans',
    pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);

# Initialize components for Routine "DV_guilt"
DV_guiltClock = core.Clock()
slider_guilt = visual.Slider(win=win, name='slider_guilt',
    startValue=None, size=(1.0, 0.05), pos=(0.05, 0.2), units=None,
    labels=(0,10, 20, 30, 40, 50,60,70,80,90,100), ticks=(0,10, 20, 30, 40, 50,60,70,80,90,100), granularity=1.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=True, depth=0, readOnly=False)
text_8 = visual.TextStim(win=win, name='text_8',
    text='你在多大程度上感受到愧疚？\n（0 = 完全没有，100 = 非常强烈）\n',
    font='Songti SC',
    pos=(0, 0.45), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_guilt = keyboard.Keyboard()
text_9 = visual.TextStim(win=win, name='text_9',
    text='愧疚\n',
    font='Songti SC',
    pos=(-0.54, 0.17), height=0.056, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_17 = visual.TextStim(win=win, name='text_17',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.5), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
pairing_sub_cur_trial = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-6.0)
result_cur_trial = visual.ImageStim(
    win=win,
    name='result_cur_trial', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-7.0)
time_reminder = visual.TextStim(win=win, name='time_reminder',
    text='请尽快回答！',
    font='Songti SC',
    pos=(0, -0.6), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);

# Initialize components for Routine "DV_sharing"
DV_sharingClock = core.Clock()
share_slider = visual.Slider(win=win, name='share_slider',
    startValue=None, size=(1.0, 0.05), pos=(0, 0), units=None,
    labels=(0, 1, 2, 3, 4, 5), ticks=(0, 1, 2, 3, 4, 5), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=0, readOnly=False)
share_text = visual.TextStim(win=win, name='share_text',
    text='设想你现在有机会自己观看负性情绪图片。\n你观看的时间越长，你的伙伴需要观看的时间就越短。\n你愿意观看多长时间？\n请谨慎地做出选择，在实验的最后，\n我们会根据你的回答向你真实地呈现一张负性情绪图片。\n\n',
    font='Songti SC',
    pos=(0, 0.4), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_share = keyboard.Keyboard()
text_29 = visual.TextStim(win=win, name='text_29',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.5), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
pairing_sub_cur_trial_2 = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial_2', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-5.0)
result_cur_trial_2 = visual.ImageStim(
    win=win,
    name='result_cur_trial_2', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)
time_reminder2 = visual.TextStim(win=win, name='time_reminder2',
    text='请尽快作答！',
    font='Songti SC',
    pos=(0, -0.6), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);

# Initialize components for Routine "DV_approach_avoidance"
DV_approach_avoidanceClock = core.Clock()
slider_apology = visual.Slider(win=win, name='slider_apology',
    startValue=None, size=(1.0, 0.06), pos=(0, 0.38), units=None,
    labels=(0, 10, 20, 30, 40,50,60,70,80,90,100), ticks=(0,10, 20, 30, 40, 50,60,70,80,90,100), granularity=1.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=0, readOnly=False)
text_apology = visual.TextStim(win=win, name='text_apology',
    text='你在多大程度上愿意亲自向你的伙伴道歉？\n（0 = 完全不愿意，100 = 非常愿意）',
    font='Songti SC',
    pos=(0, 0.5), height=0.07, wrapWidth=1.8, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_apology = keyboard.Keyboard()
slider_hide = visual.Slider(win=win, name='slider_hide',
    startValue=None, size=(1.0, 0.07), pos=(0, -0.3), units=None,
    labels=(0, 10, 20, 30, 40,50,60,70,80,90,100), ticks=(0,10, 20, 30, 40, 50,60,70,80,90,100), granularity=1.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=-3, readOnly=False)
text_hide = visual.TextStim(win=win, name='text_hide',
    text='你在多大程度上愿意避免和你的伙伴产生交集？\n（0 = 完全不愿意，100 = 非常愿意）\n',
    font='Songti SC',
    pos=(0, -0.2), height=0.07, wrapWidth=1.6, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_31 = visual.TextStim(win=win, name='text_31',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.65), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
pairing_sub_cur_trial_3 = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial_3', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-7.0)
result_cur_trial_3 = visual.ImageStim(
    win=win,
    name='result_cur_trial_3', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-8.0)
time_reminder3 = visual.TextStim(win=win, name='time_reminder3',
    text='请尽快作答！',
    font='Songti SC',
    pos=(0, -0.75), height=0.05, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-9.0);

# Initialize components for Routine "DV_forgiveness"
DV_forgivenessClock = core.Clock()
slider_forgiveness = visual.Slider(win=win, name='slider_forgiveness',
    startValue=None, size=(1.0, 0.07), pos=(0, 0.3), units=None,
    labels=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), ticks=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), granularity=0.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=0, readOnly=False)
text_forgiveness = visual.TextStim(win=win, name='text_forgiveness',
    text='你认为你的伙伴有多大可能原谅你？\n（0 = 完全不可能，100 = 非常有可能）',
    font='Songti SC',
    pos=(0, 0.5), height=0.07, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_forgiveness = keyboard.Keyboard()
slider_mad = visual.Slider(win=win, name='slider_mad',
    startValue=None, size=(1.0, 0.07), pos=(0, -0.35), units=None,
    labels=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), ticks=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), granularity=0.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=-3, readOnly=False)
text_mad = visual.TextStim(win=win, name='text_mad',
    text='你认为你的伙伴对你有多你生气？\n（0 = 完全不生气，100 = 非常生气）',
    font='Songti SC',
    pos=(0, -0.2), height=0.07, wrapWidth=1.6, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_19 = visual.TextStim(win=win, name='text_19',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.65), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
pairing_sub_cur_trial_4 = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial_4', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-7.0)
result_cur_trial_4 = visual.ImageStim(
    win=win,
    name='result_cur_trial_4', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-8.0)
time_reminder4 = visual.TextStim(win=win, name='time_reminder4',
    text='请尽快作答！',
    font='Songti SC',
    pos=(0, -0.75), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-9.0);

# Initialize components for Routine "ave_img_end"
ave_img_endClock = core.Clock()
share_choice_mean = 0
text_4 = visual.TextStim(win=win, name='text_4',
    text='根据你之前对于“你愿意观看图片多长时间？”的回答，\n下面我们会向你呈现一张负性情绪图片，\n呈现时间为你所选择的时间。',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
ave_img2 = visual.ImageStim(
    win=win,
    name='ave_img2', 
    image='7360.JPG', mask=None,
    ori=0.0, pos=(0, 0), size=[1024/768*0.5, 0.5],
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
text_5 = visual.TextStim(win=win, name='text_5',
    text='负性情绪图片呈现中',
    font='Songti SC',
    pos=(0, -0.65), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "holistic_impression"
holistic_impressionClock = core.Clock()
state_complete = 0
text_20 = visual.TextStim(win=win, name='text_20',
    text='恭喜您完成了这一阶段的任务，在结束之前，\n我们想询问您对于对家的整体印象。\n请按照您脑海中设想的对家的形象回答下列问题：',
    font='Songti SC',
    pos=(0, 0.8), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
text_friendly = visual.TextStim(win=win, name='text_friendly',
    text='您设想中的对家有多友善？（1=不友善，7=友善）',
    font='Songti SC',
    pos=(0, 0.6), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
slider_friendly = visual.Slider(win=win, name='slider_friendly',
    startValue=None, size=(1.0, 0.05), pos=(0, 0.5), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-3, readOnly=False)
text_trustworthy = visual.TextStim(win=win, name='text_trustworthy',
    text='您设想的对家有多可靠？（1=不可靠，7=可靠）',
    font='Songti SC',
    pos=(0, 0.3), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
slider_trustworthy = visual.Slider(win=win, name='slider_trustworthy',
    startValue=None, size=(1.0, 0.05), pos=(0, 0.2), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-5, readOnly=False)
text_21 = visual.TextStim(win=win, name='text_21',
    text='你设想中的对家有多有能力？（1=没有能力，7=有能力）',
    font='Songti SC',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
slider_competence = visual.Slider(win=win, name='slider_competence',
    startValue=None, size=(1.0, 0.05), pos=(0, -0.3), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-7, readOnly=False)
text_22 = visual.TextStim(win=win, name='text_22',
    text='你设想的对家有多严厉？（1=不严厉，7=严厉）',
    font='Songti SC',
    pos=(0, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);
slider_critical = visual.Slider(win=win, name='slider_critical',
    startValue=None, size=(1.0, 0.05), pos=(0, -0.6), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-9, readOnly=False)
text_space = visual.TextStim(win=win, name='text_space',
    text='请按<空格键>继续',
    font='Songti SC',
    pos=(0, -0.8), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);
key_resp = keyboard.Keyboard()

# Initialize components for Routine "check_incomplete"
check_incompleteClock = core.Clock()
text_11 = visual.TextStim(win=win, name='text_11',
    text=comp_text,
    font='Open Sans',
    pos=(0, 0), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "guilt_pairing"
guilt_pairingClock = core.Clock()
timejitter = [round(i*0.2, 1) for i in range(60)]
#timejitter = [0,0.5,1,1.5,2,2.5,3,3.5,4,4.5,5,5.5,6,6.5,7,7.5,8,8.5,9,9.5,10,10.5]
ellis = ['.','..','...']
pairing_sub = visual.ImageStim(
    win=win,
    name='pairing_sub', units='norm', 
    image='pairing_sub.png', mask=None,
    ori=0.0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
pairing_wait = visual.TextStim(win=win, name='pairing_wait',
    text='正在匹配本轮玩家\n\n\n请等待',
    font='Songti SC',
    pos=(0, -0.3), height=0.07, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
Ellipsis_2 = visual.TextStim(win=win, name='Ellipsis_2',
    text='',
    font='Open Sans',
    pos=(0, -0.5), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "guilt_cue"
guilt_cueClock = core.Clock()
pairing_sub_2 = visual.ImageStim(
    win=win,
    name='pairing_sub_2', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
attention = visual.TextStim(win=win, name='attention',
    text='“点估计”任务马上开始',
    font='Songti SC',
    pos=(0, -0.3), height=1.0, wrapWidth=1.5, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# Initialize components for Routine "guilt_sti"
guilt_stiClock = core.Clock()
pairing_sub_3 = visual.ImageStim(
    win=win,
    name='pairing_sub_3', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
dotstipic = visual.ImageStim(
    win=win,
    name='dotstipic', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=(0, -0.4), size=dotsize,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)

# Initialize components for Routine "guilt_judge"
guilt_judgeClock = core.Clock()
pairing_sub_4 = visual.ImageStim(
    win=win,
    name='pairing_sub_4', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=0.0)
sti_text1 = visual.TextStim(win=win, name='sti_text1',
    text='',
    font='Open Sans',
    pos=(0, -0.3), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
judge = event.Mouse(win=win)
x, y = [None, None]
judge.mouseClock = core.Clock()
RightButton = visual.TextStim(win=win, name='RightButton',
    text='',
    font='Songti SC',
    pos=(0.3, -0.5), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
LeftButton = visual.TextStim(win=win, name='LeftButton',
    text='',
    font='Songti SC',
    pos=(-0.3, -0.5), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
rect1_2 = visual.Line(
    win=win, name='rect1_2',
    start=(-[0.22,0.01][0]/2.0, 0), end=(+[0.22,0.01][0]/2.0, 0),
    ori=0.0, pos=(-0.3,-0.58),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-6.0, interpolate=True)
rect2_2 = visual.Line(
    win=win, name='rect2_2',
    start=(-[0.22,0.01][0]/2.0, 0), end=(+[0.22,0.01][0]/2.0, 0),
    ori=0.0, pos=(0.3,-0.58),
    lineWidth=1.0,     colorSpace='rgb',  lineColor='white', fillColor='white',
    opacity=None, depth=-7.0, interpolate=True)
text_16 = visual.TextStim(win=win, name='text_16',
    text='屏幕上的点数是大于还是小于下方的数字？',
    font='Songti SC',
    pos=(0, -0.2), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);

# Initialize components for Routine "guilt_check_answer"
guilt_check_answerClock = core.Clock()
pairing_sub_5 = visual.ImageStim(
    win=win,
    name='pairing_sub_5', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=0.0)
wait_check_text = visual.TextStim(win=win, name='wait_check_text',
    text='检测双方选择中',
    font='Songti SC',
    pos=(0, -0.2), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
Ellipsis_3 = visual.TextStim(win=win, name='Ellipsis_3',
    text='',
    font='Open Sans',
    pos=(0, -0.3), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "warn_incomplete"
warn_incompleteClock = core.Clock()
text_14 = visual.TextStim(win=win, name='text_14',
    text='本轮回答为空，请更快做出回答！',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "warn_wrong"
warn_wrongClock = core.Clock()
text_12 = visual.TextStim(win=win, name='text_12',
    text='请集中注意力！',
    font='Songti SC',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "guilt_result"
guilt_resultClock = core.Clock()
pairing_sub_6 = visual.ImageStim(
    win=win,
    name='pairing_sub_6', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos, size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-1.0)
result = visual.ImageStim(
    win=win,
    name='result', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=(0, -0.05), size=resultsize,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
punish_text2 = visual.TextStim(win=win, name='punish_text2',
    text='',
    font='Songti SC',
    pos=(0, -0.33), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-3.0);
FillerText = visual.TextStim(win=win, name='FillerText',
    text='无人需观看负性情绪图片',
    font='Songti SC',
    pos=(0, -0.33), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-4.0);
PuPicText = visual.TextStim(win=win, name='PuPicText',
    text='负性情绪图片呈现中',
    font='Songti SC',
    pos=(0, -0.75), height=bottom_textsize, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
PunishImg = visual.ImageStim(
    win=win,
    name='PunishImg', units='norm', 
    image='punishpic.png', mask=None,
    ori=0.0, pos=(0, -0.55), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)
Ellipsis = visual.TextStim(win=win, name='Ellipsis',
    text='',
    font='Open Sans',
    pos=(0, -0.85), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);

# Initialize components for Routine "DV_guilt"
DV_guiltClock = core.Clock()
slider_guilt = visual.Slider(win=win, name='slider_guilt',
    startValue=None, size=(1.0, 0.05), pos=(0.05, 0.2), units=None,
    labels=(0,10, 20, 30, 40, 50,60,70,80,90,100), ticks=(0,10, 20, 30, 40, 50,60,70,80,90,100), granularity=1.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=True, depth=0, readOnly=False)
text_8 = visual.TextStim(win=win, name='text_8',
    text='你在多大程度上感受到愧疚？\n（0 = 完全没有，100 = 非常强烈）\n',
    font='Songti SC',
    pos=(0, 0.45), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_guilt = keyboard.Keyboard()
text_9 = visual.TextStim(win=win, name='text_9',
    text='愧疚\n',
    font='Songti SC',
    pos=(-0.54, 0.17), height=0.056, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_17 = visual.TextStim(win=win, name='text_17',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.5), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-5.0);
pairing_sub_cur_trial = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-6.0)
result_cur_trial = visual.ImageStim(
    win=win,
    name='result_cur_trial', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-7.0)
time_reminder = visual.TextStim(win=win, name='time_reminder',
    text='请尽快回答！',
    font='Songti SC',
    pos=(0, -0.6), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);

# Initialize components for Routine "DV_sharing"
DV_sharingClock = core.Clock()
share_slider = visual.Slider(win=win, name='share_slider',
    startValue=None, size=(1.0, 0.05), pos=(0, 0), units=None,
    labels=(0, 1, 2, 3, 4, 5), ticks=(0, 1, 2, 3, 4, 5), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=0, readOnly=False)
share_text = visual.TextStim(win=win, name='share_text',
    text='设想你现在有机会自己观看负性情绪图片。\n你观看的时间越长，你的伙伴需要观看的时间就越短。\n你愿意观看多长时间？\n请谨慎地做出选择，在实验的最后，\n我们会根据你的回答向你真实地呈现一张负性情绪图片。\n\n',
    font='Songti SC',
    pos=(0, 0.4), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_share = keyboard.Keyboard()
text_29 = visual.TextStim(win=win, name='text_29',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.5), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
pairing_sub_cur_trial_2 = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial_2', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-5.0)
result_cur_trial_2 = visual.ImageStim(
    win=win,
    name='result_cur_trial_2', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)
time_reminder2 = visual.TextStim(win=win, name='time_reminder2',
    text='请尽快作答！',
    font='Songti SC',
    pos=(0, -0.6), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-7.0);

# Initialize components for Routine "DV_approach_avoidance"
DV_approach_avoidanceClock = core.Clock()
slider_apology = visual.Slider(win=win, name='slider_apology',
    startValue=None, size=(1.0, 0.06), pos=(0, 0.38), units=None,
    labels=(0, 10, 20, 30, 40,50,60,70,80,90,100), ticks=(0,10, 20, 30, 40, 50,60,70,80,90,100), granularity=1.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=0, readOnly=False)
text_apology = visual.TextStim(win=win, name='text_apology',
    text='你在多大程度上愿意亲自向你的伙伴道歉？\n（0 = 完全不愿意，100 = 非常愿意）',
    font='Songti SC',
    pos=(0, 0.5), height=0.07, wrapWidth=1.8, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_apology = keyboard.Keyboard()
slider_hide = visual.Slider(win=win, name='slider_hide',
    startValue=None, size=(1.0, 0.07), pos=(0, -0.3), units=None,
    labels=(0, 10, 20, 30, 40,50,60,70,80,90,100), ticks=(0,10, 20, 30, 40, 50,60,70,80,90,100), granularity=1.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=-3, readOnly=False)
text_hide = visual.TextStim(win=win, name='text_hide',
    text='你在多大程度上愿意避免和你的伙伴产生交集？\n（0 = 完全不愿意，100 = 非常愿意）\n',
    font='Songti SC',
    pos=(0, -0.2), height=0.07, wrapWidth=1.6, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_31 = visual.TextStim(win=win, name='text_31',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.65), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
pairing_sub_cur_trial_3 = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial_3', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-7.0)
result_cur_trial_3 = visual.ImageStim(
    win=win,
    name='result_cur_trial_3', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-8.0)
time_reminder3 = visual.TextStim(win=win, name='time_reminder3',
    text='请尽快作答！',
    font='Songti SC',
    pos=(0, -0.75), height=0.05, wrapWidth=None, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-9.0);

# Initialize components for Routine "DV_forgiveness"
DV_forgivenessClock = core.Clock()
slider_forgiveness = visual.Slider(win=win, name='slider_forgiveness',
    startValue=None, size=(1.0, 0.07), pos=(0, 0.3), units=None,
    labels=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), ticks=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), granularity=0.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=0, readOnly=False)
text_forgiveness = visual.TextStim(win=win, name='text_forgiveness',
    text='你认为你的伙伴有多大可能原谅你？\n（0 = 完全不可能，100 = 非常有可能）',
    font='Songti SC',
    pos=(0, 0.5), height=0.07, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
key_forgiveness = keyboard.Keyboard()
slider_mad = visual.Slider(win=win, name='slider_mad',
    startValue=None, size=(1.0, 0.07), pos=(0, -0.35), units=None,
    labels=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), ticks=(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100), granularity=0.0,
    style='slider', styleTweaks=(), opacity=None,
    color='white', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Open Sans', labelHeight=0.05,
    flip=False, depth=-3, readOnly=False)
text_mad = visual.TextStim(win=win, name='text_mad',
    text='你认为你的伙伴对你有多你生气？\n（0 = 完全不生气，100 = 非常生气）',
    font='Songti SC',
    pos=(0, -0.2), height=0.07, wrapWidth=1.6, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
text_19 = visual.TextStim(win=win, name='text_19',
    text='请按“空格键”确认继续',
    font='Songti SC',
    pos=(0, -0.65), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
pairing_sub_cur_trial_4 = visual.ImageStim(
    win=win,
    name='pairing_sub_cur_trial_4', units='norm', 
    image='Punish_Pair.png', mask=None,
    ori=0.0, pos=pairpos_DV, size=pairsize3,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=512.0, interpolate=True, depth=-7.0)
result_cur_trial_4 = visual.ImageStim(
    win=win,
    name='result_cur_trial_4', units='norm', 
    image='sin', mask=None,
    ori=0.0, pos=resultpos_DV, size=resultsize_DV,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-8.0)
time_reminder4 = visual.TextStim(win=win, name='time_reminder4',
    text='请尽快作答！',
    font='Songti SC',
    pos=(0, -0.75), height=0.05, wrapWidth=1.3, ori=0.0, 
    color='red', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-9.0);

# Initialize components for Routine "check_redo"
check_redoClock = core.Clock()

# Initialize components for Routine "ave_img_end"
ave_img_endClock = core.Clock()
share_choice_mean = 0
text_4 = visual.TextStim(win=win, name='text_4',
    text='根据你之前对于“你愿意观看图片多长时间？”的回答，\n下面我们会向你呈现一张负性情绪图片，\n呈现时间为你所选择的时间。',
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
ave_img2 = visual.ImageStim(
    win=win,
    name='ave_img2', 
    image='7360.JPG', mask=None,
    ori=0.0, pos=(0, 0), size=[1024/768*0.5, 0.5],
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
text_5 = visual.TextStim(win=win, name='text_5',
    text='负性情绪图片呈现中',
    font='Songti SC',
    pos=(0, -0.65), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# Initialize components for Routine "holistic_impression"
holistic_impressionClock = core.Clock()
state_complete = 0
text_20 = visual.TextStim(win=win, name='text_20',
    text='恭喜您完成了这一阶段的任务，在结束之前，\n我们想询问您对于对家的整体印象。\n请按照您脑海中设想的对家的形象回答下列问题：',
    font='Songti SC',
    pos=(0, 0.8), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
text_friendly = visual.TextStim(win=win, name='text_friendly',
    text='您设想中的对家有多友善？（1=不友善，7=友善）',
    font='Songti SC',
    pos=(0, 0.6), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
slider_friendly = visual.Slider(win=win, name='slider_friendly',
    startValue=None, size=(1.0, 0.05), pos=(0, 0.5), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-3, readOnly=False)
text_trustworthy = visual.TextStim(win=win, name='text_trustworthy',
    text='您设想的对家有多可靠？（1=不可靠，7=可靠）',
    font='Songti SC',
    pos=(0, 0.3), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
slider_trustworthy = visual.Slider(win=win, name='slider_trustworthy',
    startValue=None, size=(1.0, 0.05), pos=(0, 0.2), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-5, readOnly=False)
text_21 = visual.TextStim(win=win, name='text_21',
    text='你设想中的对家有多有能力？（1=没有能力，7=有能力）',
    font='Songti SC',
    pos=(0, -0.2), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-6.0);
slider_competence = visual.Slider(win=win, name='slider_competence',
    startValue=None, size=(1.0, 0.05), pos=(0, -0.3), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-7, readOnly=False)
text_22 = visual.TextStim(win=win, name='text_22',
    text='你设想的对家有多严厉？（1=不严厉，7=严厉）',
    font='Songti SC',
    pos=(0, -0.5), height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-8.0);
slider_critical = visual.Slider(win=win, name='slider_critical',
    startValue=None, size=(1.0, 0.05), pos=(0, -0.6), units=None,
    labels=(1, 2, 3, 4, 5, 6, 7), ticks=(1, 2, 3, 4, 5, 6, 7), granularity=0.0,
    style='rating', styleTweaks=(), opacity=None,
    color='LightGray', fillColor='Red', borderColor='White', colorSpace='rgb',
    font='Songti SC', labelHeight=0.05,
    flip=False, depth=-9, readOnly=False)
text_space = visual.TextStim(win=win, name='text_space',
    text='请按<空格键>继续',
    font='Songti SC',
    pos=(0, -0.8), height=0.05, wrapWidth=1.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-10.0);
key_resp = keyboard.Keyboard()

# Initialize components for Routine "end"
endClock = core.Clock()
text_13 = visual.TextStim(win=win, name='text_13',
    text=comp_text,
    font='Songti SC',
    pos=(0, 0), height=0.07, wrapWidth=1.5, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "PreDef"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
PreDefComponents = []
for thisComponent in PreDefComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
PreDefClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "PreDef"-------
while continueRoutine:
    # get current time
    t = PreDefClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=PreDefClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in PreDefComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "PreDef"-------
for thisComponent in PreDefComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "PreDef" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Welcome"-------
continueRoutine = True
# update component parameters for each repeat
pre_instru_resp_2.keys = []
pre_instru_resp_2.rt = []
_pre_instru_resp_2_allKeys = []
# keep track of which components have finished
WelcomeComponents = [welcome, pre_instru_resp_2, press_space]
for thisComponent in WelcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
WelcomeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Welcome"-------
while continueRoutine:
    # get current time
    t = WelcomeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=WelcomeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welcome* updates
    if welcome.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        welcome.frameNStart = frameN  # exact frame index
        welcome.tStart = t  # local t and not account for scr refresh
        welcome.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome, 'tStartRefresh')  # time at next scr refresh
        welcome.setAutoDraw(True)
    
    # *pre_instru_resp_2* updates
    waitOnFlip = False
    if pre_instru_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        pre_instru_resp_2.frameNStart = frameN  # exact frame index
        pre_instru_resp_2.tStart = t  # local t and not account for scr refresh
        pre_instru_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(pre_instru_resp_2, 'tStartRefresh')  # time at next scr refresh
        pre_instru_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(pre_instru_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(pre_instru_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if pre_instru_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = pre_instru_resp_2.getKeys(keyList=['space', 't'], waitRelease=False)
        _pre_instru_resp_2_allKeys.extend(theseKeys)
        if len(_pre_instru_resp_2_allKeys):
            pre_instru_resp_2.keys = _pre_instru_resp_2_allKeys[-1].name  # just the last key pressed
            pre_instru_resp_2.rt = _pre_instru_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *press_space* updates
    if press_space.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        press_space.frameNStart = frameN  # exact frame index
        press_space.tStart = t  # local t and not account for scr refresh
        press_space.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(press_space, 'tStartRefresh')  # time at next scr refresh
        press_space.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in WelcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Welcome"-------
for thisComponent in WelcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('welcome.started', welcome.tStartRefresh)
thisExp.addData('welcome.stopped', welcome.tStopRefresh)
# check responses
if pre_instru_resp_2.keys in ['', [], None]:  # No response was made
    pre_instru_resp_2.keys = None
thisExp.addData('pre_instru_resp_2.keys',pre_instru_resp_2.keys)
if pre_instru_resp_2.keys != None:  # we had a response
    thisExp.addData('pre_instru_resp_2.rt', pre_instru_resp_2.rt)
thisExp.addData('pre_instru_resp_2.started', pre_instru_resp_2.tStartRefresh)
thisExp.addData('pre_instru_resp_2.stopped', pre_instru_resp_2.tStopRefresh)
thisExp.nextEntry()
thisExp.addData('press_space.started', press_space.tStartRefresh)
thisExp.addData('press_space.stopped', press_space.tStopRefresh)
if pre_instru_resp_2.keys not in ['', [], None]:
    if pre_instru_resp_2.keys == 't':
        testing = 1
    else:
        testing = 0
else:
    testing = 0

print("Is test? ", testing)
# the Routine "Welcome" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "check_testing"-------
continueRoutine = True
# update component parameters for each repeat
# for testing
if testing:
    chooserow = chooserow[::10]
    print("Test trials:")
    print(chooserow)
# keep track of which components have finished
check_testingComponents = []
for thisComponent in check_testingComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
check_testingClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "check_testing"-------
while continueRoutine:
    # get current time
    t = check_testingClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=check_testingClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in check_testingComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "check_testing"-------
for thisComponent in check_testingComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "check_testing" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials_2 = data.TrialHandler(nReps=100.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='trials_2')
thisExp.addLoop(trials_2)  # add the loop to the experiment
thisTrial_2 = trials_2.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
if thisTrial_2 != None:
    for paramName in thisTrial_2:
        exec('{} = thisTrial_2[paramName]'.format(paramName))

for thisTrial_2 in trials_2:
    currentLoop = trials_2
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
    if thisTrial_2 != None:
        for paramName in thisTrial_2:
            exec('{} = thisTrial_2[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "ins_1"-------
    continueRoutine = True
    # update component parameters for each repeat
    pre_instru_resp_3.keys = []
    pre_instru_resp_3.rt = []
    _pre_instru_resp_3_allKeys = []
    # keep track of which components have finished
    ins_1Components = [ins1, pre_instru_resp_3, press_space1]
    for thisComponent in ins_1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_1"-------
    while continueRoutine:
        # get current time
        t = ins_1Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_1Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ins1* updates
        if ins1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ins1.frameNStart = frameN  # exact frame index
            ins1.tStart = t  # local t and not account for scr refresh
            ins1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ins1, 'tStartRefresh')  # time at next scr refresh
            ins1.setAutoDraw(True)
        
        # *pre_instru_resp_3* updates
        waitOnFlip = False
        if pre_instru_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pre_instru_resp_3.frameNStart = frameN  # exact frame index
            pre_instru_resp_3.tStart = t  # local t and not account for scr refresh
            pre_instru_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pre_instru_resp_3, 'tStartRefresh')  # time at next scr refresh
            pre_instru_resp_3.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(pre_instru_resp_3.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(pre_instru_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if pre_instru_resp_3.status == STARTED and not waitOnFlip:
            theseKeys = pre_instru_resp_3.getKeys(keyList=['space'], waitRelease=False)
            _pre_instru_resp_3_allKeys.extend(theseKeys)
            if len(_pre_instru_resp_3_allKeys):
                pre_instru_resp_3.keys = _pre_instru_resp_3_allKeys[-1].name  # just the last key pressed
                pre_instru_resp_3.rt = _pre_instru_resp_3_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *press_space1* updates
        if press_space1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            press_space1.frameNStart = frameN  # exact frame index
            press_space1.tStart = t  # local t and not account for scr refresh
            press_space1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(press_space1, 'tStartRefresh')  # time at next scr refresh
            press_space1.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_1"-------
    for thisComponent in ins_1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('ins1.started', ins1.tStartRefresh)
    trials_2.addData('ins1.stopped', ins1.tStopRefresh)
    # check responses
    if pre_instru_resp_3.keys in ['', [], None]:  # No response was made
        pre_instru_resp_3.keys = None
    trials_2.addData('pre_instru_resp_3.keys',pre_instru_resp_3.keys)
    if pre_instru_resp_3.keys != None:  # we had a response
        trials_2.addData('pre_instru_resp_3.rt', pre_instru_resp_3.rt)
    trials_2.addData('pre_instru_resp_3.started', pre_instru_resp_3.tStartRefresh)
    trials_2.addData('pre_instru_resp_3.stopped', pre_instru_resp_3.tStopRefresh)
    trials_2.addData('press_space1.started', press_space1.tStartRefresh)
    trials_2.addData('press_space1.stopped', press_space1.tStopRefresh)
    # the Routine "ins_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins__2"-------
    continueRoutine = True
    # update component parameters for each repeat
    pre_instru_resp_9.keys = []
    pre_instru_resp_9.rt = []
    _pre_instru_resp_9_allKeys = []
    # keep track of which components have finished
    ins__2Components = [ins1_4, pre_instru_resp_9, press_space1_4]
    for thisComponent in ins__2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins__2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins__2"-------
    while continueRoutine:
        # get current time
        t = ins__2Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins__2Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ins1_4* updates
        if ins1_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ins1_4.frameNStart = frameN  # exact frame index
            ins1_4.tStart = t  # local t and not account for scr refresh
            ins1_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ins1_4, 'tStartRefresh')  # time at next scr refresh
            ins1_4.setAutoDraw(True)
        
        # *pre_instru_resp_9* updates
        waitOnFlip = False
        if pre_instru_resp_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pre_instru_resp_9.frameNStart = frameN  # exact frame index
            pre_instru_resp_9.tStart = t  # local t and not account for scr refresh
            pre_instru_resp_9.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pre_instru_resp_9, 'tStartRefresh')  # time at next scr refresh
            pre_instru_resp_9.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(pre_instru_resp_9.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(pre_instru_resp_9.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if pre_instru_resp_9.status == STARTED and not waitOnFlip:
            theseKeys = pre_instru_resp_9.getKeys(keyList=['space'], waitRelease=False)
            _pre_instru_resp_9_allKeys.extend(theseKeys)
            if len(_pre_instru_resp_9_allKeys):
                pre_instru_resp_9.keys = _pre_instru_resp_9_allKeys[-1].name  # just the last key pressed
                pre_instru_resp_9.rt = _pre_instru_resp_9_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *press_space1_4* updates
        if press_space1_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            press_space1_4.frameNStart = frameN  # exact frame index
            press_space1_4.tStart = t  # local t and not account for scr refresh
            press_space1_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(press_space1_4, 'tStartRefresh')  # time at next scr refresh
            press_space1_4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins__2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins__2"-------
    for thisComponent in ins__2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('ins1_4.started', ins1_4.tStartRefresh)
    trials_2.addData('ins1_4.stopped', ins1_4.tStopRefresh)
    # check responses
    if pre_instru_resp_9.keys in ['', [], None]:  # No response was made
        pre_instru_resp_9.keys = None
    trials_2.addData('pre_instru_resp_9.keys',pre_instru_resp_9.keys)
    if pre_instru_resp_9.keys != None:  # we had a response
        trials_2.addData('pre_instru_resp_9.rt', pre_instru_resp_9.rt)
    trials_2.addData('pre_instru_resp_9.started', pre_instru_resp_9.tStartRefresh)
    trials_2.addData('pre_instru_resp_9.stopped', pre_instru_resp_9.tStopRefresh)
    trials_2.addData('press_space1_4.started', press_space1_4.tStartRefresh)
    trials_2.addData('press_space1_4.stopped', press_space1_4.tStopRefresh)
    # the Routine "ins__2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_3"-------
    continueRoutine = True
    # update component parameters for each repeat
    pre_instru_resp_8.keys = []
    pre_instru_resp_8.rt = []
    _pre_instru_resp_8_allKeys = []
    # keep track of which components have finished
    ins_3Components = [ins1_3, pre_instru_resp_8, press_space1_3]
    for thisComponent in ins_3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_3"-------
    while continueRoutine:
        # get current time
        t = ins_3Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_3Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ins1_3* updates
        if ins1_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ins1_3.frameNStart = frameN  # exact frame index
            ins1_3.tStart = t  # local t and not account for scr refresh
            ins1_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ins1_3, 'tStartRefresh')  # time at next scr refresh
            ins1_3.setAutoDraw(True)
        
        # *pre_instru_resp_8* updates
        waitOnFlip = False
        if pre_instru_resp_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pre_instru_resp_8.frameNStart = frameN  # exact frame index
            pre_instru_resp_8.tStart = t  # local t and not account for scr refresh
            pre_instru_resp_8.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pre_instru_resp_8, 'tStartRefresh')  # time at next scr refresh
            pre_instru_resp_8.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(pre_instru_resp_8.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(pre_instru_resp_8.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if pre_instru_resp_8.status == STARTED and not waitOnFlip:
            theseKeys = pre_instru_resp_8.getKeys(keyList=['space'], waitRelease=False)
            _pre_instru_resp_8_allKeys.extend(theseKeys)
            if len(_pre_instru_resp_8_allKeys):
                pre_instru_resp_8.keys = _pre_instru_resp_8_allKeys[-1].name  # just the last key pressed
                pre_instru_resp_8.rt = _pre_instru_resp_8_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *press_space1_3* updates
        if press_space1_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            press_space1_3.frameNStart = frameN  # exact frame index
            press_space1_3.tStart = t  # local t and not account for scr refresh
            press_space1_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(press_space1_3, 'tStartRefresh')  # time at next scr refresh
            press_space1_3.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_3"-------
    for thisComponent in ins_3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('ins1_3.started', ins1_3.tStartRefresh)
    trials_2.addData('ins1_3.stopped', ins1_3.tStopRefresh)
    # check responses
    if pre_instru_resp_8.keys in ['', [], None]:  # No response was made
        pre_instru_resp_8.keys = None
    trials_2.addData('pre_instru_resp_8.keys',pre_instru_resp_8.keys)
    if pre_instru_resp_8.keys != None:  # we had a response
        trials_2.addData('pre_instru_resp_8.rt', pre_instru_resp_8.rt)
    trials_2.addData('pre_instru_resp_8.started', pre_instru_resp_8.tStartRefresh)
    trials_2.addData('pre_instru_resp_8.stopped', pre_instru_resp_8.tStopRefresh)
    trials_2.addData('press_space1_3.started', press_space1_3.tStartRefresh)
    trials_2.addData('press_space1_3.stopped', press_space1_3.tStopRefresh)
    # the Routine "ins_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_4"-------
    continueRoutine = True
    # update component parameters for each repeat
    pre_instru_resp_4.keys = []
    pre_instru_resp_4.rt = []
    _pre_instru_resp_4_allKeys = []
    # keep track of which components have finished
    ins_4Components = [ins2, pre_instru_resp_4, press_space2, Rule]
    for thisComponent in ins_4Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_4Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_4"-------
    while continueRoutine:
        # get current time
        t = ins_4Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_4Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ins2* updates
        if ins2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ins2.frameNStart = frameN  # exact frame index
            ins2.tStart = t  # local t and not account for scr refresh
            ins2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ins2, 'tStartRefresh')  # time at next scr refresh
            ins2.setAutoDraw(True)
        
        # *pre_instru_resp_4* updates
        waitOnFlip = False
        if pre_instru_resp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pre_instru_resp_4.frameNStart = frameN  # exact frame index
            pre_instru_resp_4.tStart = t  # local t and not account for scr refresh
            pre_instru_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pre_instru_resp_4, 'tStartRefresh')  # time at next scr refresh
            pre_instru_resp_4.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(pre_instru_resp_4.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(pre_instru_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if pre_instru_resp_4.status == STARTED and not waitOnFlip:
            theseKeys = pre_instru_resp_4.getKeys(keyList=['space'], waitRelease=False)
            _pre_instru_resp_4_allKeys.extend(theseKeys)
            if len(_pre_instru_resp_4_allKeys):
                pre_instru_resp_4.keys = _pre_instru_resp_4_allKeys[-1].name  # just the last key pressed
                pre_instru_resp_4.rt = _pre_instru_resp_4_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *press_space2* updates
        if press_space2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            press_space2.frameNStart = frameN  # exact frame index
            press_space2.tStart = t  # local t and not account for scr refresh
            press_space2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(press_space2, 'tStartRefresh')  # time at next scr refresh
            press_space2.setAutoDraw(True)
        
        # *Rule* updates
        if Rule.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Rule.frameNStart = frameN  # exact frame index
            Rule.tStart = t  # local t and not account for scr refresh
            Rule.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Rule, 'tStartRefresh')  # time at next scr refresh
            Rule.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_4Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_4"-------
    for thisComponent in ins_4Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('ins2.started', ins2.tStartRefresh)
    trials_2.addData('ins2.stopped', ins2.tStopRefresh)
    # check responses
    if pre_instru_resp_4.keys in ['', [], None]:  # No response was made
        pre_instru_resp_4.keys = None
    trials_2.addData('pre_instru_resp_4.keys',pre_instru_resp_4.keys)
    if pre_instru_resp_4.keys != None:  # we had a response
        trials_2.addData('pre_instru_resp_4.rt', pre_instru_resp_4.rt)
    trials_2.addData('pre_instru_resp_4.started', pre_instru_resp_4.tStartRefresh)
    trials_2.addData('pre_instru_resp_4.stopped', pre_instru_resp_4.tStopRefresh)
    trials_2.addData('press_space2.started', press_space2.tStartRefresh)
    trials_2.addData('press_space2.stopped', press_space2.tStopRefresh)
    trials_2.addData('Rule.started', Rule.tStartRefresh)
    trials_2.addData('Rule.stopped', Rule.tStopRefresh)
    # the Routine "ins_4" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "aver_ima"-------
    continueRoutine = True
    routineTimer.add(5.000000)
    # update component parameters for each repeat
    # keep track of which components have finished
    aver_imaComponents = [text_18, aver_image]
    for thisComponent in aver_imaComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    aver_imaClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "aver_ima"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = aver_imaClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=aver_imaClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_18* updates
        if text_18.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_18.frameNStart = frameN  # exact frame index
            text_18.tStart = t  # local t and not account for scr refresh
            text_18.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_18, 'tStartRefresh')  # time at next scr refresh
            text_18.setAutoDraw(True)
        if text_18.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_18.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                text_18.tStop = t  # not accounting for scr refresh
                text_18.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_18, 'tStopRefresh')  # time at next scr refresh
                text_18.setAutoDraw(False)
        
        # *aver_image* updates
        if aver_image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            aver_image.frameNStart = frameN  # exact frame index
            aver_image.tStart = t  # local t and not account for scr refresh
            aver_image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(aver_image, 'tStartRefresh')  # time at next scr refresh
            aver_image.setAutoDraw(True)
        if aver_image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > aver_image.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                aver_image.tStop = t  # not accounting for scr refresh
                aver_image.frameNStop = frameN  # exact frame index
                win.timeOnFlip(aver_image, 'tStopRefresh')  # time at next scr refresh
                aver_image.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in aver_imaComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "aver_ima"-------
    for thisComponent in aver_imaComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('text_18.started', text_18.tStartRefresh)
    trials_2.addData('text_18.stopped', text_18.tStopRefresh)
    trials_2.addData('aver_image.started', aver_image.tStartRefresh)
    trials_2.addData('aver_image.stopped', aver_image.tStopRefresh)
    
    # ------Prepare to start Routine "ins_5"-------
    continueRoutine = True
    # update component parameters for each repeat
    pre_instru_resp_5.keys = []
    pre_instru_resp_5.rt = []
    _pre_instru_resp_5_allKeys = []
    # keep track of which components have finished
    ins_5Components = [ins3, pre_instru_resp_5]
    for thisComponent in ins_5Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_5Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_5"-------
    while continueRoutine:
        # get current time
        t = ins_5Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_5Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ins3* updates
        if ins3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ins3.frameNStart = frameN  # exact frame index
            ins3.tStart = t  # local t and not account for scr refresh
            ins3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ins3, 'tStartRefresh')  # time at next scr refresh
            ins3.setAutoDraw(True)
        
        # *pre_instru_resp_5* updates
        waitOnFlip = False
        if pre_instru_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pre_instru_resp_5.frameNStart = frameN  # exact frame index
            pre_instru_resp_5.tStart = t  # local t and not account for scr refresh
            pre_instru_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pre_instru_resp_5, 'tStartRefresh')  # time at next scr refresh
            pre_instru_resp_5.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(pre_instru_resp_5.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(pre_instru_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if pre_instru_resp_5.status == STARTED and not waitOnFlip:
            theseKeys = pre_instru_resp_5.getKeys(keyList=['space'], waitRelease=False)
            _pre_instru_resp_5_allKeys.extend(theseKeys)
            if len(_pre_instru_resp_5_allKeys):
                pre_instru_resp_5.keys = _pre_instru_resp_5_allKeys[-1].name  # just the last key pressed
                pre_instru_resp_5.rt = _pre_instru_resp_5_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_5Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_5"-------
    for thisComponent in ins_5Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('ins3.started', ins3.tStartRefresh)
    trials_2.addData('ins3.stopped', ins3.tStopRefresh)
    # check responses
    if pre_instru_resp_5.keys in ['', [], None]:  # No response was made
        pre_instru_resp_5.keys = None
    trials_2.addData('pre_instru_resp_5.keys',pre_instru_resp_5.keys)
    if pre_instru_resp_5.keys != None:  # we had a response
        trials_2.addData('pre_instru_resp_5.rt', pre_instru_resp_5.rt)
    trials_2.addData('pre_instru_resp_5.started', pre_instru_resp_5.tStartRefresh)
    trials_2.addData('pre_instru_resp_5.stopped', pre_instru_resp_5.tStopRefresh)
    # the Routine "ins_5" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_6"-------
    continueRoutine = True
    # update component parameters for each repeat
    pre_instru_resp_6.keys = []
    pre_instru_resp_6.rt = []
    _pre_instru_resp_6_allKeys = []
    # keep track of which components have finished
    ins_6Components = [ins3_2, pre_instru_resp_6]
    for thisComponent in ins_6Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_6Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_6"-------
    while continueRoutine:
        # get current time
        t = ins_6Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_6Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ins3_2* updates
        if ins3_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ins3_2.frameNStart = frameN  # exact frame index
            ins3_2.tStart = t  # local t and not account for scr refresh
            ins3_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ins3_2, 'tStartRefresh')  # time at next scr refresh
            ins3_2.setAutoDraw(True)
        
        # *pre_instru_resp_6* updates
        waitOnFlip = False
        if pre_instru_resp_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pre_instru_resp_6.frameNStart = frameN  # exact frame index
            pre_instru_resp_6.tStart = t  # local t and not account for scr refresh
            pre_instru_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pre_instru_resp_6, 'tStartRefresh')  # time at next scr refresh
            pre_instru_resp_6.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(pre_instru_resp_6.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(pre_instru_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if pre_instru_resp_6.status == STARTED and not waitOnFlip:
            theseKeys = pre_instru_resp_6.getKeys(keyList=['space'], waitRelease=False)
            _pre_instru_resp_6_allKeys.extend(theseKeys)
            if len(_pre_instru_resp_6_allKeys):
                pre_instru_resp_6.keys = _pre_instru_resp_6_allKeys[-1].name  # just the last key pressed
                pre_instru_resp_6.rt = _pre_instru_resp_6_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_6Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_6"-------
    for thisComponent in ins_6Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('ins3_2.started', ins3_2.tStartRefresh)
    trials_2.addData('ins3_2.stopped', ins3_2.tStopRefresh)
    # check responses
    if pre_instru_resp_6.keys in ['', [], None]:  # No response was made
        pre_instru_resp_6.keys = None
    trials_2.addData('pre_instru_resp_6.keys',pre_instru_resp_6.keys)
    if pre_instru_resp_6.keys != None:  # we had a response
        trials_2.addData('pre_instru_resp_6.rt', pre_instru_resp_6.rt)
    trials_2.addData('pre_instru_resp_6.started', pre_instru_resp_6.tStartRefresh)
    trials_2.addData('pre_instru_resp_6.stopped', pre_instru_resp_6.tStopRefresh)
    # the Routine "ins_6" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Check_1"-------
    continueRoutine = True
    # update component parameters for each repeat
    # if testing
    if testing:
        continueRoutine = False
    
    wrong=0
    key_resp_3.keys = []
    key_resp_3.rt = []
    _key_resp_3_allKeys = []
    # keep track of which components have finished
    Check_1Components = [check1, a1, key_resp_3]
    for thisComponent in Check_1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Check_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Check_1"-------
    while continueRoutine:
        # get current time
        t = Check_1Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Check_1Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *check1* updates
        if check1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            check1.frameNStart = frameN  # exact frame index
            check1.tStart = t  # local t and not account for scr refresh
            check1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(check1, 'tStartRefresh')  # time at next scr refresh
            check1.setAutoDraw(True)
        
        # *a1* updates
        if a1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            a1.frameNStart = frameN  # exact frame index
            a1.tStart = t  # local t and not account for scr refresh
            a1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(a1, 'tStartRefresh')  # time at next scr refresh
            a1.setAutoDraw(True)
        
        # *key_resp_3* updates
        waitOnFlip = False
        if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_3.frameNStart = frameN  # exact frame index
            key_resp_3.tStart = t  # local t and not account for scr refresh
            key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
            key_resp_3.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_3.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_3.getKeys(keyList=['1', '2', '3', '4'], waitRelease=False)
            _key_resp_3_allKeys.extend(theseKeys)
            if len(_key_resp_3_allKeys):
                key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
                key_resp_3.rt = _key_resp_3_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Check_1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Check_1"-------
    for thisComponent in Check_1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('check1.started', check1.tStartRefresh)
    trials_2.addData('check1.stopped', check1.tStopRefresh)
    trials_2.addData('a1.started', a1.tStartRefresh)
    trials_2.addData('a1.stopped', a1.tStopRefresh)
    if key_resp_3.keys == "3":
        feedback1_text = u'正确'
        feedback1_text_color = 'green'
    else:
        feedback1_text = u'错误'
        feedback1_text_color = 'red'
        wrong=wrong+1
    # check responses
    if key_resp_3.keys in ['', [], None]:  # No response was made
        key_resp_3.keys = None
    trials_2.addData('key_resp_3.keys',key_resp_3.keys)
    if key_resp_3.keys != None:  # we had a response
        trials_2.addData('key_resp_3.rt', key_resp_3.rt)
    trials_2.addData('key_resp_3.started', key_resp_3.tStartRefresh)
    trials_2.addData('key_resp_3.stopped', key_resp_3.tStopRefresh)
    # the Routine "Check_1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_fb"-------
    continueRoutine = True
    # update component parameters for each repeat
    feedback_2.setColor(feedback1_text_color, colorSpace='rgb')
    feedback_2.setText(feedback1_text)
    # if testing
    if testing:
        continueRoutine = False
    # keep track of which components have finished
    ins_fbComponents = [feedback_2]
    for thisComponent in ins_fbComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_fbClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_fb"-------
    while continueRoutine:
        # get current time
        t = ins_fbClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_fbClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedback_2* updates
        if feedback_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            feedback_2.frameNStart = frameN  # exact frame index
            feedback_2.tStart = t  # local t and not account for scr refresh
            feedback_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(feedback_2, 'tStartRefresh')  # time at next scr refresh
            feedback_2.setAutoDraw(True)
        if feedback_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > feedback_2.tStartRefresh + feedback_time-frameTolerance:
                # keep track of stop time/frame for later
                feedback_2.tStop = t  # not accounting for scr refresh
                feedback_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(feedback_2, 'tStopRefresh')  # time at next scr refresh
                feedback_2.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_fbComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_fb"-------
    for thisComponent in ins_fbComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "ins_fb" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Check_2"-------
    continueRoutine = True
    # update component parameters for each repeat
    b1.setPos(k1)
    b1.alignText='left'
    
    # if testing
    if testing:
        continueRoutine = False
    key_resp_4.keys = []
    key_resp_4.rt = []
    _key_resp_4_allKeys = []
    # keep track of which components have finished
    Check_2Components = [check2, b1, key_resp_4]
    for thisComponent in Check_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Check_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Check_2"-------
    while continueRoutine:
        # get current time
        t = Check_2Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Check_2Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *check2* updates
        if check2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            check2.frameNStart = frameN  # exact frame index
            check2.tStart = t  # local t and not account for scr refresh
            check2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(check2, 'tStartRefresh')  # time at next scr refresh
            check2.setAutoDraw(True)
        
        # *b1* updates
        if b1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            b1.frameNStart = frameN  # exact frame index
            b1.tStart = t  # local t and not account for scr refresh
            b1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(b1, 'tStartRefresh')  # time at next scr refresh
            b1.setAutoDraw(True)
        
        # *key_resp_4* updates
        waitOnFlip = False
        if key_resp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_4.frameNStart = frameN  # exact frame index
            key_resp_4.tStart = t  # local t and not account for scr refresh
            key_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
            key_resp_4.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_4.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_4.getKeys(keyList=['1', '2', '3'], waitRelease=False)
            _key_resp_4_allKeys.extend(theseKeys)
            if len(_key_resp_4_allKeys):
                key_resp_4.keys = _key_resp_4_allKeys[-1].name  # just the last key pressed
                key_resp_4.rt = _key_resp_4_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Check_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Check_2"-------
    for thisComponent in Check_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('check2.started', check2.tStartRefresh)
    trials_2.addData('check2.stopped', check2.tStopRefresh)
    trials_2.addData('b1.started', b1.tStartRefresh)
    trials_2.addData('b1.stopped', b1.tStopRefresh)
    # check responses
    if key_resp_4.keys in ['', [], None]:  # No response was made
        key_resp_4.keys = None
    trials_2.addData('key_resp_4.keys',key_resp_4.keys)
    if key_resp_4.keys != None:  # we had a response
        trials_2.addData('key_resp_4.rt', key_resp_4.rt)
    trials_2.addData('key_resp_4.started', key_resp_4.tStartRefresh)
    trials_2.addData('key_resp_4.stopped', key_resp_4.tStopRefresh)
    if key_resp_4.keys == "1":
        feedback2_text = u'正确'
        feedback2_text_color = 'green'
    else:
        feedback2_text = u'错误'
        feedback2_text_color = 'red'
        wrong=wrong+1
    # the Routine "Check_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_fb_2"-------
    continueRoutine = True
    # update component parameters for each repeat
    feedback_3.setColor(feedback2_text_color, colorSpace='rgb')
    feedback_3.setText(feedback2_text)
    # if testing
    if testing:
        continueRoutine = False
    # keep track of which components have finished
    ins_fb_2Components = [feedback_3]
    for thisComponent in ins_fb_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_fb_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_fb_2"-------
    while continueRoutine:
        # get current time
        t = ins_fb_2Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_fb_2Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedback_3* updates
        if feedback_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            feedback_3.frameNStart = frameN  # exact frame index
            feedback_3.tStart = t  # local t and not account for scr refresh
            feedback_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(feedback_3, 'tStartRefresh')  # time at next scr refresh
            feedback_3.setAutoDraw(True)
        if feedback_3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > feedback_3.tStartRefresh + feedback_time-frameTolerance:
                # keep track of stop time/frame for later
                feedback_3.tStop = t  # not accounting for scr refresh
                feedback_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(feedback_3, 'tStopRefresh')  # time at next scr refresh
                feedback_3.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_fb_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_fb_2"-------
    for thisComponent in ins_fb_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "ins_fb_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Check_3"-------
    continueRoutine = True
    # update component parameters for each repeat
    c1.setPos(k2)
    c1.alignText='left'
    
    # if testing
    if testing:
        continueRoutine = False
    key_resp_5.keys = []
    key_resp_5.rt = []
    _key_resp_5_allKeys = []
    # keep track of which components have finished
    Check_3Components = [check3, c1, key_resp_5]
    for thisComponent in Check_3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Check_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Check_3"-------
    while continueRoutine:
        # get current time
        t = Check_3Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Check_3Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *check3* updates
        if check3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            check3.frameNStart = frameN  # exact frame index
            check3.tStart = t  # local t and not account for scr refresh
            check3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(check3, 'tStartRefresh')  # time at next scr refresh
            check3.setAutoDraw(True)
        
        # *c1* updates
        if c1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            c1.frameNStart = frameN  # exact frame index
            c1.tStart = t  # local t and not account for scr refresh
            c1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(c1, 'tStartRefresh')  # time at next scr refresh
            c1.setAutoDraw(True)
        
        # *key_resp_5* updates
        waitOnFlip = False
        if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_5.frameNStart = frameN  # exact frame index
            key_resp_5.tStart = t  # local t and not account for scr refresh
            key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
            key_resp_5.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_5.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_5.getKeys(keyList=['1', '2', '3'], waitRelease=False)
            _key_resp_5_allKeys.extend(theseKeys)
            if len(_key_resp_5_allKeys):
                key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
                key_resp_5.rt = _key_resp_5_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Check_3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Check_3"-------
    for thisComponent in Check_3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('check3.started', check3.tStartRefresh)
    trials_2.addData('check3.stopped', check3.tStopRefresh)
    trials_2.addData('c1.started', c1.tStartRefresh)
    trials_2.addData('c1.stopped', c1.tStopRefresh)
    # check responses
    if key_resp_5.keys in ['', [], None]:  # No response was made
        key_resp_5.keys = None
    trials_2.addData('key_resp_5.keys',key_resp_5.keys)
    if key_resp_5.keys != None:  # we had a response
        trials_2.addData('key_resp_5.rt', key_resp_5.rt)
    trials_2.addData('key_resp_5.started', key_resp_5.tStartRefresh)
    trials_2.addData('key_resp_5.stopped', key_resp_5.tStopRefresh)
    if key_resp_5.keys == "3":
        feedback3_text = u'正确'
        feedback3_text_color = 'green'
    else:
        feedback3_text = u'错误'
        feedback3_text_color = 'red'
        wrong=wrong+1
    # the Routine "Check_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_fb_3"-------
    continueRoutine = True
    # update component parameters for each repeat
    feedback_4.setColor(feedback3_text_color, colorSpace='rgb')
    feedback_4.setText(feedback3_text)
    # if testing
    if testing:
        continueRoutine = False
    # keep track of which components have finished
    ins_fb_3Components = [feedback_4]
    for thisComponent in ins_fb_3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_fb_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_fb_3"-------
    while continueRoutine:
        # get current time
        t = ins_fb_3Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_fb_3Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedback_4* updates
        if feedback_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            feedback_4.frameNStart = frameN  # exact frame index
            feedback_4.tStart = t  # local t and not account for scr refresh
            feedback_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(feedback_4, 'tStartRefresh')  # time at next scr refresh
            feedback_4.setAutoDraw(True)
        if feedback_4.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > feedback_4.tStartRefresh + feedback_time-frameTolerance:
                # keep track of stop time/frame for later
                feedback_4.tStop = t  # not accounting for scr refresh
                feedback_4.frameNStop = frameN  # exact frame index
                win.timeOnFlip(feedback_4, 'tStopRefresh')  # time at next scr refresh
                feedback_4.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_fb_3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_fb_3"-------
    for thisComponent in ins_fb_3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "ins_fb_3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Check_4"-------
    continueRoutine = True
    # update component parameters for each repeat
    d1.setPos(k3)
    d1.alignText='left'
    
    # if testing
    if testing:
        continueRoutine = False
    key_resp_6.keys = []
    key_resp_6.rt = []
    _key_resp_6_allKeys = []
    pairing_sub_7.setSize(pairsize2)
    result_2.setImage('only_sub_wrong.png')
    # keep track of which components have finished
    Check_4Components = [check4, d1, key_resp_6, pairing_sub_7, result_2]
    for thisComponent in Check_4Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Check_4Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Check_4"-------
    while continueRoutine:
        # get current time
        t = Check_4Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Check_4Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *check4* updates
        if check4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            check4.frameNStart = frameN  # exact frame index
            check4.tStart = t  # local t and not account for scr refresh
            check4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(check4, 'tStartRefresh')  # time at next scr refresh
            check4.setAutoDraw(True)
        
        # *d1* updates
        if d1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            d1.frameNStart = frameN  # exact frame index
            d1.tStart = t  # local t and not account for scr refresh
            d1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(d1, 'tStartRefresh')  # time at next scr refresh
            d1.setAutoDraw(True)
        
        # *key_resp_6* updates
        waitOnFlip = False
        if key_resp_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_6.frameNStart = frameN  # exact frame index
            key_resp_6.tStart = t  # local t and not account for scr refresh
            key_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_6, 'tStartRefresh')  # time at next scr refresh
            key_resp_6.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_6.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_6.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_6.getKeys(keyList=['1', '2', '3'], waitRelease=False)
            _key_resp_6_allKeys.extend(theseKeys)
            if len(_key_resp_6_allKeys):
                key_resp_6.keys = _key_resp_6_allKeys[-1].name  # just the last key pressed
                key_resp_6.rt = _key_resp_6_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *pairing_sub_7* updates
        if pairing_sub_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_7.frameNStart = frameN  # exact frame index
            pairing_sub_7.tStart = t  # local t and not account for scr refresh
            pairing_sub_7.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_7, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_7.setAutoDraw(True)
        
        # *result_2* updates
        if result_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_2.frameNStart = frameN  # exact frame index
            result_2.tStart = t  # local t and not account for scr refresh
            result_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_2, 'tStartRefresh')  # time at next scr refresh
            result_2.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Check_4Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Check_4"-------
    for thisComponent in Check_4Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('check4.started', check4.tStartRefresh)
    trials_2.addData('check4.stopped', check4.tStopRefresh)
    trials_2.addData('d1.started', d1.tStartRefresh)
    trials_2.addData('d1.stopped', d1.tStopRefresh)
    # check responses
    if key_resp_6.keys in ['', [], None]:  # No response was made
        key_resp_6.keys = None
    trials_2.addData('key_resp_6.keys',key_resp_6.keys)
    if key_resp_6.keys != None:  # we had a response
        trials_2.addData('key_resp_6.rt', key_resp_6.rt)
    trials_2.addData('key_resp_6.started', key_resp_6.tStartRefresh)
    trials_2.addData('key_resp_6.stopped', key_resp_6.tStopRefresh)
    if key_resp_6.keys == "2":
        feedback4_text = u'正确'
        feedback4_text_color = 'green'
    else:
        feedback4_text = u'错误'
        feedback4_text_color = 'red'
        wrong=wrong+1
    # the Routine "Check_4" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_fb_4"-------
    continueRoutine = True
    # update component parameters for each repeat
    feedback_5.setColor(feedback4_text_color, colorSpace='rgb')
    feedback_5.setText(feedback4_text)
    # if testing
    if testing:
        continueRoutine = False
    # keep track of which components have finished
    ins_fb_4Components = [feedback_5]
    for thisComponent in ins_fb_4Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_fb_4Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_fb_4"-------
    while continueRoutine:
        # get current time
        t = ins_fb_4Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_fb_4Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedback_5* updates
        if feedback_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            feedback_5.frameNStart = frameN  # exact frame index
            feedback_5.tStart = t  # local t and not account for scr refresh
            feedback_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(feedback_5, 'tStartRefresh')  # time at next scr refresh
            feedback_5.setAutoDraw(True)
        if feedback_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > feedback_5.tStartRefresh + feedback_time-frameTolerance:
                # keep track of stop time/frame for later
                feedback_5.tStop = t  # not accounting for scr refresh
                feedback_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(feedback_5, 'tStopRefresh')  # time at next scr refresh
                feedback_5.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_fb_4Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_fb_4"-------
    for thisComponent in ins_fb_4Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "ins_fb_4" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Check_5"-------
    continueRoutine = True
    # update component parameters for each repeat
    e1.setPos(k3)
    e1.alignText='left'
    
    # if testing
    if testing:
        continueRoutine = False
    key_resp_7.keys = []
    key_resp_7.rt = []
    _key_resp_7_allKeys = []
    pairing_sub_8.setSize(pairsize2)
    result_3.setImage('both_wrong.png')
    # keep track of which components have finished
    Check_5Components = [check5, e1, key_resp_7, pairing_sub_8, result_3]
    for thisComponent in Check_5Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Check_5Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Check_5"-------
    while continueRoutine:
        # get current time
        t = Check_5Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Check_5Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *check5* updates
        if check5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            check5.frameNStart = frameN  # exact frame index
            check5.tStart = t  # local t and not account for scr refresh
            check5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(check5, 'tStartRefresh')  # time at next scr refresh
            check5.setAutoDraw(True)
        
        # *e1* updates
        if e1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            e1.frameNStart = frameN  # exact frame index
            e1.tStart = t  # local t and not account for scr refresh
            e1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(e1, 'tStartRefresh')  # time at next scr refresh
            e1.setAutoDraw(True)
        
        # *key_resp_7* updates
        waitOnFlip = False
        if key_resp_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp_7.frameNStart = frameN  # exact frame index
            key_resp_7.tStart = t  # local t and not account for scr refresh
            key_resp_7.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp_7, 'tStartRefresh')  # time at next scr refresh
            key_resp_7.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp_7.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp_7.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp_7.status == STARTED and not waitOnFlip:
            theseKeys = key_resp_7.getKeys(keyList=['1', '2', '3'], waitRelease=False)
            _key_resp_7_allKeys.extend(theseKeys)
            if len(_key_resp_7_allKeys):
                key_resp_7.keys = _key_resp_7_allKeys[-1].name  # just the last key pressed
                key_resp_7.rt = _key_resp_7_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *pairing_sub_8* updates
        if pairing_sub_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_8.frameNStart = frameN  # exact frame index
            pairing_sub_8.tStart = t  # local t and not account for scr refresh
            pairing_sub_8.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_8, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_8.setAutoDraw(True)
        
        # *result_3* updates
        if result_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_3.frameNStart = frameN  # exact frame index
            result_3.tStart = t  # local t and not account for scr refresh
            result_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_3, 'tStartRefresh')  # time at next scr refresh
            result_3.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Check_5Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Check_5"-------
    for thisComponent in Check_5Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('check5.started', check5.tStartRefresh)
    trials_2.addData('check5.stopped', check5.tStopRefresh)
    trials_2.addData('e1.started', e1.tStartRefresh)
    trials_2.addData('e1.stopped', e1.tStopRefresh)
    # check responses
    if key_resp_7.keys in ['', [], None]:  # No response was made
        key_resp_7.keys = None
    trials_2.addData('key_resp_7.keys',key_resp_7.keys)
    if key_resp_7.keys != None:  # we had a response
        trials_2.addData('key_resp_7.rt', key_resp_7.rt)
    trials_2.addData('key_resp_7.started', key_resp_7.tStartRefresh)
    trials_2.addData('key_resp_7.stopped', key_resp_7.tStopRefresh)
    if key_resp_7.keys == "2":
        feedback5_text = u'正确'
        feedback5_text_color = 'green'
    else:
        feedback5_text = u'错误'
        feedback5_text_color = 'red'
        wrong=wrong+1
    # the Routine "Check_5" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ins_fb_5"-------
    continueRoutine = True
    # update component parameters for each repeat
    feedback_6.setColor(feedback5_text_color, colorSpace='rgb')
    feedback_6.setText(feedback5_text)
    # if testing
    if testing:
        continueRoutine = False
    # keep track of which components have finished
    ins_fb_5Components = [feedback_6]
    for thisComponent in ins_fb_5Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ins_fb_5Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ins_fb_5"-------
    while continueRoutine:
        # get current time
        t = ins_fb_5Clock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ins_fb_5Clock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedback_6* updates
        if feedback_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            feedback_6.frameNStart = frameN  # exact frame index
            feedback_6.tStart = t  # local t and not account for scr refresh
            feedback_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(feedback_6, 'tStartRefresh')  # time at next scr refresh
            feedback_6.setAutoDraw(True)
        if feedback_6.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > feedback_6.tStartRefresh + feedback_time-frameTolerance:
                # keep track of stop time/frame for later
                feedback_6.tStop = t  # not accounting for scr refresh
                feedback_6.frameNStop = frameN  # exact frame index
                win.timeOnFlip(feedback_6, 'tStopRefresh')  # time at next scr refresh
                feedback_6.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ins_fb_5Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ins_fb_5"-------
    for thisComponent in ins_fb_5Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "ins_fb_5" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "end_ins"-------
    continueRoutine = True
    # update component parameters for each repeat
    if testing | (wrong==0):
        trials_2.finished=True
    # keep track of which components have finished
    end_insComponents = []
    for thisComponent in end_insComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    end_insClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "end_ins"-------
    while continueRoutine:
        # get current time
        t = end_insClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=end_insClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in end_insComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "end_ins"-------
    for thisComponent in end_insComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "end_ins" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "read_again"-------
    continueRoutine = True
    routineTimer.add(3.000000)
    # update component parameters for each repeat
    if testing | (wrong == 0):
        continueRoutine = False
    
    #if wrong==0:
    #    continueRoutine=False
    # keep track of which components have finished
    read_againComponents = [text_15]
    for thisComponent in read_againComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    read_againClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "read_again"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = read_againClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=read_againClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_15* updates
        if text_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_15.frameNStart = frameN  # exact frame index
            text_15.tStart = t  # local t and not account for scr refresh
            text_15.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_15, 'tStartRefresh')  # time at next scr refresh
            text_15.setAutoDraw(True)
        if text_15.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_15.tStartRefresh + 3-frameTolerance:
                # keep track of stop time/frame for later
                text_15.tStop = t  # not accounting for scr refresh
                text_15.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_15, 'tStopRefresh')  # time at next scr refresh
                text_15.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in read_againComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "read_again"-------
    for thisComponent in read_againComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_2.addData('text_15.started', text_15.tStartRefresh)
    trials_2.addData('text_15.stopped', text_15.tStopRefresh)
    thisExp.nextEntry()
    
# completed 100.0 repeats of 'trials_2'


# ------Prepare to start Routine "prac_ins"-------
continueRoutine = True
# update component parameters for each repeat
pre_instru_resp.keys = []
pre_instru_resp.rt = []
_pre_instru_resp_allKeys = []
# keep track of which components have finished
prac_insComponents = [text, pre_instru_resp]
for thisComponent in prac_insComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
prac_insClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "prac_ins"-------
while continueRoutine:
    # get current time
    t = prac_insClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=prac_insClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    
    # *pre_instru_resp* updates
    waitOnFlip = False
    if pre_instru_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        pre_instru_resp.frameNStart = frameN  # exact frame index
        pre_instru_resp.tStart = t  # local t and not account for scr refresh
        pre_instru_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(pre_instru_resp, 'tStartRefresh')  # time at next scr refresh
        pre_instru_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(pre_instru_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(pre_instru_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if pre_instru_resp.status == STARTED and not waitOnFlip:
        theseKeys = pre_instru_resp.getKeys(keyList=['space'], waitRelease=False)
        _pre_instru_resp_allKeys.extend(theseKeys)
        if len(_pre_instru_resp_allKeys):
            pre_instru_resp.keys = _pre_instru_resp_allKeys[-1].name  # just the last key pressed
            pre_instru_resp.rt = _pre_instru_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in prac_insComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "prac_ins"-------
for thisComponent in prac_insComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)
# check responses
if pre_instru_resp.keys in ['', [], None]:  # No response was made
    pre_instru_resp.keys = None
thisExp.addData('pre_instru_resp.keys',pre_instru_resp.keys)
if pre_instru_resp.keys != None:  # we had a response
    thisExp.addData('pre_instru_resp.rt', pre_instru_resp.rt)
thisExp.addData('pre_instru_resp.started', pre_instru_resp.tStartRefresh)
thisExp.addData('pre_instru_resp.stopped', pre_instru_resp.tStopRefresh)
thisExp.nextEntry()
# the Routine "prac_ins" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('prac_condition.csv', selection=pracrow),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "prac_sta"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    count_text = u'第'+str((trials.thisTrialN+1))+u'轮练习'
    start_prac_text.setText(count_text
)
    # keep track of which components have finished
    prac_staComponents = [start_prac_text]
    for thisComponent in prac_staComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    prac_staClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "prac_sta"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = prac_staClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=prac_staClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *start_prac_text* updates
        if start_prac_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            start_prac_text.frameNStart = frameN  # exact frame index
            start_prac_text.tStart = t  # local t and not account for scr refresh
            start_prac_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(start_prac_text, 'tStartRefresh')  # time at next scr refresh
            start_prac_text.setAutoDraw(True)
        if start_prac_text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > start_prac_text.tStartRefresh + 1-frameTolerance:
                # keep track of stop time/frame for later
                start_prac_text.tStop = t  # not accounting for scr refresh
                start_prac_text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(start_prac_text, 'tStopRefresh')  # time at next scr refresh
                start_prac_text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in prac_staComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "prac_sta"-------
    for thisComponent in prac_staComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addData('start_prac_text.started', start_prac_text.tStartRefresh)
    trials.addData('start_prac_text.stopped', start_prac_text.tStopRefresh)
    
    # ------Prepare to start Routine "prac_sti"-------
    continueRoutine = True
    routineTimer.add(1.500000)
    # update component parameters for each repeat
    image.setSize(dotsize)
    image.setImage(prac_dot_sti)
    # keep track of which components have finished
    prac_stiComponents = [image]
    for thisComponent in prac_stiComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    prac_stiClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "prac_sti"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = prac_stiClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=prac_stiClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image* updates
        if image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image.frameNStart = frameN  # exact frame index
            image.tStart = t  # local t and not account for scr refresh
            image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
            image.setAutoDraw(True)
        if image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > image.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                image.tStop = t  # not accounting for scr refresh
                image.frameNStop = frameN  # exact frame index
                win.timeOnFlip(image, 'tStopRefresh')  # time at next scr refresh
                image.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in prac_stiComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "prac_sti"-------
    for thisComponent in prac_stiComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addData('image.started', image.tStartRefresh)
    trials.addData('image.stopped', image.tStopRefresh)
    
    # ------Prepare to start Routine "prac_judge"-------
    continueRoutine = True
    routineTimer.add(5.000000)
    # update component parameters for each repeat
    prac_judge_text.setHeight(0.1)
    # setup some python lists for storing info about the judge_2
    judge_2.clicked_name = []
    gotValidClick = False  # until a click is received
    RightButton_2.setText(dotrighttext)
    LeftButton_2.setText(dotlefttext)
    # keep track of which components have finished
    prac_judgeComponents = [prac_judge_text, judge_2, rect1, rect2, RightButton_2, LeftButton_2]
    for thisComponent in prac_judgeComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    prac_judgeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "prac_judge"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = prac_judgeClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=prac_judgeClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        if RightButton_2.contains(judge_2): 
            rectcolor2 = 'red'
        else:
            rectcolor2 = 'white'
            
        if LeftButton_2.contains(judge_2):
            rectcolor1 = 'red'
        else:
            rectcolor1 = 'white'
        
        # *prac_judge_text* updates
        if prac_judge_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_judge_text.frameNStart = frameN  # exact frame index
            prac_judge_text.tStart = t  # local t and not account for scr refresh
            prac_judge_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_judge_text, 'tStartRefresh')  # time at next scr refresh
            prac_judge_text.setAutoDraw(True)
        if prac_judge_text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > prac_judge_text.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                prac_judge_text.tStop = t  # not accounting for scr refresh
                prac_judge_text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(prac_judge_text, 'tStopRefresh')  # time at next scr refresh
                prac_judge_text.setAutoDraw(False)
        # *judge_2* updates
        if judge_2.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            judge_2.frameNStart = frameN  # exact frame index
            judge_2.tStart = t  # local t and not account for scr refresh
            judge_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(judge_2, 'tStartRefresh')  # time at next scr refresh
            judge_2.status = STARTED
            judge_2.mouseClock.reset()
            prevButtonState = judge_2.getPressed()  # if button is down already this ISN'T a new click
        if judge_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > judge_2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                judge_2.tStop = t  # not accounting for scr refresh
                judge_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(judge_2, 'tStopRefresh')  # time at next scr refresh
                judge_2.status = FINISHED
        if judge_2.status == STARTED:  # only update if started and not finished!
            buttons = judge_2.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter([RightButton_2,LeftButton_2])
                        clickableList = [RightButton_2,LeftButton_2]
                    except:
                        clickableList = [[RightButton_2,LeftButton_2]]
                    for obj in clickableList:
                        if obj.contains(judge_2):
                            gotValidClick = True
                            judge_2.clicked_name.append(obj.name)
                    if gotValidClick:  # abort routine on response
                        continueRoutine = False
        
        # *rect1* updates
        if rect1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            rect1.frameNStart = frameN  # exact frame index
            rect1.tStart = t  # local t and not account for scr refresh
            rect1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(rect1, 'tStartRefresh')  # time at next scr refresh
            rect1.setAutoDraw(True)
        if rect1.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > rect1.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                rect1.tStop = t  # not accounting for scr refresh
                rect1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(rect1, 'tStopRefresh')  # time at next scr refresh
                rect1.setAutoDraw(False)
        if rect1.status == STARTED:  # only update if drawing
            rect1.setLineColor(rectcolor1, log=False)
        
        # *rect2* updates
        if rect2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            rect2.frameNStart = frameN  # exact frame index
            rect2.tStart = t  # local t and not account for scr refresh
            rect2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(rect2, 'tStartRefresh')  # time at next scr refresh
            rect2.setAutoDraw(True)
        if rect2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > rect2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                rect2.tStop = t  # not accounting for scr refresh
                rect2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(rect2, 'tStopRefresh')  # time at next scr refresh
                rect2.setAutoDraw(False)
        if rect2.status == STARTED:  # only update if drawing
            rect2.setLineColor(rectcolor2, log=False)
        
        # *RightButton_2* updates
        if RightButton_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RightButton_2.frameNStart = frameN  # exact frame index
            RightButton_2.tStart = t  # local t and not account for scr refresh
            RightButton_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RightButton_2, 'tStartRefresh')  # time at next scr refresh
            RightButton_2.setAutoDraw(True)
        if RightButton_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > RightButton_2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                RightButton_2.tStop = t  # not accounting for scr refresh
                RightButton_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(RightButton_2, 'tStopRefresh')  # time at next scr refresh
                RightButton_2.setAutoDraw(False)
        
        # *LeftButton_2* updates
        if LeftButton_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            LeftButton_2.frameNStart = frameN  # exact frame index
            LeftButton_2.tStart = t  # local t and not account for scr refresh
            LeftButton_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(LeftButton_2, 'tStartRefresh')  # time at next scr refresh
            LeftButton_2.setAutoDraw(True)
        if LeftButton_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > LeftButton_2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                LeftButton_2.tStop = t  # not accounting for scr refresh
                LeftButton_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(LeftButton_2, 'tStopRefresh')  # time at next scr refresh
                LeftButton_2.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in prac_judgeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "prac_judge"-------
    for thisComponent in prac_judgeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    get_clicked = judge_2.clicked_name
    thisExp.addData('clicked', get_clicked)
    if not gotValidClick:
        feedback_text = u'本轮回答为空，请更快地作答'
        feedback_text_color = 'red'
    else:
        if judge_2.clicked_name[0] == prac_answer:
            feedback_text = u'正确' 
            feedback_text_color = 'green'
            prac_acc += 1
        else:
            feedback_text = u'错误'
            feedback_text_color = 'red'
    #if judge_2.clicked_name[0] == prac_answer:
    #    feedback_text = u'Correct'
    #    feedback_text_color = 'green'
    #    prac_acc+=1
    #else:
    #    feedback_text = u'Incorrect'
    #    feedback_text_color = 'red'
    # store data for trials (TrialHandler)
    x, y = judge_2.getPos()
    buttons = judge_2.getPressed()
    if sum(buttons):
        # check if the mouse was inside our 'clickable' objects
        gotValidClick = False
        try:
            iter([RightButton_2,LeftButton_2])
            clickableList = [RightButton_2,LeftButton_2]
        except:
            clickableList = [[RightButton_2,LeftButton_2]]
        for obj in clickableList:
            if obj.contains(judge_2):
                gotValidClick = True
                judge_2.clicked_name.append(obj.name)
    trials.addData('judge_2.x', x)
    trials.addData('judge_2.y', y)
    trials.addData('judge_2.leftButton', buttons[0])
    trials.addData('judge_2.midButton', buttons[1])
    trials.addData('judge_2.rightButton', buttons[2])
    if len(judge_2.clicked_name):
        trials.addData('judge_2.clicked_name', judge_2.clicked_name[0])
    trials.addData('judge_2.started', judge_2.tStart)
    trials.addData('judge_2.stopped', judge_2.tStop)
    
    # ------Prepare to start Routine "prac_fb"-------
    continueRoutine = True
    # update component parameters for each repeat
    feedback.setColor(feedback_text_color, colorSpace='rgb')
    feedback.setText(feedback_text)
    # keep track of which components have finished
    prac_fbComponents = [feedback]
    for thisComponent in prac_fbComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    prac_fbClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "prac_fb"-------
    while continueRoutine:
        # get current time
        t = prac_fbClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=prac_fbClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedback* updates
        if feedback.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            feedback.frameNStart = frameN  # exact frame index
            feedback.tStart = t  # local t and not account for scr refresh
            feedback.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(feedback, 'tStartRefresh')  # time at next scr refresh
            feedback.setAutoDraw(True)
        if feedback.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > feedback.tStartRefresh + feedback_time-frameTolerance:
                # keep track of stop time/frame for later
                feedback.tStop = t  # not accounting for scr refresh
                feedback.frameNStop = frameN  # exact frame index
                win.timeOnFlip(feedback, 'tStopRefresh')  # time at next scr refresh
                feedback.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in prac_fbComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "prac_fb"-------
    for thisComponent in prac_fbComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "prac_fb" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trials'


# ------Prepare to start Routine "phase_ins"-------
continueRoutine = True
# update component parameters for each repeat
instru_resp_2.keys = []
instru_resp_2.rt = []
_instru_resp_2_allKeys = []
prac_acc = prac_acc/5
thisExp.addData('prac_acc', prac_acc)
# keep track of which components have finished
phase_insComponents = [instru_text_2, instru_resp_2]
for thisComponent in phase_insComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
phase_insClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "phase_ins"-------
while continueRoutine:
    # get current time
    t = phase_insClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=phase_insClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instru_text_2* updates
    if instru_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instru_text_2.frameNStart = frameN  # exact frame index
        instru_text_2.tStart = t  # local t and not account for scr refresh
        instru_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instru_text_2, 'tStartRefresh')  # time at next scr refresh
        instru_text_2.setAutoDraw(True)
    
    # *instru_resp_2* updates
    waitOnFlip = False
    if instru_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instru_resp_2.frameNStart = frameN  # exact frame index
        instru_resp_2.tStart = t  # local t and not account for scr refresh
        instru_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instru_resp_2, 'tStartRefresh')  # time at next scr refresh
        instru_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instru_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instru_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instru_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = instru_resp_2.getKeys(keyList=['space'], waitRelease=False)
        _instru_resp_2_allKeys.extend(theseKeys)
        if len(_instru_resp_2_allKeys):
            instru_resp_2.keys = _instru_resp_2_allKeys[-1].name  # just the last key pressed
            instru_resp_2.rt = _instru_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in phase_insComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "phase_ins"-------
for thisComponent in phase_insComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "phase_ins" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trialseq = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('condition.csv', selection=chooserow),
    seed=None, name='trialseq')
thisExp.addLoop(trialseq)  # add the loop to the experiment
thisTrialseq = trialseq.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrialseq.rgb)
if thisTrialseq != None:
    for paramName in thisTrialseq:
        exec('{} = thisTrialseq[paramName]'.format(paramName))

for thisTrialseq in trialseq:
    currentLoop = trialseq
    # abbreviate parameter names if possible (e.g. rgb = thisTrialseq.rgb)
    if thisTrialseq != None:
        for paramName in thisTrialseq:
            exec('{} = thisTrialseq[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "first_guilt_sta"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    if trialseq.thisTrialN!=0:
        continueRoutine=False
    # keep track of which components have finished
    first_guilt_staComponents = [text_10]
    for thisComponent in first_guilt_staComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    first_guilt_staClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "first_guilt_sta"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = first_guilt_staClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=first_guilt_staClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_10* updates
        if text_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_10.frameNStart = frameN  # exact frame index
            text_10.tStart = t  # local t and not account for scr refresh
            text_10.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_10, 'tStartRefresh')  # time at next scr refresh
            text_10.setAutoDraw(True)
        if text_10.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_10.tStartRefresh + 1-frameTolerance:
                # keep track of stop time/frame for later
                text_10.tStop = t  # not accounting for scr refresh
                text_10.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_10, 'tStopRefresh')  # time at next scr refresh
                text_10.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in first_guilt_staComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "first_guilt_sta"-------
    for thisComponent in first_guilt_staComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('text_10.started', text_10.tStartRefresh)
    trialseq.addData('text_10.stopped', text_10.tStopRefresh)
    
    # ------Prepare to start Routine "guilt_pairing"-------
    continueRoutine = True
    # update component parameters for each repeat
    pairing_wait_time = random.random()+2
    count = 0
    timejit = timejitter
    pairing_sub.setPos(pairpos)
    pairing_sub.setSize(pairsize0)
    # keep track of which components have finished
    guilt_pairingComponents = [pairing_sub, pairing_wait, Ellipsis_2]
    for thisComponent in guilt_pairingComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_pairingClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_pairing"-------
    while continueRoutine:
        # get current time
        t = guilt_pairingClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_pairingClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        if t>timejit[0]:
            EllipsisText = ellis [count%3] 
            count = count+1
            timejit = timejit[1:]
        
        # *pairing_sub* updates
        if pairing_sub.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub.frameNStart = frameN  # exact frame index
            pairing_sub.tStart = t  # local t and not account for scr refresh
            pairing_sub.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub, 'tStartRefresh')  # time at next scr refresh
            pairing_sub.setAutoDraw(True)
        if pairing_sub.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub.tStartRefresh + pairing_wait_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub.tStop = t  # not accounting for scr refresh
                pairing_sub.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub, 'tStopRefresh')  # time at next scr refresh
                pairing_sub.setAutoDraw(False)
        
        # *pairing_wait* updates
        if pairing_wait.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_wait.frameNStart = frameN  # exact frame index
            pairing_wait.tStart = t  # local t and not account for scr refresh
            pairing_wait.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_wait, 'tStartRefresh')  # time at next scr refresh
            pairing_wait.setAutoDraw(True)
        if pairing_wait.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_wait.tStartRefresh + pairing_wait_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_wait.tStop = t  # not accounting for scr refresh
                pairing_wait.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_wait, 'tStopRefresh')  # time at next scr refresh
                pairing_wait.setAutoDraw(False)
        
        # *Ellipsis_2* updates
        if Ellipsis_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Ellipsis_2.frameNStart = frameN  # exact frame index
            Ellipsis_2.tStart = t  # local t and not account for scr refresh
            Ellipsis_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ellipsis_2, 'tStartRefresh')  # time at next scr refresh
            Ellipsis_2.setAutoDraw(True)
        if Ellipsis_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Ellipsis_2.tStartRefresh + pairing_wait_time-frameTolerance:
                # keep track of stop time/frame for later
                Ellipsis_2.tStop = t  # not accounting for scr refresh
                Ellipsis_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Ellipsis_2, 'tStopRefresh')  # time at next scr refresh
                Ellipsis_2.setAutoDraw(False)
        if Ellipsis_2.status == STARTED:  # only update if drawing
            Ellipsis_2.setText(EllipsisText, log=False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_pairingComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_pairing"-------
    for thisComponent in guilt_pairingComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "guilt_pairing" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "guilt_cue"-------
    continueRoutine = True
    # update component parameters for each repeat
    guilt_cue_time = 1
    
    pairing_sub_2.setSize(pairsize2)
    pairing_sub_2.setImage('Punish_Pair.png')
    attention.setHeight(bottom_textsize)
    # keep track of which components have finished
    guilt_cueComponents = [pairing_sub_2, attention]
    for thisComponent in guilt_cueComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_cueClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_cue"-------
    while continueRoutine:
        # get current time
        t = guilt_cueClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_cueClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_2* updates
        if pairing_sub_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_2.frameNStart = frameN  # exact frame index
            pairing_sub_2.tStart = t  # local t and not account for scr refresh
            pairing_sub_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_2, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_2.setAutoDraw(True)
        if pairing_sub_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_2.tStartRefresh + guilt_cue_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_2.tStop = t  # not accounting for scr refresh
                pairing_sub_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_2, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_2.setAutoDraw(False)
        
        # *attention* updates
        if attention.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            attention.frameNStart = frameN  # exact frame index
            attention.tStart = t  # local t and not account for scr refresh
            attention.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(attention, 'tStartRefresh')  # time at next scr refresh
            attention.setAutoDraw(True)
        if attention.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > attention.tStartRefresh + guilt_cue_time-frameTolerance:
                # keep track of stop time/frame for later
                attention.tStop = t  # not accounting for scr refresh
                attention.frameNStop = frameN  # exact frame index
                win.timeOnFlip(attention, 'tStopRefresh')  # time at next scr refresh
                attention.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_cueComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_cue"-------
    for thisComponent in guilt_cueComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "guilt_cue" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "guilt_sti"-------
    continueRoutine = True
    routineTimer.add(1.500000)
    # update component parameters for each repeat
    pairing_sub_3.setSize(pairsize2)
    pairing_sub_3.setImage('Punish_Pair.png')
    dotstipic.setImage(picture)
    # keep track of which components have finished
    guilt_stiComponents = [pairing_sub_3, dotstipic]
    for thisComponent in guilt_stiComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_stiClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_sti"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = guilt_stiClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_stiClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_3* updates
        if pairing_sub_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_3.frameNStart = frameN  # exact frame index
            pairing_sub_3.tStart = t  # local t and not account for scr refresh
            pairing_sub_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_3, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_3.setAutoDraw(True)
        if pairing_sub_3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_3.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_3.tStop = t  # not accounting for scr refresh
                pairing_sub_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_3, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_3.setAutoDraw(False)
        
        # *dotstipic* updates
        if dotstipic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            dotstipic.frameNStart = frameN  # exact frame index
            dotstipic.tStart = t  # local t and not account for scr refresh
            dotstipic.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(dotstipic, 'tStartRefresh')  # time at next scr refresh
            dotstipic.setAutoDraw(True)
        if dotstipic.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > dotstipic.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                dotstipic.tStop = t  # not accounting for scr refresh
                dotstipic.frameNStop = frameN  # exact frame index
                win.timeOnFlip(dotstipic, 'tStopRefresh')  # time at next scr refresh
                dotstipic.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_stiComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_sti"-------
    for thisComponent in guilt_stiComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "guilt_judge"-------
    continueRoutine = True
    routineTimer.add(5.000000)
    # update component parameters for each repeat
    pairing_sub_4.setSize(pairsize2)
    pairing_sub_4.setImage('Punish_Pair.png')
    sti_text1.setText(number)
    sti_text1.setHeight(bottom_textsize)
    # setup some python lists for storing info about the judge
    judge.clicked_name = []
    gotValidClick = False  # until a click is received
    RightButton.setText(dotrighttext)
    LeftButton.setText(dotlefttext)
    # keep track of which components have finished
    guilt_judgeComponents = [pairing_sub_4, sti_text1, judge, RightButton, LeftButton, rect1_2, rect2_2, text_16]
    for thisComponent in guilt_judgeComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_judgeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_judge"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = guilt_judgeClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_judgeClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_4* updates
        if pairing_sub_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_4.frameNStart = frameN  # exact frame index
            pairing_sub_4.tStart = t  # local t and not account for scr refresh
            pairing_sub_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_4, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_4.setAutoDraw(True)
        if pairing_sub_4.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_4.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_4.tStop = t  # not accounting for scr refresh
                pairing_sub_4.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_4, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_4.setAutoDraw(False)
        
        # *sti_text1* updates
        if sti_text1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            sti_text1.frameNStart = frameN  # exact frame index
            sti_text1.tStart = t  # local t and not account for scr refresh
            sti_text1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(sti_text1, 'tStartRefresh')  # time at next scr refresh
            sti_text1.setAutoDraw(True)
        if sti_text1.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > sti_text1.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                sti_text1.tStop = t  # not accounting for scr refresh
                sti_text1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(sti_text1, 'tStopRefresh')  # time at next scr refresh
                sti_text1.setAutoDraw(False)
        # *judge* updates
        if judge.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            judge.frameNStart = frameN  # exact frame index
            judge.tStart = t  # local t and not account for scr refresh
            judge.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(judge, 'tStartRefresh')  # time at next scr refresh
            judge.status = STARTED
            judge.mouseClock.reset()
            prevButtonState = judge.getPressed()  # if button is down already this ISN'T a new click
        if judge.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > judge.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                judge.tStop = t  # not accounting for scr refresh
                judge.frameNStop = frameN  # exact frame index
                win.timeOnFlip(judge, 'tStopRefresh')  # time at next scr refresh
                judge.status = FINISHED
        if judge.status == STARTED:  # only update if started and not finished!
            buttons = judge.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter([RightButton,LeftButton])
                        clickableList = [RightButton,LeftButton]
                    except:
                        clickableList = [[RightButton,LeftButton]]
                    for obj in clickableList:
                        if obj.contains(judge):
                            gotValidClick = True
                            judge.clicked_name.append(obj.name)
                    if gotValidClick:  # abort routine on response
                        continueRoutine = False
        if RightButton.contains(judge): 
            rectcolor2 = 'red'
        else:
            rectcolor2 = 'white'
            
        if LeftButton.contains(judge):
            rectcolor1 = 'red'
        else:
            rectcolor1 = 'white'
        
        # *RightButton* updates
        if RightButton.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RightButton.frameNStart = frameN  # exact frame index
            RightButton.tStart = t  # local t and not account for scr refresh
            RightButton.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RightButton, 'tStartRefresh')  # time at next scr refresh
            RightButton.setAutoDraw(True)
        if RightButton.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > RightButton.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                RightButton.tStop = t  # not accounting for scr refresh
                RightButton.frameNStop = frameN  # exact frame index
                win.timeOnFlip(RightButton, 'tStopRefresh')  # time at next scr refresh
                RightButton.setAutoDraw(False)
        
        # *LeftButton* updates
        if LeftButton.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            LeftButton.frameNStart = frameN  # exact frame index
            LeftButton.tStart = t  # local t and not account for scr refresh
            LeftButton.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(LeftButton, 'tStartRefresh')  # time at next scr refresh
            LeftButton.setAutoDraw(True)
        if LeftButton.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > LeftButton.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                LeftButton.tStop = t  # not accounting for scr refresh
                LeftButton.frameNStop = frameN  # exact frame index
                win.timeOnFlip(LeftButton, 'tStopRefresh')  # time at next scr refresh
                LeftButton.setAutoDraw(False)
        
        # *rect1_2* updates
        if rect1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            rect1_2.frameNStart = frameN  # exact frame index
            rect1_2.tStart = t  # local t and not account for scr refresh
            rect1_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(rect1_2, 'tStartRefresh')  # time at next scr refresh
            rect1_2.setAutoDraw(True)
        if rect1_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > rect1_2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                rect1_2.tStop = t  # not accounting for scr refresh
                rect1_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(rect1_2, 'tStopRefresh')  # time at next scr refresh
                rect1_2.setAutoDraw(False)
        if rect1_2.status == STARTED:  # only update if drawing
            rect1_2.setLineColor(rectcolor1, log=False)
        
        # *rect2_2* updates
        if rect2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            rect2_2.frameNStart = frameN  # exact frame index
            rect2_2.tStart = t  # local t and not account for scr refresh
            rect2_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(rect2_2, 'tStartRefresh')  # time at next scr refresh
            rect2_2.setAutoDraw(True)
        if rect2_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > rect2_2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                rect2_2.tStop = t  # not accounting for scr refresh
                rect2_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(rect2_2, 'tStopRefresh')  # time at next scr refresh
                rect2_2.setAutoDraw(False)
        if rect2_2.status == STARTED:  # only update if drawing
            rect2_2.setLineColor(rectcolor2, log=False)
        
        # *text_16* updates
        if text_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_16.frameNStart = frameN  # exact frame index
            text_16.tStart = t  # local t and not account for scr refresh
            text_16.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_16, 'tStartRefresh')  # time at next scr refresh
            text_16.setAutoDraw(True)
        if text_16.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_16.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                text_16.tStop = t  # not accounting for scr refresh
                text_16.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_16, 'tStopRefresh')  # time at next scr refresh
                text_16.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_judgeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_judge"-------
    for thisComponent in guilt_judgeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store data for trialseq (TrialHandler)
    x, y = judge.getPos()
    buttons = judge.getPressed()
    if sum(buttons):
        # check if the mouse was inside our 'clickable' objects
        gotValidClick = False
        try:
            iter([RightButton,LeftButton])
            clickableList = [RightButton,LeftButton]
        except:
            clickableList = [[RightButton,LeftButton]]
        for obj in clickableList:
            if obj.contains(judge):
                gotValidClick = True
                judge.clicked_name.append(obj.name)
    trialseq.addData('judge.x', x)
    trialseq.addData('judge.y', y)
    trialseq.addData('judge.leftButton', buttons[0])
    trialseq.addData('judge.midButton', buttons[1])
    trialseq.addData('judge.rightButton', buttons[2])
    if len(judge.clicked_name):
        trialseq.addData('judge.clicked_name', judge.clicked_name[0])
    trialseq.addData('judge.started', judge.tStart)
    trialseq.addData('judge.stopped', judge.tStop)
    get_clicked_guilt = judge.clicked_name
    thisExp.addData('clicked_guilt', get_clicked_guilt)
    rep=1
    if gotValidClick==False:
        judge.clicked_name=['No response']
    
    if (type_trial== 4) & (judge.clicked_name[0] != answer):
        rep=0
    if (type_trial== 5) & (judge.clicked_name[0] != answer):
        rep=0
    
    trialseq.addData('text_16.started', text_16.tStartRefresh)
    trialseq.addData('text_16.stopped', text_16.tStopRefresh)
    
    # ------Prepare to start Routine "guilt_check_answer"-------
    continueRoutine = True
    # update component parameters for each repeat
    pairing_sub_5.setSize(pairsize2)
    if gotValidClick==False:
        continueRoutine=False
    wait_check_time = 0.8
    count = 0
    timejit = timejitter
    
    wait_check_text.setHeight(bottom_textsize)
    # keep track of which components have finished
    guilt_check_answerComponents = [pairing_sub_5, wait_check_text, Ellipsis_3]
    for thisComponent in guilt_check_answerComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_check_answerClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_check_answer"-------
    while continueRoutine:
        # get current time
        t = guilt_check_answerClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_check_answerClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_5* updates
        if pairing_sub_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_5.frameNStart = frameN  # exact frame index
            pairing_sub_5.tStart = t  # local t and not account for scr refresh
            pairing_sub_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_5, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_5.setAutoDraw(True)
        if pairing_sub_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_5.tStartRefresh + wait_check_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_5.tStop = t  # not accounting for scr refresh
                pairing_sub_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_5, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_5.setAutoDraw(False)
        if t>timejit[0]:
            EllipsisText = ellis [count%3] 
            count = count+1
            timejit = timejit[1:]
        
        # *wait_check_text* updates
        if wait_check_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            wait_check_text.frameNStart = frameN  # exact frame index
            wait_check_text.tStart = t  # local t and not account for scr refresh
            wait_check_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(wait_check_text, 'tStartRefresh')  # time at next scr refresh
            wait_check_text.setAutoDraw(True)
        if wait_check_text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > wait_check_text.tStartRefresh + wait_check_time-frameTolerance:
                # keep track of stop time/frame for later
                wait_check_text.tStop = t  # not accounting for scr refresh
                wait_check_text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(wait_check_text, 'tStopRefresh')  # time at next scr refresh
                wait_check_text.setAutoDraw(False)
        
        # *Ellipsis_3* updates
        if Ellipsis_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Ellipsis_3.frameNStart = frameN  # exact frame index
            Ellipsis_3.tStart = t  # local t and not account for scr refresh
            Ellipsis_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ellipsis_3, 'tStartRefresh')  # time at next scr refresh
            Ellipsis_3.setAutoDraw(True)
        if Ellipsis_3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Ellipsis_3.tStartRefresh + wait_check_time-frameTolerance:
                # keep track of stop time/frame for later
                Ellipsis_3.tStop = t  # not accounting for scr refresh
                Ellipsis_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Ellipsis_3, 'tStopRefresh')  # time at next scr refresh
                Ellipsis_3.setAutoDraw(False)
        if Ellipsis_3.status == STARTED:  # only update if drawing
            Ellipsis_3.setText(EllipsisText, log=False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_check_answerComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_check_answer"-------
    for thisComponent in guilt_check_answerComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "guilt_check_answer" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "warn_incomplete"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    if gotValidClick==True:
        continueRoutine=False
    else:
        incompleteTrials.append(chooserow[trialseq.thisTrialN])
        print("incompleteTrials: ", incompleteTrials)
        thisExp.addData('incompleteTrials', chooserow[trialseq.thisTrialN])
    # keep track of which components have finished
    warn_incompleteComponents = [text_14]
    for thisComponent in warn_incompleteComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    warn_incompleteClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "warn_incomplete"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = warn_incompleteClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=warn_incompleteClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_14* updates
        if text_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_14.frameNStart = frameN  # exact frame index
            text_14.tStart = t  # local t and not account for scr refresh
            text_14.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_14, 'tStartRefresh')  # time at next scr refresh
            text_14.setAutoDraw(True)
        if text_14.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_14.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                text_14.tStop = t  # not accounting for scr refresh
                text_14.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_14, 'tStopRefresh')  # time at next scr refresh
                text_14.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warn_incompleteComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "warn_incomplete"-------
    for thisComponent in warn_incompleteComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('text_14.started', text_14.tStartRefresh)
    trialseq.addData('text_14.stopped', text_14.tStopRefresh)
    
    # ------Prepare to start Routine "warn_wrong"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    if (rep != 0):
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    
    # keep track of which components have finished
    warn_wrongComponents = [text_12]
    for thisComponent in warn_wrongComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    warn_wrongClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "warn_wrong"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = warn_wrongClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=warn_wrongClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_12* updates
        if text_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_12.frameNStart = frameN  # exact frame index
            text_12.tStart = t  # local t and not account for scr refresh
            text_12.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_12, 'tStartRefresh')  # time at next scr refresh
            text_12.setAutoDraw(True)
        if text_12.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_12.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                text_12.tStop = t  # not accounting for scr refresh
                text_12.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_12, 'tStopRefresh')  # time at next scr refresh
                text_12.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warn_wrongComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "warn_wrong"-------
    for thisComponent in warn_wrongComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('text_12.started', text_12.tStartRefresh)
    trialseq.addData('text_12.stopped', text_12.tStopRefresh)
    
    # ------Prepare to start Routine "guilt_result"-------
    continueRoutine = True
    # update component parameters for each repeat
    if rep==0 :
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    
    count = 0
    timejit = timejitter
    if (type_trial == 0) | (type_trial == 4) | (type_trial == 5):
        phase1_result_time = 2
        FillerPunish = 1
        ValidPunish = 0
        PunishStart = 0
        PunishFinish = 0
    else:
        phase1_result_time = 4 # 13 # this is the duration for showing the results
        FillerPunish = 0
        ValidPunish = 1
        PunishStart = 1
        PunishFinish = 3 # 10 # this is the duration
        
    pairing_sub_6.setSize(pairsize2)
    result.setImage(stipic)
    punish_text2.setOpacity(ValidPunish)
    punish_text2.setText('对方需观看负性情绪图片')
    punish_text2.setHeight(bottom_textsize)
    FillerText.setOpacity(FillerPunish)
    PunishImg.setSize(punishpicsize)
    # keep track of which components have finished
    guilt_resultComponents = [pairing_sub_6, result, punish_text2, FillerText, PuPicText, PunishImg, Ellipsis]
    for thisComponent in guilt_resultComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_resultClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_result"-------
    while continueRoutine:
        # get current time
        t = guilt_resultClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_resultClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        #if t>(PunishStart+5):
        #    punish_pic_text = u'Image 2 is presenting'
        #else:
        #    punish_pic_text = u'Image 1 is presenting'
        
        #punish_pic_text = u'Aversive image is presenting'
        
        if t-PunishStart>timejit[0]:
            EllipsisText = ellis [count%3] 
            count = count+1
            timejit = timejit[1:]
        elif t<PunishStart:
            EllipsisText = ellis [0] 
        
        # *pairing_sub_6* updates
        if pairing_sub_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_6.frameNStart = frameN  # exact frame index
            pairing_sub_6.tStart = t  # local t and not account for scr refresh
            pairing_sub_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_6, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_6.setAutoDraw(True)
        if pairing_sub_6.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_6.tStartRefresh + phase1_result_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_6.tStop = t  # not accounting for scr refresh
                pairing_sub_6.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_6, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_6.setAutoDraw(False)
        
        # *result* updates
        if result.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result.frameNStart = frameN  # exact frame index
            result.tStart = t  # local t and not account for scr refresh
            result.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result, 'tStartRefresh')  # time at next scr refresh
            result.setAutoDraw(True)
        if result.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > result.tStartRefresh + phase1_result_time-frameTolerance:
                # keep track of stop time/frame for later
                result.tStop = t  # not accounting for scr refresh
                result.frameNStop = frameN  # exact frame index
                win.timeOnFlip(result, 'tStopRefresh')  # time at next scr refresh
                result.setAutoDraw(False)
        
        # *punish_text2* updates
        if punish_text2.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            punish_text2.frameNStart = frameN  # exact frame index
            punish_text2.tStart = t  # local t and not account for scr refresh
            punish_text2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(punish_text2, 'tStartRefresh')  # time at next scr refresh
            punish_text2.setAutoDraw(True)
        if punish_text2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > punish_text2.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                punish_text2.tStop = t  # not accounting for scr refresh
                punish_text2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(punish_text2, 'tStopRefresh')  # time at next scr refresh
                punish_text2.setAutoDraw(False)
        
        # *FillerText* updates
        if FillerText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            FillerText.frameNStart = frameN  # exact frame index
            FillerText.tStart = t  # local t and not account for scr refresh
            FillerText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(FillerText, 'tStartRefresh')  # time at next scr refresh
            FillerText.setAutoDraw(True)
        if FillerText.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > FillerText.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                FillerText.tStop = t  # not accounting for scr refresh
                FillerText.frameNStop = frameN  # exact frame index
                win.timeOnFlip(FillerText, 'tStopRefresh')  # time at next scr refresh
                FillerText.setAutoDraw(False)
        
        # *PuPicText* updates
        if PuPicText.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            PuPicText.frameNStart = frameN  # exact frame index
            PuPicText.tStart = t  # local t and not account for scr refresh
            PuPicText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PuPicText, 'tStartRefresh')  # time at next scr refresh
            PuPicText.setAutoDraw(True)
        if PuPicText.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PuPicText.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                PuPicText.tStop = t  # not accounting for scr refresh
                PuPicText.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PuPicText, 'tStopRefresh')  # time at next scr refresh
                PuPicText.setAutoDraw(False)
        
        # *PunishImg* updates
        if PunishImg.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            PunishImg.frameNStart = frameN  # exact frame index
            PunishImg.tStart = t  # local t and not account for scr refresh
            PunishImg.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PunishImg, 'tStartRefresh')  # time at next scr refresh
            PunishImg.setAutoDraw(True)
        if PunishImg.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PunishImg.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                PunishImg.tStop = t  # not accounting for scr refresh
                PunishImg.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PunishImg, 'tStopRefresh')  # time at next scr refresh
                PunishImg.setAutoDraw(False)
        
        # *Ellipsis* updates
        if Ellipsis.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            Ellipsis.frameNStart = frameN  # exact frame index
            Ellipsis.tStart = t  # local t and not account for scr refresh
            Ellipsis.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ellipsis, 'tStartRefresh')  # time at next scr refresh
            Ellipsis.setAutoDraw(True)
        if Ellipsis.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Ellipsis.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                Ellipsis.tStop = t  # not accounting for scr refresh
                Ellipsis.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Ellipsis, 'tStopRefresh')  # time at next scr refresh
                Ellipsis.setAutoDraw(False)
        if Ellipsis.status == STARTED:  # only update if drawing
            Ellipsis.setText(EllipsisText, log=False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_resultComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_result"-------
    for thisComponent in guilt_resultComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('PunishImg.started', PunishImg.tStartRefresh)
    trialseq.addData('PunishImg.stopped', PunishImg.tStopRefresh)
    # the Routine "guilt_result" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_guilt"-------
    continueRoutine = True
    # update component parameters for each repeat
    slider_guilt.reset()
    key_guilt.keys = []
    key_guilt.rt = []
    _key_guilt_allKeys = []
    if (DV != 0) | (type_trial==0) |(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial.setImage(stipic)
    # keep track of which components have finished
    DV_guiltComponents = [slider_guilt, text_8, key_guilt, text_9, text_17, pairing_sub_cur_trial, result_cur_trial, time_reminder]
    for thisComponent in DV_guiltComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_guiltClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_guilt"-------
    while continueRoutine:
        # get current time
        t = DV_guiltClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_guiltClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *slider_guilt* updates
        if slider_guilt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_guilt.frameNStart = frameN  # exact frame index
            slider_guilt.tStart = t  # local t and not account for scr refresh
            slider_guilt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_guilt, 'tStartRefresh')  # time at next scr refresh
            slider_guilt.setAutoDraw(True)
        
        # *text_8* updates
        if text_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_8.frameNStart = frameN  # exact frame index
            text_8.tStart = t  # local t and not account for scr refresh
            text_8.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_8, 'tStartRefresh')  # time at next scr refresh
            text_8.setAutoDraw(True)
        
        # *key_guilt* updates
        waitOnFlip = False
        if key_guilt.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_guilt.frameNStart = frameN  # exact frame index
            key_guilt.tStart = t  # local t and not account for scr refresh
            key_guilt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_guilt, 'tStartRefresh')  # time at next scr refresh
            key_guilt.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_guilt.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_guilt.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_guilt.status == STARTED and not waitOnFlip:
            theseKeys = key_guilt.getKeys(keyList=['space'], waitRelease=False)
            _key_guilt_allKeys.extend(theseKeys)
            if len(_key_guilt_allKeys):
                key_guilt.keys = _key_guilt_allKeys[-1].name  # just the last key pressed
                key_guilt.rt = _key_guilt_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        logic1=(slider_guilt.getRating()!=None)
        if logic1:
           
            temp=1
        
        
        # *text_9* updates
        if text_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_9.frameNStart = frameN  # exact frame index
            text_9.tStart = t  # local t and not account for scr refresh
            text_9.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
            text_9.setAutoDraw(True)
        
        # *text_17* updates
        if text_17.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            text_17.frameNStart = frameN  # exact frame index
            text_17.tStart = t  # local t and not account for scr refresh
            text_17.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_17, 'tStartRefresh')  # time at next scr refresh
            text_17.setAutoDraw(True)
        
        # *pairing_sub_cur_trial* updates
        if pairing_sub_cur_trial.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial.setAutoDraw(True)
        
        # *result_cur_trial* updates
        if result_cur_trial.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial.frameNStart = frameN  # exact frame index
            result_cur_trial.tStart = t  # local t and not account for scr refresh
            result_cur_trial.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial.setAutoDraw(True)
        
        # *time_reminder* updates
        if time_reminder.status == NOT_STARTED and tThisFlip >= 10-frameTolerance:
            # keep track of start time/frame for later
            time_reminder.frameNStart = frameN  # exact frame index
            time_reminder.tStart = t  # local t and not account for scr refresh
            time_reminder.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder, 'tStartRefresh')  # time at next scr refresh
            time_reminder.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_guiltComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_guilt"-------
    for thisComponent in DV_guiltComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('slider_guilt.response', slider_guilt.getRating())
    trialseq.addData('slider_guilt.rt', slider_guilt.getRT())
    trialseq.addData('slider_guilt.started', slider_guilt.tStartRefresh)
    trialseq.addData('slider_guilt.stopped', slider_guilt.tStopRefresh)
    trialseq.addData('text_8.started', text_8.tStartRefresh)
    trialseq.addData('text_8.stopped', text_8.tStopRefresh)
    # check responses
    if key_guilt.keys in ['', [], None]:  # No response was made
        key_guilt.keys = None
    trialseq.addData('key_guilt.keys',key_guilt.keys)
    if key_guilt.keys != None:  # we had a response
        trialseq.addData('key_guilt.rt', key_guilt.rt)
    trialseq.addData('key_guilt.started', key_guilt.tStartRefresh)
    trialseq.addData('key_guilt.stopped', key_guilt.tStopRefresh)
    trialseq.addData('text_9.started', text_9.tStartRefresh)
    trialseq.addData('text_9.stopped', text_9.tStopRefresh)
    trialseq.addData('text_17.started', text_17.tStartRefresh)
    trialseq.addData('text_17.stopped', text_17.tStopRefresh)
    trialseq.addData('pairing_sub_cur_trial.started', pairing_sub_cur_trial.tStartRefresh)
    trialseq.addData('pairing_sub_cur_trial.stopped', pairing_sub_cur_trial.tStopRefresh)
    trialseq.addData('result_cur_trial.started', result_cur_trial.tStartRefresh)
    trialseq.addData('result_cur_trial.stopped', result_cur_trial.tStopRefresh)
    trialseq.addData('time_reminder.started', time_reminder.tStartRefresh)
    trialseq.addData('time_reminder.stopped', time_reminder.tStopRefresh)
    # the Routine "DV_guilt" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_sharing"-------
    continueRoutine = True
    # update component parameters for each repeat
    share_slider.reset()
    key_share.keys = []
    key_share.rt = []
    _key_share_allKeys = []
    if (DV != 1) | (type_trial==0)|(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial_2.setImage(stipic)
    # keep track of which components have finished
    DV_sharingComponents = [share_slider, share_text, key_share, text_29, pairing_sub_cur_trial_2, result_cur_trial_2, time_reminder2]
    for thisComponent in DV_sharingComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_sharingClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_sharing"-------
    while continueRoutine:
        # get current time
        t = DV_sharingClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_sharingClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *share_slider* updates
        if share_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            share_slider.frameNStart = frameN  # exact frame index
            share_slider.tStart = t  # local t and not account for scr refresh
            share_slider.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(share_slider, 'tStartRefresh')  # time at next scr refresh
            share_slider.setAutoDraw(True)
        
        # *share_text* updates
        if share_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            share_text.frameNStart = frameN  # exact frame index
            share_text.tStart = t  # local t and not account for scr refresh
            share_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(share_text, 'tStartRefresh')  # time at next scr refresh
            share_text.setAutoDraw(True)
        
        # *key_share* updates
        waitOnFlip = False
        if key_share.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_share.frameNStart = frameN  # exact frame index
            key_share.tStart = t  # local t and not account for scr refresh
            key_share.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_share, 'tStartRefresh')  # time at next scr refresh
            key_share.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_share.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_share.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_share.status == STARTED and not waitOnFlip:
            theseKeys = key_share.getKeys(keyList=['space'], waitRelease=False)
            _key_share_allKeys.extend(theseKeys)
            if len(_key_share_allKeys):
                key_share.keys = _key_share_allKeys[-1].name  # just the last key pressed
                key_share.rt = _key_share_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        if share_slider.getRating()!=None:
           
            temp=1
        
        # *text_29* updates
        if text_29.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            text_29.frameNStart = frameN  # exact frame index
            text_29.tStart = t  # local t and not account for scr refresh
            text_29.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_29, 'tStartRefresh')  # time at next scr refresh
            text_29.setAutoDraw(True)
        
        # *pairing_sub_cur_trial_2* updates
        if pairing_sub_cur_trial_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial_2.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial_2.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial_2, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial_2.setAutoDraw(True)
        
        # *result_cur_trial_2* updates
        if result_cur_trial_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial_2.frameNStart = frameN  # exact frame index
            result_cur_trial_2.tStart = t  # local t and not account for scr refresh
            result_cur_trial_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial_2, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial_2.setAutoDraw(True)
        
        # *time_reminder2* updates
        if time_reminder2.status == NOT_STARTED and tThisFlip >= 10-frameTolerance:
            # keep track of start time/frame for later
            time_reminder2.frameNStart = frameN  # exact frame index
            time_reminder2.tStart = t  # local t and not account for scr refresh
            time_reminder2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder2, 'tStartRefresh')  # time at next scr refresh
            time_reminder2.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_sharingComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_sharing"-------
    for thisComponent in DV_sharingComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('share_slider.response', share_slider.getRating())
    trialseq.addData('share_slider.rt', share_slider.getRT())
    trialseq.addData('share_slider.started', share_slider.tStartRefresh)
    trialseq.addData('share_slider.stopped', share_slider.tStopRefresh)
    trialseq.addData('share_text.started', share_text.tStartRefresh)
    trialseq.addData('share_text.stopped', share_text.tStopRefresh)
    # check responses
    if key_share.keys in ['', [], None]:  # No response was made
        key_share.keys = None
    trialseq.addData('key_share.keys',key_share.keys)
    if key_share.keys != None:  # we had a response
        trialseq.addData('key_share.rt', key_share.rt)
    trialseq.addData('key_share.started', key_share.tStartRefresh)
    trialseq.addData('key_share.stopped', key_share.tStopRefresh)
    trialseq.addData('text_29.started', text_29.tStartRefresh)
    trialseq.addData('text_29.stopped', text_29.tStopRefresh)
    trialseq.addData('pairing_sub_cur_trial_2.started', pairing_sub_cur_trial_2.tStartRefresh)
    trialseq.addData('pairing_sub_cur_trial_2.stopped', pairing_sub_cur_trial_2.tStopRefresh)
    trialseq.addData('result_cur_trial_2.started', result_cur_trial_2.tStartRefresh)
    trialseq.addData('result_cur_trial_2.stopped', result_cur_trial_2.tStopRefresh)
    trialseq.addData('time_reminder2.started', time_reminder2.tStartRefresh)
    trialseq.addData('time_reminder2.stopped', time_reminder2.tStopRefresh)
    # append compensation choice for this trial
    share_choice.append(share_slider.getRating())
    # the Routine "DV_sharing" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_approach_avoidance"-------
    continueRoutine = True
    # update component parameters for each repeat
    slider_apology.reset()
    key_apology.keys = []
    key_apology.rt = []
    _key_apology_allKeys = []
    slider_hide.reset()
    if (DV != 2) | (type_trial==0)|(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial_3.setImage(stipic)
    # keep track of which components have finished
    DV_approach_avoidanceComponents = [slider_apology, text_apology, key_apology, slider_hide, text_hide, text_31, pairing_sub_cur_trial_3, result_cur_trial_3, time_reminder3]
    for thisComponent in DV_approach_avoidanceComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_approach_avoidanceClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_approach_avoidance"-------
    while continueRoutine:
        # get current time
        t = DV_approach_avoidanceClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_approach_avoidanceClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *slider_apology* updates
        if slider_apology.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_apology.frameNStart = frameN  # exact frame index
            slider_apology.tStart = t  # local t and not account for scr refresh
            slider_apology.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_apology, 'tStartRefresh')  # time at next scr refresh
            slider_apology.setAutoDraw(True)
        
        # *text_apology* updates
        if text_apology.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_apology.frameNStart = frameN  # exact frame index
            text_apology.tStart = t  # local t and not account for scr refresh
            text_apology.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_apology, 'tStartRefresh')  # time at next scr refresh
            text_apology.setAutoDraw(True)
        
        # *key_apology* updates
        waitOnFlip = False
        if key_apology.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_apology.frameNStart = frameN  # exact frame index
            key_apology.tStart = t  # local t and not account for scr refresh
            key_apology.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_apology, 'tStartRefresh')  # time at next scr refresh
            key_apology.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_apology.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_apology.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_apology.status == STARTED and not waitOnFlip:
            theseKeys = key_apology.getKeys(keyList=['space'], waitRelease=False)
            _key_apology_allKeys.extend(theseKeys)
            if len(_key_apology_allKeys):
                key_apology.keys = _key_apology_allKeys[-1].name  # just the last key pressed
                key_apology.rt = _key_apology_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *slider_hide* updates
        if slider_hide.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_hide.frameNStart = frameN  # exact frame index
            slider_hide.tStart = t  # local t and not account for scr refresh
            slider_hide.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_hide, 'tStartRefresh')  # time at next scr refresh
            slider_hide.setAutoDraw(True)
        
        # *text_hide* updates
        if text_hide.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_hide.frameNStart = frameN  # exact frame index
            text_hide.tStart = t  # local t and not account for scr refresh
            text_hide.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_hide, 'tStartRefresh')  # time at next scr refresh
            text_hide.setAutoDraw(True)
        logic3 = (slider_apology.getRating() is not None) and (slider_hide.getRating() is not None)
        
        if logic3:
            temp = 1
        
        
        
        # *text_31* updates
        if text_31.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            text_31.frameNStart = frameN  # exact frame index
            text_31.tStart = t  # local t and not account for scr refresh
            text_31.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_31, 'tStartRefresh')  # time at next scr refresh
            text_31.setAutoDraw(True)
        
        # *pairing_sub_cur_trial_3* updates
        if pairing_sub_cur_trial_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial_3.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial_3.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial_3, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial_3.setAutoDraw(True)
        
        # *result_cur_trial_3* updates
        if result_cur_trial_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial_3.frameNStart = frameN  # exact frame index
            result_cur_trial_3.tStart = t  # local t and not account for scr refresh
            result_cur_trial_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial_3, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial_3.setAutoDraw(True)
        
        # *time_reminder3* updates
        if time_reminder3.status == NOT_STARTED and tThisFlip >= 20-frameTolerance:
            # keep track of start time/frame for later
            time_reminder3.frameNStart = frameN  # exact frame index
            time_reminder3.tStart = t  # local t and not account for scr refresh
            time_reminder3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder3, 'tStartRefresh')  # time at next scr refresh
            time_reminder3.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_approach_avoidanceComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_approach_avoidance"-------
    for thisComponent in DV_approach_avoidanceComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('slider_apology.response', slider_apology.getRating())
    trialseq.addData('slider_apology.rt', slider_apology.getRT())
    trialseq.addData('slider_apology.started', slider_apology.tStartRefresh)
    trialseq.addData('slider_apology.stopped', slider_apology.tStopRefresh)
    trialseq.addData('text_apology.started', text_apology.tStartRefresh)
    trialseq.addData('text_apology.stopped', text_apology.tStopRefresh)
    # check responses
    if key_apology.keys in ['', [], None]:  # No response was made
        key_apology.keys = None
    trialseq.addData('key_apology.keys',key_apology.keys)
    if key_apology.keys != None:  # we had a response
        trialseq.addData('key_apology.rt', key_apology.rt)
    trialseq.addData('key_apology.started', key_apology.tStartRefresh)
    trialseq.addData('key_apology.stopped', key_apology.tStopRefresh)
    trialseq.addData('slider_hide.response', slider_hide.getRating())
    trialseq.addData('slider_hide.rt', slider_hide.getRT())
    trialseq.addData('slider_hide.started', slider_hide.tStartRefresh)
    trialseq.addData('slider_hide.stopped', slider_hide.tStopRefresh)
    trialseq.addData('text_hide.started', text_hide.tStartRefresh)
    trialseq.addData('text_hide.stopped', text_hide.tStopRefresh)
    trialseq.addData('text_31.started', text_31.tStartRefresh)
    trialseq.addData('text_31.stopped', text_31.tStopRefresh)
    trialseq.addData('pairing_sub_cur_trial_3.started', pairing_sub_cur_trial_3.tStartRefresh)
    trialseq.addData('pairing_sub_cur_trial_3.stopped', pairing_sub_cur_trial_3.tStopRefresh)
    trialseq.addData('result_cur_trial_3.started', result_cur_trial_3.tStartRefresh)
    trialseq.addData('result_cur_trial_3.stopped', result_cur_trial_3.tStopRefresh)
    trialseq.addData('time_reminder3.started', time_reminder3.tStartRefresh)
    trialseq.addData('time_reminder3.stopped', time_reminder3.tStopRefresh)
    # the Routine "DV_approach_avoidance" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_forgiveness"-------
    continueRoutine = True
    # update component parameters for each repeat
    slider_forgiveness.reset()
    key_forgiveness.keys = []
    key_forgiveness.rt = []
    _key_forgiveness_allKeys = []
    slider_mad.reset()
    if (DV != 3) | (type_trial==0)|(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial_4.setImage(stipic)
    # keep track of which components have finished
    DV_forgivenessComponents = [slider_forgiveness, text_forgiveness, key_forgiveness, slider_mad, text_mad, text_19, pairing_sub_cur_trial_4, result_cur_trial_4, time_reminder4]
    for thisComponent in DV_forgivenessComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_forgivenessClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_forgiveness"-------
    while continueRoutine:
        # get current time
        t = DV_forgivenessClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_forgivenessClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *slider_forgiveness* updates
        if slider_forgiveness.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_forgiveness.frameNStart = frameN  # exact frame index
            slider_forgiveness.tStart = t  # local t and not account for scr refresh
            slider_forgiveness.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_forgiveness, 'tStartRefresh')  # time at next scr refresh
            slider_forgiveness.setAutoDraw(True)
        
        # *text_forgiveness* updates
        if text_forgiveness.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_forgiveness.frameNStart = frameN  # exact frame index
            text_forgiveness.tStart = t  # local t and not account for scr refresh
            text_forgiveness.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_forgiveness, 'tStartRefresh')  # time at next scr refresh
            text_forgiveness.setAutoDraw(True)
        
        # *key_forgiveness* updates
        waitOnFlip = False
        if key_forgiveness.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_forgiveness.frameNStart = frameN  # exact frame index
            key_forgiveness.tStart = t  # local t and not account for scr refresh
            key_forgiveness.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_forgiveness, 'tStartRefresh')  # time at next scr refresh
            key_forgiveness.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_forgiveness.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_forgiveness.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_forgiveness.status == STARTED and not waitOnFlip:
            theseKeys = key_forgiveness.getKeys(keyList=['space'], waitRelease=False)
            _key_forgiveness_allKeys.extend(theseKeys)
            if len(_key_forgiveness_allKeys):
                key_forgiveness.keys = _key_forgiveness_allKeys[-1].name  # just the last key pressed
                key_forgiveness.rt = _key_forgiveness_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *slider_mad* updates
        if slider_mad.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_mad.frameNStart = frameN  # exact frame index
            slider_mad.tStart = t  # local t and not account for scr refresh
            slider_mad.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_mad, 'tStartRefresh')  # time at next scr refresh
            slider_mad.setAutoDraw(True)
        
        # *text_mad* updates
        if text_mad.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_mad.frameNStart = frameN  # exact frame index
            text_mad.tStart = t  # local t and not account for scr refresh
            text_mad.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_mad, 'tStartRefresh')  # time at next scr refresh
            text_mad.setAutoDraw(True)
        logic4 = (slider_forgiveness.getRating() is not None) and (slider_mad.getRating() is not None)
        
        if logic4:
            temp = 1
        
        # *text_19* updates
        if text_19.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_19.frameNStart = frameN  # exact frame index
            text_19.tStart = t  # local t and not account for scr refresh
            text_19.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_19, 'tStartRefresh')  # time at next scr refresh
            text_19.setAutoDraw(True)
        
        # *pairing_sub_cur_trial_4* updates
        if pairing_sub_cur_trial_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial_4.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial_4.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial_4, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial_4.setAutoDraw(True)
        
        # *result_cur_trial_4* updates
        if result_cur_trial_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial_4.frameNStart = frameN  # exact frame index
            result_cur_trial_4.tStart = t  # local t and not account for scr refresh
            result_cur_trial_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial_4, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial_4.setAutoDraw(True)
        
        # *time_reminder4* updates
        if time_reminder4.status == NOT_STARTED and tThisFlip >= 20-frameTolerance:
            # keep track of start time/frame for later
            time_reminder4.frameNStart = frameN  # exact frame index
            time_reminder4.tStart = t  # local t and not account for scr refresh
            time_reminder4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder4, 'tStartRefresh')  # time at next scr refresh
            time_reminder4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_forgivenessComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_forgiveness"-------
    for thisComponent in DV_forgivenessComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trialseq.addData('slider_forgiveness.response', slider_forgiveness.getRating())
    trialseq.addData('slider_forgiveness.rt', slider_forgiveness.getRT())
    trialseq.addData('slider_forgiveness.started', slider_forgiveness.tStartRefresh)
    trialseq.addData('slider_forgiveness.stopped', slider_forgiveness.tStopRefresh)
    trialseq.addData('text_forgiveness.started', text_forgiveness.tStartRefresh)
    trialseq.addData('text_forgiveness.stopped', text_forgiveness.tStopRefresh)
    # check responses
    if key_forgiveness.keys in ['', [], None]:  # No response was made
        key_forgiveness.keys = None
    trialseq.addData('key_forgiveness.keys',key_forgiveness.keys)
    if key_forgiveness.keys != None:  # we had a response
        trialseq.addData('key_forgiveness.rt', key_forgiveness.rt)
    trialseq.addData('key_forgiveness.started', key_forgiveness.tStartRefresh)
    trialseq.addData('key_forgiveness.stopped', key_forgiveness.tStopRefresh)
    trialseq.addData('slider_mad.response', slider_mad.getRating())
    trialseq.addData('slider_mad.rt', slider_mad.getRT())
    trialseq.addData('slider_mad.started', slider_mad.tStartRefresh)
    trialseq.addData('slider_mad.stopped', slider_mad.tStopRefresh)
    trialseq.addData('text_mad.started', text_mad.tStartRefresh)
    trialseq.addData('text_mad.stopped', text_mad.tStopRefresh)
    trialseq.addData('text_19.started', text_19.tStartRefresh)
    trialseq.addData('text_19.stopped', text_19.tStopRefresh)
    trialseq.addData('pairing_sub_cur_trial_4.started', pairing_sub_cur_trial_4.tStartRefresh)
    trialseq.addData('pairing_sub_cur_trial_4.stopped', pairing_sub_cur_trial_4.tStopRefresh)
    trialseq.addData('result_cur_trial_4.started', result_cur_trial_4.tStartRefresh)
    trialseq.addData('result_cur_trial_4.stopped', result_cur_trial_4.tStopRefresh)
    trialseq.addData('time_reminder4.started', time_reminder4.tStartRefresh)
    trialseq.addData('time_reminder4.stopped', time_reminder4.tStopRefresh)
    # the Routine "DV_forgiveness" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trialseq'


# ------Prepare to start Routine "ave_img_end"-------
continueRoutine = True
# update component parameters for each repeat
print(f"Before presenting aversive images, show share choice: \n {share_choice}")

if len(incompleteTrials) == 0 or redo_flag == 1:
    # all trials are completed, escape
    continueRoutine = True
    #Remove None values from the list
    cleaned_share_choice = [x for x in share_choice if x is not None]
    share_choice_mean = sum(cleaned_share_choice)/len(cleaned_share_choice)
    print(f"share choice mean is:{share_choice_mean}")
else:
    continueRoutine = False
    share_choice_mean = 0 # skip this trial
# keep track of which components have finished
ave_img_endComponents = [text_4, ave_img2, text_5]
for thisComponent in ave_img_endComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ave_img_endClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "ave_img_end"-------
while continueRoutine:
    # get current time
    t = ave_img_endClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ave_img_endClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_4* updates
    if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_4.frameNStart = frameN  # exact frame index
        text_4.tStart = t  # local t and not account for scr refresh
        text_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
        text_4.setAutoDraw(True)
    if text_4.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_4.tStartRefresh + 4-frameTolerance:
            # keep track of stop time/frame for later
            text_4.tStop = t  # not accounting for scr refresh
            text_4.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_4, 'tStopRefresh')  # time at next scr refresh
            text_4.setAutoDraw(False)
    
    # *ave_img2* updates
    if ave_img2.status == NOT_STARTED and tThisFlip >= 4-frameTolerance:
        # keep track of start time/frame for later
        ave_img2.frameNStart = frameN  # exact frame index
        ave_img2.tStart = t  # local t and not account for scr refresh
        ave_img2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(ave_img2, 'tStartRefresh')  # time at next scr refresh
        ave_img2.setAutoDraw(True)
    if ave_img2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > ave_img2.tStartRefresh + share_choice_mean-frameTolerance:
            # keep track of stop time/frame for later
            ave_img2.tStop = t  # not accounting for scr refresh
            ave_img2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(ave_img2, 'tStopRefresh')  # time at next scr refresh
            ave_img2.setAutoDraw(False)
    
    # *text_5* updates
    if text_5.status == NOT_STARTED and tThisFlip >= 4-frameTolerance:
        # keep track of start time/frame for later
        text_5.frameNStart = frameN  # exact frame index
        text_5.tStart = t  # local t and not account for scr refresh
        text_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
        text_5.setAutoDraw(True)
    if text_5.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_5.tStartRefresh + share_choice_mean-frameTolerance:
            # keep track of stop time/frame for later
            text_5.tStop = t  # not accounting for scr refresh
            text_5.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_5, 'tStopRefresh')  # time at next scr refresh
            text_5.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ave_img_endComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ave_img_end"-------
for thisComponent in ave_img_endComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_4.started', text_4.tStartRefresh)
thisExp.addData('text_4.stopped', text_4.tStopRefresh)
thisExp.addData('ave_img2.started', ave_img2.tStartRefresh)
thisExp.addData('ave_img2.stopped', ave_img2.tStopRefresh)
thisExp.addData('text_5.started', text_5.tStartRefresh)
thisExp.addData('text_5.stopped', text_5.tStopRefresh)
# the Routine "ave_img_end" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "holistic_impression"-------
continueRoutine = True
# update component parameters for each repeat
print(f"all complete? {incompleteTrials}")

if len(incompleteTrials) == 0 or redo_flag == 1:
    # all trials are completed, escape
    continueRoutine = True
else:
    continueRoutine = False # skip this trial
slider_friendly.reset()
slider_trustworthy.reset()
slider_competence.reset()
slider_critical.reset()
key_resp.keys = []
key_resp.rt = []
_key_resp_allKeys = []
# keep track of which components have finished
holistic_impressionComponents = [text_20, text_friendly, slider_friendly, text_trustworthy, slider_trustworthy, text_21, slider_competence, text_22, slider_critical, text_space, key_resp]
for thisComponent in holistic_impressionComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
holistic_impressionClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "holistic_impression"-------
while continueRoutine:
    # get current time
    t = holistic_impressionClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=holistic_impressionClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    logic5=(slider_friendly.getRating()!=None) and \
    (slider_trustworthy.getRating()!=None) and \
    (slider_competence.getRating()!=None) and \
    (slider_critical.getRating()!=None)
    
    if logic5:
       
        state_complete = 1
    
    
    # *text_20* updates
    if text_20.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_20.frameNStart = frameN  # exact frame index
        text_20.tStart = t  # local t and not account for scr refresh
        text_20.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_20, 'tStartRefresh')  # time at next scr refresh
        text_20.setAutoDraw(True)
    
    # *text_friendly* updates
    if text_friendly.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_friendly.frameNStart = frameN  # exact frame index
        text_friendly.tStart = t  # local t and not account for scr refresh
        text_friendly.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_friendly, 'tStartRefresh')  # time at next scr refresh
        text_friendly.setAutoDraw(True)
    
    # *slider_friendly* updates
    if slider_friendly.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_friendly.frameNStart = frameN  # exact frame index
        slider_friendly.tStart = t  # local t and not account for scr refresh
        slider_friendly.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_friendly, 'tStartRefresh')  # time at next scr refresh
        slider_friendly.setAutoDraw(True)
    
    # *text_trustworthy* updates
    if text_trustworthy.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_trustworthy.frameNStart = frameN  # exact frame index
        text_trustworthy.tStart = t  # local t and not account for scr refresh
        text_trustworthy.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_trustworthy, 'tStartRefresh')  # time at next scr refresh
        text_trustworthy.setAutoDraw(True)
    
    # *slider_trustworthy* updates
    if slider_trustworthy.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_trustworthy.frameNStart = frameN  # exact frame index
        slider_trustworthy.tStart = t  # local t and not account for scr refresh
        slider_trustworthy.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_trustworthy, 'tStartRefresh')  # time at next scr refresh
        slider_trustworthy.setAutoDraw(True)
    
    # *text_21* updates
    if text_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_21.frameNStart = frameN  # exact frame index
        text_21.tStart = t  # local t and not account for scr refresh
        text_21.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_21, 'tStartRefresh')  # time at next scr refresh
        text_21.setAutoDraw(True)
    
    # *slider_competence* updates
    if slider_competence.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_competence.frameNStart = frameN  # exact frame index
        slider_competence.tStart = t  # local t and not account for scr refresh
        slider_competence.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_competence, 'tStartRefresh')  # time at next scr refresh
        slider_competence.setAutoDraw(True)
    
    # *text_22* updates
    if text_22.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_22.frameNStart = frameN  # exact frame index
        text_22.tStart = t  # local t and not account for scr refresh
        text_22.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_22, 'tStartRefresh')  # time at next scr refresh
        text_22.setAutoDraw(True)
    
    # *slider_critical* updates
    if slider_critical.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_critical.frameNStart = frameN  # exact frame index
        slider_critical.tStart = t  # local t and not account for scr refresh
        slider_critical.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_critical, 'tStartRefresh')  # time at next scr refresh
        slider_critical.setAutoDraw(True)
    
    # *text_space* updates
    if text_space.status == NOT_STARTED and state_complete==1:
        # keep track of start time/frame for later
        text_space.frameNStart = frameN  # exact frame index
        text_space.tStart = t  # local t and not account for scr refresh
        text_space.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_space, 'tStartRefresh')  # time at next scr refresh
        text_space.setAutoDraw(True)
    
    # *key_resp* updates
    waitOnFlip = False
    if key_resp.status == NOT_STARTED and state_complete==1:
        # keep track of start time/frame for later
        key_resp.frameNStart = frameN  # exact frame index
        key_resp.tStart = t  # local t and not account for scr refresh
        key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp.status == STARTED and not waitOnFlip:
        theseKeys = key_resp.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_allKeys.extend(theseKeys)
        if len(_key_resp_allKeys):
            key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
            key_resp.rt = _key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in holistic_impressionComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "holistic_impression"-------
for thisComponent in holistic_impressionComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_20.started', text_20.tStartRefresh)
thisExp.addData('text_20.stopped', text_20.tStopRefresh)
thisExp.addData('text_friendly.started', text_friendly.tStartRefresh)
thisExp.addData('text_friendly.stopped', text_friendly.tStopRefresh)
thisExp.addData('slider_friendly.response', slider_friendly.getRating())
thisExp.addData('slider_friendly.rt', slider_friendly.getRT())
thisExp.addData('slider_friendly.started', slider_friendly.tStartRefresh)
thisExp.addData('slider_friendly.stopped', slider_friendly.tStopRefresh)
thisExp.addData('text_trustworthy.started', text_trustworthy.tStartRefresh)
thisExp.addData('text_trustworthy.stopped', text_trustworthy.tStopRefresh)
thisExp.addData('slider_trustworthy.response', slider_trustworthy.getRating())
thisExp.addData('slider_trustworthy.rt', slider_trustworthy.getRT())
thisExp.addData('slider_trustworthy.started', slider_trustworthy.tStartRefresh)
thisExp.addData('slider_trustworthy.stopped', slider_trustworthy.tStopRefresh)
thisExp.addData('text_21.started', text_21.tStartRefresh)
thisExp.addData('text_21.stopped', text_21.tStopRefresh)
thisExp.addData('slider_competence.response', slider_competence.getRating())
thisExp.addData('slider_competence.rt', slider_competence.getRT())
thisExp.addData('slider_competence.started', slider_competence.tStartRefresh)
thisExp.addData('slider_competence.stopped', slider_competence.tStopRefresh)
thisExp.addData('text_22.started', text_22.tStartRefresh)
thisExp.addData('text_22.stopped', text_22.tStopRefresh)
thisExp.addData('slider_critical.response', slider_critical.getRating())
thisExp.addData('slider_critical.rt', slider_critical.getRT())
thisExp.addData('slider_critical.started', slider_critical.tStartRefresh)
thisExp.addData('slider_critical.stopped', slider_critical.tStopRefresh)
thisExp.addData('text_space.started', text_space.tStartRefresh)
thisExp.addData('text_space.stopped', text_space.tStopRefresh)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
thisExp.addData('key_resp.keys',key_resp.keys)
if key_resp.keys != None:  # we had a response
    thisExp.addData('key_resp.rt', key_resp.rt)
thisExp.addData('key_resp.started', key_resp.tStartRefresh)
thisExp.addData('key_resp.stopped', key_resp.tStopRefresh)
thisExp.nextEntry()
# the Routine "holistic_impression" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "check_incomplete"-------
continueRoutine = True
routineTimer.add(8.000000)
# update component parameters for each repeat
if not incompleteTrials:
    # all trials are completed, escape
    continueRoutine = True

else:
    continueRoutine = False

# add into data: now add in every incomplete trial
# thisExp.addData('incompleteTrials',incompleteTrials)
# keep track of which components have finished
check_incompleteComponents = [text_11]
for thisComponent in check_incompleteComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
check_incompleteClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "check_incomplete"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = check_incompleteClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=check_incompleteClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_11* updates
    if text_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_11.frameNStart = frameN  # exact frame index
        text_11.tStart = t  # local t and not account for scr refresh
        text_11.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_11, 'tStartRefresh')  # time at next scr refresh
        text_11.setAutoDraw(True)
    if text_11.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_11.tStartRefresh + 8-frameTolerance:
            # keep track of stop time/frame for later
            text_11.tStop = t  # not accounting for scr refresh
            text_11.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_11, 'tStopRefresh')  # time at next scr refresh
            text_11.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in check_incompleteComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "check_incomplete"-------
for thisComponent in check_incompleteComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
if not incompleteTrials:
    # make sure everything is closed down
    thisExp.abort()  # or data files will save again on exit
    win.close()
    core.quit()
thisExp.addData('text_11.started', text_11.tStartRefresh)
thisExp.addData('text_11.stopped', text_11.tStopRefresh)

# set up handler to look after randomisation of conditions etc
trials_redo = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('condition.csv', selection=incompleteTrials),
    seed=None, name='trials_redo')
thisExp.addLoop(trials_redo)  # add the loop to the experiment
thisTrials_redo = trials_redo.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrials_redo.rgb)
if thisTrials_redo != None:
    for paramName in thisTrials_redo:
        exec('{} = thisTrials_redo[paramName]'.format(paramName))

for thisTrials_redo in trials_redo:
    currentLoop = trials_redo
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_redo.rgb)
    if thisTrials_redo != None:
        for paramName in thisTrials_redo:
            exec('{} = thisTrials_redo[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "guilt_pairing"-------
    continueRoutine = True
    # update component parameters for each repeat
    pairing_wait_time = random.random()+2
    count = 0
    timejit = timejitter
    pairing_sub.setPos(pairpos)
    pairing_sub.setSize(pairsize0)
    # keep track of which components have finished
    guilt_pairingComponents = [pairing_sub, pairing_wait, Ellipsis_2]
    for thisComponent in guilt_pairingComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_pairingClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_pairing"-------
    while continueRoutine:
        # get current time
        t = guilt_pairingClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_pairingClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        if t>timejit[0]:
            EllipsisText = ellis [count%3] 
            count = count+1
            timejit = timejit[1:]
        
        # *pairing_sub* updates
        if pairing_sub.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub.frameNStart = frameN  # exact frame index
            pairing_sub.tStart = t  # local t and not account for scr refresh
            pairing_sub.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub, 'tStartRefresh')  # time at next scr refresh
            pairing_sub.setAutoDraw(True)
        if pairing_sub.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub.tStartRefresh + pairing_wait_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub.tStop = t  # not accounting for scr refresh
                pairing_sub.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub, 'tStopRefresh')  # time at next scr refresh
                pairing_sub.setAutoDraw(False)
        
        # *pairing_wait* updates
        if pairing_wait.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_wait.frameNStart = frameN  # exact frame index
            pairing_wait.tStart = t  # local t and not account for scr refresh
            pairing_wait.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_wait, 'tStartRefresh')  # time at next scr refresh
            pairing_wait.setAutoDraw(True)
        if pairing_wait.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_wait.tStartRefresh + pairing_wait_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_wait.tStop = t  # not accounting for scr refresh
                pairing_wait.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_wait, 'tStopRefresh')  # time at next scr refresh
                pairing_wait.setAutoDraw(False)
        
        # *Ellipsis_2* updates
        if Ellipsis_2.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Ellipsis_2.frameNStart = frameN  # exact frame index
            Ellipsis_2.tStart = t  # local t and not account for scr refresh
            Ellipsis_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ellipsis_2, 'tStartRefresh')  # time at next scr refresh
            Ellipsis_2.setAutoDraw(True)
        if Ellipsis_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Ellipsis_2.tStartRefresh + pairing_wait_time-frameTolerance:
                # keep track of stop time/frame for later
                Ellipsis_2.tStop = t  # not accounting for scr refresh
                Ellipsis_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Ellipsis_2, 'tStopRefresh')  # time at next scr refresh
                Ellipsis_2.setAutoDraw(False)
        if Ellipsis_2.status == STARTED:  # only update if drawing
            Ellipsis_2.setText(EllipsisText, log=False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_pairingComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_pairing"-------
    for thisComponent in guilt_pairingComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "guilt_pairing" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "guilt_cue"-------
    continueRoutine = True
    # update component parameters for each repeat
    guilt_cue_time = 1
    
    pairing_sub_2.setSize(pairsize2)
    pairing_sub_2.setImage('Punish_Pair.png')
    attention.setHeight(bottom_textsize)
    # keep track of which components have finished
    guilt_cueComponents = [pairing_sub_2, attention]
    for thisComponent in guilt_cueComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_cueClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_cue"-------
    while continueRoutine:
        # get current time
        t = guilt_cueClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_cueClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_2* updates
        if pairing_sub_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_2.frameNStart = frameN  # exact frame index
            pairing_sub_2.tStart = t  # local t and not account for scr refresh
            pairing_sub_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_2, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_2.setAutoDraw(True)
        if pairing_sub_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_2.tStartRefresh + guilt_cue_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_2.tStop = t  # not accounting for scr refresh
                pairing_sub_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_2, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_2.setAutoDraw(False)
        
        # *attention* updates
        if attention.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            attention.frameNStart = frameN  # exact frame index
            attention.tStart = t  # local t and not account for scr refresh
            attention.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(attention, 'tStartRefresh')  # time at next scr refresh
            attention.setAutoDraw(True)
        if attention.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > attention.tStartRefresh + guilt_cue_time-frameTolerance:
                # keep track of stop time/frame for later
                attention.tStop = t  # not accounting for scr refresh
                attention.frameNStop = frameN  # exact frame index
                win.timeOnFlip(attention, 'tStopRefresh')  # time at next scr refresh
                attention.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_cueComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_cue"-------
    for thisComponent in guilt_cueComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "guilt_cue" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "guilt_sti"-------
    continueRoutine = True
    routineTimer.add(1.500000)
    # update component parameters for each repeat
    pairing_sub_3.setSize(pairsize2)
    pairing_sub_3.setImage('Punish_Pair.png')
    dotstipic.setImage(picture)
    # keep track of which components have finished
    guilt_stiComponents = [pairing_sub_3, dotstipic]
    for thisComponent in guilt_stiComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_stiClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_sti"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = guilt_stiClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_stiClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_3* updates
        if pairing_sub_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_3.frameNStart = frameN  # exact frame index
            pairing_sub_3.tStart = t  # local t and not account for scr refresh
            pairing_sub_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_3, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_3.setAutoDraw(True)
        if pairing_sub_3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_3.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_3.tStop = t  # not accounting for scr refresh
                pairing_sub_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_3, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_3.setAutoDraw(False)
        
        # *dotstipic* updates
        if dotstipic.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            dotstipic.frameNStart = frameN  # exact frame index
            dotstipic.tStart = t  # local t and not account for scr refresh
            dotstipic.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(dotstipic, 'tStartRefresh')  # time at next scr refresh
            dotstipic.setAutoDraw(True)
        if dotstipic.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > dotstipic.tStartRefresh + 1.5-frameTolerance:
                # keep track of stop time/frame for later
                dotstipic.tStop = t  # not accounting for scr refresh
                dotstipic.frameNStop = frameN  # exact frame index
                win.timeOnFlip(dotstipic, 'tStopRefresh')  # time at next scr refresh
                dotstipic.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_stiComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_sti"-------
    for thisComponent in guilt_stiComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # ------Prepare to start Routine "guilt_judge"-------
    continueRoutine = True
    routineTimer.add(5.000000)
    # update component parameters for each repeat
    pairing_sub_4.setSize(pairsize2)
    pairing_sub_4.setImage('Punish_Pair.png')
    sti_text1.setText(number)
    sti_text1.setHeight(bottom_textsize)
    # setup some python lists for storing info about the judge
    judge.clicked_name = []
    gotValidClick = False  # until a click is received
    RightButton.setText(dotrighttext)
    LeftButton.setText(dotlefttext)
    # keep track of which components have finished
    guilt_judgeComponents = [pairing_sub_4, sti_text1, judge, RightButton, LeftButton, rect1_2, rect2_2, text_16]
    for thisComponent in guilt_judgeComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_judgeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_judge"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = guilt_judgeClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_judgeClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_4* updates
        if pairing_sub_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_4.frameNStart = frameN  # exact frame index
            pairing_sub_4.tStart = t  # local t and not account for scr refresh
            pairing_sub_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_4, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_4.setAutoDraw(True)
        if pairing_sub_4.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_4.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_4.tStop = t  # not accounting for scr refresh
                pairing_sub_4.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_4, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_4.setAutoDraw(False)
        
        # *sti_text1* updates
        if sti_text1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            sti_text1.frameNStart = frameN  # exact frame index
            sti_text1.tStart = t  # local t and not account for scr refresh
            sti_text1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(sti_text1, 'tStartRefresh')  # time at next scr refresh
            sti_text1.setAutoDraw(True)
        if sti_text1.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > sti_text1.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                sti_text1.tStop = t  # not accounting for scr refresh
                sti_text1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(sti_text1, 'tStopRefresh')  # time at next scr refresh
                sti_text1.setAutoDraw(False)
        # *judge* updates
        if judge.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            judge.frameNStart = frameN  # exact frame index
            judge.tStart = t  # local t and not account for scr refresh
            judge.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(judge, 'tStartRefresh')  # time at next scr refresh
            judge.status = STARTED
            judge.mouseClock.reset()
            prevButtonState = judge.getPressed()  # if button is down already this ISN'T a new click
        if judge.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > judge.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                judge.tStop = t  # not accounting for scr refresh
                judge.frameNStop = frameN  # exact frame index
                win.timeOnFlip(judge, 'tStopRefresh')  # time at next scr refresh
                judge.status = FINISHED
        if judge.status == STARTED:  # only update if started and not finished!
            buttons = judge.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter([RightButton,LeftButton])
                        clickableList = [RightButton,LeftButton]
                    except:
                        clickableList = [[RightButton,LeftButton]]
                    for obj in clickableList:
                        if obj.contains(judge):
                            gotValidClick = True
                            judge.clicked_name.append(obj.name)
                    if gotValidClick:  # abort routine on response
                        continueRoutine = False
        if RightButton.contains(judge): 
            rectcolor2 = 'red'
        else:
            rectcolor2 = 'white'
            
        if LeftButton.contains(judge):
            rectcolor1 = 'red'
        else:
            rectcolor1 = 'white'
        
        # *RightButton* updates
        if RightButton.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            RightButton.frameNStart = frameN  # exact frame index
            RightButton.tStart = t  # local t and not account for scr refresh
            RightButton.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(RightButton, 'tStartRefresh')  # time at next scr refresh
            RightButton.setAutoDraw(True)
        if RightButton.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > RightButton.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                RightButton.tStop = t  # not accounting for scr refresh
                RightButton.frameNStop = frameN  # exact frame index
                win.timeOnFlip(RightButton, 'tStopRefresh')  # time at next scr refresh
                RightButton.setAutoDraw(False)
        
        # *LeftButton* updates
        if LeftButton.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            LeftButton.frameNStart = frameN  # exact frame index
            LeftButton.tStart = t  # local t and not account for scr refresh
            LeftButton.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(LeftButton, 'tStartRefresh')  # time at next scr refresh
            LeftButton.setAutoDraw(True)
        if LeftButton.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > LeftButton.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                LeftButton.tStop = t  # not accounting for scr refresh
                LeftButton.frameNStop = frameN  # exact frame index
                win.timeOnFlip(LeftButton, 'tStopRefresh')  # time at next scr refresh
                LeftButton.setAutoDraw(False)
        
        # *rect1_2* updates
        if rect1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            rect1_2.frameNStart = frameN  # exact frame index
            rect1_2.tStart = t  # local t and not account for scr refresh
            rect1_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(rect1_2, 'tStartRefresh')  # time at next scr refresh
            rect1_2.setAutoDraw(True)
        if rect1_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > rect1_2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                rect1_2.tStop = t  # not accounting for scr refresh
                rect1_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(rect1_2, 'tStopRefresh')  # time at next scr refresh
                rect1_2.setAutoDraw(False)
        if rect1_2.status == STARTED:  # only update if drawing
            rect1_2.setLineColor(rectcolor1, log=False)
        
        # *rect2_2* updates
        if rect2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            rect2_2.frameNStart = frameN  # exact frame index
            rect2_2.tStart = t  # local t and not account for scr refresh
            rect2_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(rect2_2, 'tStartRefresh')  # time at next scr refresh
            rect2_2.setAutoDraw(True)
        if rect2_2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > rect2_2.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                rect2_2.tStop = t  # not accounting for scr refresh
                rect2_2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(rect2_2, 'tStopRefresh')  # time at next scr refresh
                rect2_2.setAutoDraw(False)
        if rect2_2.status == STARTED:  # only update if drawing
            rect2_2.setLineColor(rectcolor2, log=False)
        
        # *text_16* updates
        if text_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_16.frameNStart = frameN  # exact frame index
            text_16.tStart = t  # local t and not account for scr refresh
            text_16.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_16, 'tStartRefresh')  # time at next scr refresh
            text_16.setAutoDraw(True)
        if text_16.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_16.tStartRefresh + 5-frameTolerance:
                # keep track of stop time/frame for later
                text_16.tStop = t  # not accounting for scr refresh
                text_16.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_16, 'tStopRefresh')  # time at next scr refresh
                text_16.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_judgeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_judge"-------
    for thisComponent in guilt_judgeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store data for trials_redo (TrialHandler)
    x, y = judge.getPos()
    buttons = judge.getPressed()
    if sum(buttons):
        # check if the mouse was inside our 'clickable' objects
        gotValidClick = False
        try:
            iter([RightButton,LeftButton])
            clickableList = [RightButton,LeftButton]
        except:
            clickableList = [[RightButton,LeftButton]]
        for obj in clickableList:
            if obj.contains(judge):
                gotValidClick = True
                judge.clicked_name.append(obj.name)
    trials_redo.addData('judge.x', x)
    trials_redo.addData('judge.y', y)
    trials_redo.addData('judge.leftButton', buttons[0])
    trials_redo.addData('judge.midButton', buttons[1])
    trials_redo.addData('judge.rightButton', buttons[2])
    if len(judge.clicked_name):
        trials_redo.addData('judge.clicked_name', judge.clicked_name[0])
    trials_redo.addData('judge.started', judge.tStart)
    trials_redo.addData('judge.stopped', judge.tStop)
    get_clicked_guilt = judge.clicked_name
    thisExp.addData('clicked_guilt', get_clicked_guilt)
    rep=1
    if gotValidClick==False:
        judge.clicked_name=['No response']
    
    if (type_trial== 4) & (judge.clicked_name[0] != answer):
        rep=0
    if (type_trial== 5) & (judge.clicked_name[0] != answer):
        rep=0
    
    trials_redo.addData('text_16.started', text_16.tStartRefresh)
    trials_redo.addData('text_16.stopped', text_16.tStopRefresh)
    
    # ------Prepare to start Routine "guilt_check_answer"-------
    continueRoutine = True
    # update component parameters for each repeat
    pairing_sub_5.setSize(pairsize2)
    if gotValidClick==False:
        continueRoutine=False
    wait_check_time = 0.8
    count = 0
    timejit = timejitter
    
    wait_check_text.setHeight(bottom_textsize)
    # keep track of which components have finished
    guilt_check_answerComponents = [pairing_sub_5, wait_check_text, Ellipsis_3]
    for thisComponent in guilt_check_answerComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_check_answerClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_check_answer"-------
    while continueRoutine:
        # get current time
        t = guilt_check_answerClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_check_answerClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *pairing_sub_5* updates
        if pairing_sub_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_5.frameNStart = frameN  # exact frame index
            pairing_sub_5.tStart = t  # local t and not account for scr refresh
            pairing_sub_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_5, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_5.setAutoDraw(True)
        if pairing_sub_5.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_5.tStartRefresh + wait_check_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_5.tStop = t  # not accounting for scr refresh
                pairing_sub_5.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_5, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_5.setAutoDraw(False)
        if t>timejit[0]:
            EllipsisText = ellis [count%3] 
            count = count+1
            timejit = timejit[1:]
        
        # *wait_check_text* updates
        if wait_check_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            wait_check_text.frameNStart = frameN  # exact frame index
            wait_check_text.tStart = t  # local t and not account for scr refresh
            wait_check_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(wait_check_text, 'tStartRefresh')  # time at next scr refresh
            wait_check_text.setAutoDraw(True)
        if wait_check_text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > wait_check_text.tStartRefresh + wait_check_time-frameTolerance:
                # keep track of stop time/frame for later
                wait_check_text.tStop = t  # not accounting for scr refresh
                wait_check_text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(wait_check_text, 'tStopRefresh')  # time at next scr refresh
                wait_check_text.setAutoDraw(False)
        
        # *Ellipsis_3* updates
        if Ellipsis_3.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Ellipsis_3.frameNStart = frameN  # exact frame index
            Ellipsis_3.tStart = t  # local t and not account for scr refresh
            Ellipsis_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ellipsis_3, 'tStartRefresh')  # time at next scr refresh
            Ellipsis_3.setAutoDraw(True)
        if Ellipsis_3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Ellipsis_3.tStartRefresh + wait_check_time-frameTolerance:
                # keep track of stop time/frame for later
                Ellipsis_3.tStop = t  # not accounting for scr refresh
                Ellipsis_3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Ellipsis_3, 'tStopRefresh')  # time at next scr refresh
                Ellipsis_3.setAutoDraw(False)
        if Ellipsis_3.status == STARTED:  # only update if drawing
            Ellipsis_3.setText(EllipsisText, log=False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_check_answerComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_check_answer"-------
    for thisComponent in guilt_check_answerComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "guilt_check_answer" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "warn_incomplete"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    if gotValidClick==True:
        continueRoutine=False
    else:
        incompleteTrials.append(chooserow[trialseq.thisTrialN])
        print("incompleteTrials: ", incompleteTrials)
        thisExp.addData('incompleteTrials', chooserow[trialseq.thisTrialN])
    # keep track of which components have finished
    warn_incompleteComponents = [text_14]
    for thisComponent in warn_incompleteComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    warn_incompleteClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "warn_incomplete"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = warn_incompleteClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=warn_incompleteClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_14* updates
        if text_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_14.frameNStart = frameN  # exact frame index
            text_14.tStart = t  # local t and not account for scr refresh
            text_14.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_14, 'tStartRefresh')  # time at next scr refresh
            text_14.setAutoDraw(True)
        if text_14.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_14.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                text_14.tStop = t  # not accounting for scr refresh
                text_14.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_14, 'tStopRefresh')  # time at next scr refresh
                text_14.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warn_incompleteComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "warn_incomplete"-------
    for thisComponent in warn_incompleteComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_redo.addData('text_14.started', text_14.tStartRefresh)
    trials_redo.addData('text_14.stopped', text_14.tStopRefresh)
    
    # ------Prepare to start Routine "warn_wrong"-------
    continueRoutine = True
    routineTimer.add(2.000000)
    # update component parameters for each repeat
    if (rep != 0):
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    
    # keep track of which components have finished
    warn_wrongComponents = [text_12]
    for thisComponent in warn_wrongComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    warn_wrongClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "warn_wrong"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = warn_wrongClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=warn_wrongClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text_12* updates
        if text_12.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_12.frameNStart = frameN  # exact frame index
            text_12.tStart = t  # local t and not account for scr refresh
            text_12.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_12, 'tStartRefresh')  # time at next scr refresh
            text_12.setAutoDraw(True)
        if text_12.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text_12.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                text_12.tStop = t  # not accounting for scr refresh
                text_12.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text_12, 'tStopRefresh')  # time at next scr refresh
                text_12.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in warn_wrongComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "warn_wrong"-------
    for thisComponent in warn_wrongComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_redo.addData('text_12.started', text_12.tStartRefresh)
    trials_redo.addData('text_12.stopped', text_12.tStopRefresh)
    
    # ------Prepare to start Routine "guilt_result"-------
    continueRoutine = True
    # update component parameters for each repeat
    if rep==0 :
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    
    count = 0
    timejit = timejitter
    if (type_trial == 0) | (type_trial == 4) | (type_trial == 5):
        phase1_result_time = 2
        FillerPunish = 1
        ValidPunish = 0
        PunishStart = 0
        PunishFinish = 0
    else:
        phase1_result_time = 4 # 13 # this is the duration for showing the results
        FillerPunish = 0
        ValidPunish = 1
        PunishStart = 1
        PunishFinish = 3 # 10 # this is the duration
        
    pairing_sub_6.setSize(pairsize2)
    result.setImage(stipic)
    punish_text2.setOpacity(ValidPunish)
    punish_text2.setText('对方需观看负性情绪图片')
    punish_text2.setHeight(bottom_textsize)
    FillerText.setOpacity(FillerPunish)
    PunishImg.setSize(punishpicsize)
    # keep track of which components have finished
    guilt_resultComponents = [pairing_sub_6, result, punish_text2, FillerText, PuPicText, PunishImg, Ellipsis]
    for thisComponent in guilt_resultComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    guilt_resultClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "guilt_result"-------
    while continueRoutine:
        # get current time
        t = guilt_resultClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=guilt_resultClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        #if t>(PunishStart+5):
        #    punish_pic_text = u'Image 2 is presenting'
        #else:
        #    punish_pic_text = u'Image 1 is presenting'
        
        #punish_pic_text = u'Aversive image is presenting'
        
        if t-PunishStart>timejit[0]:
            EllipsisText = ellis [count%3] 
            count = count+1
            timejit = timejit[1:]
        elif t<PunishStart:
            EllipsisText = ellis [0] 
        
        # *pairing_sub_6* updates
        if pairing_sub_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_6.frameNStart = frameN  # exact frame index
            pairing_sub_6.tStart = t  # local t and not account for scr refresh
            pairing_sub_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_6, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_6.setAutoDraw(True)
        if pairing_sub_6.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > pairing_sub_6.tStartRefresh + phase1_result_time-frameTolerance:
                # keep track of stop time/frame for later
                pairing_sub_6.tStop = t  # not accounting for scr refresh
                pairing_sub_6.frameNStop = frameN  # exact frame index
                win.timeOnFlip(pairing_sub_6, 'tStopRefresh')  # time at next scr refresh
                pairing_sub_6.setAutoDraw(False)
        
        # *result* updates
        if result.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result.frameNStart = frameN  # exact frame index
            result.tStart = t  # local t and not account for scr refresh
            result.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result, 'tStartRefresh')  # time at next scr refresh
            result.setAutoDraw(True)
        if result.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > result.tStartRefresh + phase1_result_time-frameTolerance:
                # keep track of stop time/frame for later
                result.tStop = t  # not accounting for scr refresh
                result.frameNStop = frameN  # exact frame index
                win.timeOnFlip(result, 'tStopRefresh')  # time at next scr refresh
                result.setAutoDraw(False)
        
        # *punish_text2* updates
        if punish_text2.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            punish_text2.frameNStart = frameN  # exact frame index
            punish_text2.tStart = t  # local t and not account for scr refresh
            punish_text2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(punish_text2, 'tStartRefresh')  # time at next scr refresh
            punish_text2.setAutoDraw(True)
        if punish_text2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > punish_text2.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                punish_text2.tStop = t  # not accounting for scr refresh
                punish_text2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(punish_text2, 'tStopRefresh')  # time at next scr refresh
                punish_text2.setAutoDraw(False)
        
        # *FillerText* updates
        if FillerText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            FillerText.frameNStart = frameN  # exact frame index
            FillerText.tStart = t  # local t and not account for scr refresh
            FillerText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(FillerText, 'tStartRefresh')  # time at next scr refresh
            FillerText.setAutoDraw(True)
        if FillerText.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > FillerText.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                FillerText.tStop = t  # not accounting for scr refresh
                FillerText.frameNStop = frameN  # exact frame index
                win.timeOnFlip(FillerText, 'tStopRefresh')  # time at next scr refresh
                FillerText.setAutoDraw(False)
        
        # *PuPicText* updates
        if PuPicText.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            PuPicText.frameNStart = frameN  # exact frame index
            PuPicText.tStart = t  # local t and not account for scr refresh
            PuPicText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PuPicText, 'tStartRefresh')  # time at next scr refresh
            PuPicText.setAutoDraw(True)
        if PuPicText.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PuPicText.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                PuPicText.tStop = t  # not accounting for scr refresh
                PuPicText.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PuPicText, 'tStopRefresh')  # time at next scr refresh
                PuPicText.setAutoDraw(False)
        
        # *PunishImg* updates
        if PunishImg.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            PunishImg.frameNStart = frameN  # exact frame index
            PunishImg.tStart = t  # local t and not account for scr refresh
            PunishImg.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PunishImg, 'tStartRefresh')  # time at next scr refresh
            PunishImg.setAutoDraw(True)
        if PunishImg.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PunishImg.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                PunishImg.tStop = t  # not accounting for scr refresh
                PunishImg.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PunishImg, 'tStopRefresh')  # time at next scr refresh
                PunishImg.setAutoDraw(False)
        
        # *Ellipsis* updates
        if Ellipsis.status == NOT_STARTED and tThisFlip >= PunishStart-frameTolerance:
            # keep track of start time/frame for later
            Ellipsis.frameNStart = frameN  # exact frame index
            Ellipsis.tStart = t  # local t and not account for scr refresh
            Ellipsis.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Ellipsis, 'tStartRefresh')  # time at next scr refresh
            Ellipsis.setAutoDraw(True)
        if Ellipsis.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Ellipsis.tStartRefresh + PunishFinish-frameTolerance:
                # keep track of stop time/frame for later
                Ellipsis.tStop = t  # not accounting for scr refresh
                Ellipsis.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Ellipsis, 'tStopRefresh')  # time at next scr refresh
                Ellipsis.setAutoDraw(False)
        if Ellipsis.status == STARTED:  # only update if drawing
            Ellipsis.setText(EllipsisText, log=False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in guilt_resultComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "guilt_result"-------
    for thisComponent in guilt_resultComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_redo.addData('PunishImg.started', PunishImg.tStartRefresh)
    trials_redo.addData('PunishImg.stopped', PunishImg.tStopRefresh)
    # the Routine "guilt_result" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_guilt"-------
    continueRoutine = True
    # update component parameters for each repeat
    slider_guilt.reset()
    key_guilt.keys = []
    key_guilt.rt = []
    _key_guilt_allKeys = []
    if (DV != 0) | (type_trial==0) |(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial.setImage(stipic)
    # keep track of which components have finished
    DV_guiltComponents = [slider_guilt, text_8, key_guilt, text_9, text_17, pairing_sub_cur_trial, result_cur_trial, time_reminder]
    for thisComponent in DV_guiltComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_guiltClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_guilt"-------
    while continueRoutine:
        # get current time
        t = DV_guiltClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_guiltClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *slider_guilt* updates
        if slider_guilt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_guilt.frameNStart = frameN  # exact frame index
            slider_guilt.tStart = t  # local t and not account for scr refresh
            slider_guilt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_guilt, 'tStartRefresh')  # time at next scr refresh
            slider_guilt.setAutoDraw(True)
        
        # *text_8* updates
        if text_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_8.frameNStart = frameN  # exact frame index
            text_8.tStart = t  # local t and not account for scr refresh
            text_8.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_8, 'tStartRefresh')  # time at next scr refresh
            text_8.setAutoDraw(True)
        
        # *key_guilt* updates
        waitOnFlip = False
        if key_guilt.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_guilt.frameNStart = frameN  # exact frame index
            key_guilt.tStart = t  # local t and not account for scr refresh
            key_guilt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_guilt, 'tStartRefresh')  # time at next scr refresh
            key_guilt.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_guilt.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_guilt.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_guilt.status == STARTED and not waitOnFlip:
            theseKeys = key_guilt.getKeys(keyList=['space'], waitRelease=False)
            _key_guilt_allKeys.extend(theseKeys)
            if len(_key_guilt_allKeys):
                key_guilt.keys = _key_guilt_allKeys[-1].name  # just the last key pressed
                key_guilt.rt = _key_guilt_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        logic1=(slider_guilt.getRating()!=None)
        if logic1:
           
            temp=1
        
        
        # *text_9* updates
        if text_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_9.frameNStart = frameN  # exact frame index
            text_9.tStart = t  # local t and not account for scr refresh
            text_9.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
            text_9.setAutoDraw(True)
        
        # *text_17* updates
        if text_17.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            text_17.frameNStart = frameN  # exact frame index
            text_17.tStart = t  # local t and not account for scr refresh
            text_17.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_17, 'tStartRefresh')  # time at next scr refresh
            text_17.setAutoDraw(True)
        
        # *pairing_sub_cur_trial* updates
        if pairing_sub_cur_trial.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial.setAutoDraw(True)
        
        # *result_cur_trial* updates
        if result_cur_trial.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial.frameNStart = frameN  # exact frame index
            result_cur_trial.tStart = t  # local t and not account for scr refresh
            result_cur_trial.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial.setAutoDraw(True)
        
        # *time_reminder* updates
        if time_reminder.status == NOT_STARTED and tThisFlip >= 10-frameTolerance:
            # keep track of start time/frame for later
            time_reminder.frameNStart = frameN  # exact frame index
            time_reminder.tStart = t  # local t and not account for scr refresh
            time_reminder.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder, 'tStartRefresh')  # time at next scr refresh
            time_reminder.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_guiltComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_guilt"-------
    for thisComponent in DV_guiltComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_redo.addData('slider_guilt.response', slider_guilt.getRating())
    trials_redo.addData('slider_guilt.rt', slider_guilt.getRT())
    trials_redo.addData('slider_guilt.started', slider_guilt.tStartRefresh)
    trials_redo.addData('slider_guilt.stopped', slider_guilt.tStopRefresh)
    trials_redo.addData('text_8.started', text_8.tStartRefresh)
    trials_redo.addData('text_8.stopped', text_8.tStopRefresh)
    # check responses
    if key_guilt.keys in ['', [], None]:  # No response was made
        key_guilt.keys = None
    trials_redo.addData('key_guilt.keys',key_guilt.keys)
    if key_guilt.keys != None:  # we had a response
        trials_redo.addData('key_guilt.rt', key_guilt.rt)
    trials_redo.addData('key_guilt.started', key_guilt.tStartRefresh)
    trials_redo.addData('key_guilt.stopped', key_guilt.tStopRefresh)
    trials_redo.addData('text_9.started', text_9.tStartRefresh)
    trials_redo.addData('text_9.stopped', text_9.tStopRefresh)
    trials_redo.addData('text_17.started', text_17.tStartRefresh)
    trials_redo.addData('text_17.stopped', text_17.tStopRefresh)
    trials_redo.addData('pairing_sub_cur_trial.started', pairing_sub_cur_trial.tStartRefresh)
    trials_redo.addData('pairing_sub_cur_trial.stopped', pairing_sub_cur_trial.tStopRefresh)
    trials_redo.addData('result_cur_trial.started', result_cur_trial.tStartRefresh)
    trials_redo.addData('result_cur_trial.stopped', result_cur_trial.tStopRefresh)
    trials_redo.addData('time_reminder.started', time_reminder.tStartRefresh)
    trials_redo.addData('time_reminder.stopped', time_reminder.tStopRefresh)
    # the Routine "DV_guilt" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_sharing"-------
    continueRoutine = True
    # update component parameters for each repeat
    share_slider.reset()
    key_share.keys = []
    key_share.rt = []
    _key_share_allKeys = []
    if (DV != 1) | (type_trial==0)|(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial_2.setImage(stipic)
    # keep track of which components have finished
    DV_sharingComponents = [share_slider, share_text, key_share, text_29, pairing_sub_cur_trial_2, result_cur_trial_2, time_reminder2]
    for thisComponent in DV_sharingComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_sharingClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_sharing"-------
    while continueRoutine:
        # get current time
        t = DV_sharingClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_sharingClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *share_slider* updates
        if share_slider.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            share_slider.frameNStart = frameN  # exact frame index
            share_slider.tStart = t  # local t and not account for scr refresh
            share_slider.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(share_slider, 'tStartRefresh')  # time at next scr refresh
            share_slider.setAutoDraw(True)
        
        # *share_text* updates
        if share_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            share_text.frameNStart = frameN  # exact frame index
            share_text.tStart = t  # local t and not account for scr refresh
            share_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(share_text, 'tStartRefresh')  # time at next scr refresh
            share_text.setAutoDraw(True)
        
        # *key_share* updates
        waitOnFlip = False
        if key_share.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_share.frameNStart = frameN  # exact frame index
            key_share.tStart = t  # local t and not account for scr refresh
            key_share.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_share, 'tStartRefresh')  # time at next scr refresh
            key_share.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_share.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_share.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_share.status == STARTED and not waitOnFlip:
            theseKeys = key_share.getKeys(keyList=['space'], waitRelease=False)
            _key_share_allKeys.extend(theseKeys)
            if len(_key_share_allKeys):
                key_share.keys = _key_share_allKeys[-1].name  # just the last key pressed
                key_share.rt = _key_share_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        if share_slider.getRating()!=None:
           
            temp=1
        
        # *text_29* updates
        if text_29.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            text_29.frameNStart = frameN  # exact frame index
            text_29.tStart = t  # local t and not account for scr refresh
            text_29.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_29, 'tStartRefresh')  # time at next scr refresh
            text_29.setAutoDraw(True)
        
        # *pairing_sub_cur_trial_2* updates
        if pairing_sub_cur_trial_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial_2.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial_2.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial_2, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial_2.setAutoDraw(True)
        
        # *result_cur_trial_2* updates
        if result_cur_trial_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial_2.frameNStart = frameN  # exact frame index
            result_cur_trial_2.tStart = t  # local t and not account for scr refresh
            result_cur_trial_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial_2, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial_2.setAutoDraw(True)
        
        # *time_reminder2* updates
        if time_reminder2.status == NOT_STARTED and tThisFlip >= 10-frameTolerance:
            # keep track of start time/frame for later
            time_reminder2.frameNStart = frameN  # exact frame index
            time_reminder2.tStart = t  # local t and not account for scr refresh
            time_reminder2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder2, 'tStartRefresh')  # time at next scr refresh
            time_reminder2.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_sharingComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_sharing"-------
    for thisComponent in DV_sharingComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_redo.addData('share_slider.response', share_slider.getRating())
    trials_redo.addData('share_slider.rt', share_slider.getRT())
    trials_redo.addData('share_slider.started', share_slider.tStartRefresh)
    trials_redo.addData('share_slider.stopped', share_slider.tStopRefresh)
    trials_redo.addData('share_text.started', share_text.tStartRefresh)
    trials_redo.addData('share_text.stopped', share_text.tStopRefresh)
    # check responses
    if key_share.keys in ['', [], None]:  # No response was made
        key_share.keys = None
    trials_redo.addData('key_share.keys',key_share.keys)
    if key_share.keys != None:  # we had a response
        trials_redo.addData('key_share.rt', key_share.rt)
    trials_redo.addData('key_share.started', key_share.tStartRefresh)
    trials_redo.addData('key_share.stopped', key_share.tStopRefresh)
    trials_redo.addData('text_29.started', text_29.tStartRefresh)
    trials_redo.addData('text_29.stopped', text_29.tStopRefresh)
    trials_redo.addData('pairing_sub_cur_trial_2.started', pairing_sub_cur_trial_2.tStartRefresh)
    trials_redo.addData('pairing_sub_cur_trial_2.stopped', pairing_sub_cur_trial_2.tStopRefresh)
    trials_redo.addData('result_cur_trial_2.started', result_cur_trial_2.tStartRefresh)
    trials_redo.addData('result_cur_trial_2.stopped', result_cur_trial_2.tStopRefresh)
    trials_redo.addData('time_reminder2.started', time_reminder2.tStartRefresh)
    trials_redo.addData('time_reminder2.stopped', time_reminder2.tStopRefresh)
    # append compensation choice for this trial
    share_choice.append(share_slider.getRating())
    # the Routine "DV_sharing" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_approach_avoidance"-------
    continueRoutine = True
    # update component parameters for each repeat
    slider_apology.reset()
    key_apology.keys = []
    key_apology.rt = []
    _key_apology_allKeys = []
    slider_hide.reset()
    if (DV != 2) | (type_trial==0)|(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial_3.setImage(stipic)
    # keep track of which components have finished
    DV_approach_avoidanceComponents = [slider_apology, text_apology, key_apology, slider_hide, text_hide, text_31, pairing_sub_cur_trial_3, result_cur_trial_3, time_reminder3]
    for thisComponent in DV_approach_avoidanceComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_approach_avoidanceClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_approach_avoidance"-------
    while continueRoutine:
        # get current time
        t = DV_approach_avoidanceClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_approach_avoidanceClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *slider_apology* updates
        if slider_apology.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_apology.frameNStart = frameN  # exact frame index
            slider_apology.tStart = t  # local t and not account for scr refresh
            slider_apology.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_apology, 'tStartRefresh')  # time at next scr refresh
            slider_apology.setAutoDraw(True)
        
        # *text_apology* updates
        if text_apology.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_apology.frameNStart = frameN  # exact frame index
            text_apology.tStart = t  # local t and not account for scr refresh
            text_apology.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_apology, 'tStartRefresh')  # time at next scr refresh
            text_apology.setAutoDraw(True)
        
        # *key_apology* updates
        waitOnFlip = False
        if key_apology.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_apology.frameNStart = frameN  # exact frame index
            key_apology.tStart = t  # local t and not account for scr refresh
            key_apology.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_apology, 'tStartRefresh')  # time at next scr refresh
            key_apology.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_apology.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_apology.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_apology.status == STARTED and not waitOnFlip:
            theseKeys = key_apology.getKeys(keyList=['space'], waitRelease=False)
            _key_apology_allKeys.extend(theseKeys)
            if len(_key_apology_allKeys):
                key_apology.keys = _key_apology_allKeys[-1].name  # just the last key pressed
                key_apology.rt = _key_apology_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *slider_hide* updates
        if slider_hide.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_hide.frameNStart = frameN  # exact frame index
            slider_hide.tStart = t  # local t and not account for scr refresh
            slider_hide.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_hide, 'tStartRefresh')  # time at next scr refresh
            slider_hide.setAutoDraw(True)
        
        # *text_hide* updates
        if text_hide.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_hide.frameNStart = frameN  # exact frame index
            text_hide.tStart = t  # local t and not account for scr refresh
            text_hide.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_hide, 'tStartRefresh')  # time at next scr refresh
            text_hide.setAutoDraw(True)
        logic3 = (slider_apology.getRating() is not None) and (slider_hide.getRating() is not None)
        
        if logic3:
            temp = 1
        
        
        
        # *text_31* updates
        if text_31.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            text_31.frameNStart = frameN  # exact frame index
            text_31.tStart = t  # local t and not account for scr refresh
            text_31.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_31, 'tStartRefresh')  # time at next scr refresh
            text_31.setAutoDraw(True)
        
        # *pairing_sub_cur_trial_3* updates
        if pairing_sub_cur_trial_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial_3.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial_3.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial_3, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial_3.setAutoDraw(True)
        
        # *result_cur_trial_3* updates
        if result_cur_trial_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial_3.frameNStart = frameN  # exact frame index
            result_cur_trial_3.tStart = t  # local t and not account for scr refresh
            result_cur_trial_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial_3, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial_3.setAutoDraw(True)
        
        # *time_reminder3* updates
        if time_reminder3.status == NOT_STARTED and tThisFlip >= 20-frameTolerance:
            # keep track of start time/frame for later
            time_reminder3.frameNStart = frameN  # exact frame index
            time_reminder3.tStart = t  # local t and not account for scr refresh
            time_reminder3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder3, 'tStartRefresh')  # time at next scr refresh
            time_reminder3.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_approach_avoidanceComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_approach_avoidance"-------
    for thisComponent in DV_approach_avoidanceComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_redo.addData('slider_apology.response', slider_apology.getRating())
    trials_redo.addData('slider_apology.rt', slider_apology.getRT())
    trials_redo.addData('slider_apology.started', slider_apology.tStartRefresh)
    trials_redo.addData('slider_apology.stopped', slider_apology.tStopRefresh)
    trials_redo.addData('text_apology.started', text_apology.tStartRefresh)
    trials_redo.addData('text_apology.stopped', text_apology.tStopRefresh)
    # check responses
    if key_apology.keys in ['', [], None]:  # No response was made
        key_apology.keys = None
    trials_redo.addData('key_apology.keys',key_apology.keys)
    if key_apology.keys != None:  # we had a response
        trials_redo.addData('key_apology.rt', key_apology.rt)
    trials_redo.addData('key_apology.started', key_apology.tStartRefresh)
    trials_redo.addData('key_apology.stopped', key_apology.tStopRefresh)
    trials_redo.addData('slider_hide.response', slider_hide.getRating())
    trials_redo.addData('slider_hide.rt', slider_hide.getRT())
    trials_redo.addData('slider_hide.started', slider_hide.tStartRefresh)
    trials_redo.addData('slider_hide.stopped', slider_hide.tStopRefresh)
    trials_redo.addData('text_hide.started', text_hide.tStartRefresh)
    trials_redo.addData('text_hide.stopped', text_hide.tStopRefresh)
    trials_redo.addData('text_31.started', text_31.tStartRefresh)
    trials_redo.addData('text_31.stopped', text_31.tStopRefresh)
    trials_redo.addData('pairing_sub_cur_trial_3.started', pairing_sub_cur_trial_3.tStartRefresh)
    trials_redo.addData('pairing_sub_cur_trial_3.stopped', pairing_sub_cur_trial_3.tStopRefresh)
    trials_redo.addData('result_cur_trial_3.started', result_cur_trial_3.tStartRefresh)
    trials_redo.addData('result_cur_trial_3.stopped', result_cur_trial_3.tStopRefresh)
    trials_redo.addData('time_reminder3.started', time_reminder3.tStartRefresh)
    trials_redo.addData('time_reminder3.stopped', time_reminder3.tStopRefresh)
    # the Routine "DV_approach_avoidance" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "DV_forgiveness"-------
    continueRoutine = True
    # update component parameters for each repeat
    slider_forgiveness.reset()
    key_forgiveness.keys = []
    key_forgiveness.rt = []
    _key_forgiveness_allKeys = []
    slider_mad.reset()
    if (DV != 3) | (type_trial==0)|(type_trial==4) |(type_trial==5) :
        continueRoutine=False
    
    if gotValidClick==False:
        continueRoutine=False
    temp=0
    result_cur_trial_4.setImage(stipic)
    # keep track of which components have finished
    DV_forgivenessComponents = [slider_forgiveness, text_forgiveness, key_forgiveness, slider_mad, text_mad, text_19, pairing_sub_cur_trial_4, result_cur_trial_4, time_reminder4]
    for thisComponent in DV_forgivenessComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    DV_forgivenessClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "DV_forgiveness"-------
    while continueRoutine:
        # get current time
        t = DV_forgivenessClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=DV_forgivenessClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *slider_forgiveness* updates
        if slider_forgiveness.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_forgiveness.frameNStart = frameN  # exact frame index
            slider_forgiveness.tStart = t  # local t and not account for scr refresh
            slider_forgiveness.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_forgiveness, 'tStartRefresh')  # time at next scr refresh
            slider_forgiveness.setAutoDraw(True)
        
        # *text_forgiveness* updates
        if text_forgiveness.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_forgiveness.frameNStart = frameN  # exact frame index
            text_forgiveness.tStart = t  # local t and not account for scr refresh
            text_forgiveness.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_forgiveness, 'tStartRefresh')  # time at next scr refresh
            text_forgiveness.setAutoDraw(True)
        
        # *key_forgiveness* updates
        waitOnFlip = False
        if key_forgiveness.status == NOT_STARTED and temp==1:
            # keep track of start time/frame for later
            key_forgiveness.frameNStart = frameN  # exact frame index
            key_forgiveness.tStart = t  # local t and not account for scr refresh
            key_forgiveness.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_forgiveness, 'tStartRefresh')  # time at next scr refresh
            key_forgiveness.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_forgiveness.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_forgiveness.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_forgiveness.status == STARTED and not waitOnFlip:
            theseKeys = key_forgiveness.getKeys(keyList=['space'], waitRelease=False)
            _key_forgiveness_allKeys.extend(theseKeys)
            if len(_key_forgiveness_allKeys):
                key_forgiveness.keys = _key_forgiveness_allKeys[-1].name  # just the last key pressed
                key_forgiveness.rt = _key_forgiveness_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *slider_mad* updates
        if slider_mad.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            slider_mad.frameNStart = frameN  # exact frame index
            slider_mad.tStart = t  # local t and not account for scr refresh
            slider_mad.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(slider_mad, 'tStartRefresh')  # time at next scr refresh
            slider_mad.setAutoDraw(True)
        
        # *text_mad* updates
        if text_mad.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_mad.frameNStart = frameN  # exact frame index
            text_mad.tStart = t  # local t and not account for scr refresh
            text_mad.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_mad, 'tStartRefresh')  # time at next scr refresh
            text_mad.setAutoDraw(True)
        logic4 = (slider_forgiveness.getRating() is not None) and (slider_mad.getRating() is not None)
        
        if logic4:
            temp = 1
        
        # *text_19* updates
        if text_19.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_19.frameNStart = frameN  # exact frame index
            text_19.tStart = t  # local t and not account for scr refresh
            text_19.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_19, 'tStartRefresh')  # time at next scr refresh
            text_19.setAutoDraw(True)
        
        # *pairing_sub_cur_trial_4* updates
        if pairing_sub_cur_trial_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            pairing_sub_cur_trial_4.frameNStart = frameN  # exact frame index
            pairing_sub_cur_trial_4.tStart = t  # local t and not account for scr refresh
            pairing_sub_cur_trial_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(pairing_sub_cur_trial_4, 'tStartRefresh')  # time at next scr refresh
            pairing_sub_cur_trial_4.setAutoDraw(True)
        
        # *result_cur_trial_4* updates
        if result_cur_trial_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            result_cur_trial_4.frameNStart = frameN  # exact frame index
            result_cur_trial_4.tStart = t  # local t and not account for scr refresh
            result_cur_trial_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(result_cur_trial_4, 'tStartRefresh')  # time at next scr refresh
            result_cur_trial_4.setAutoDraw(True)
        
        # *time_reminder4* updates
        if time_reminder4.status == NOT_STARTED and tThisFlip >= 20-frameTolerance:
            # keep track of start time/frame for later
            time_reminder4.frameNStart = frameN  # exact frame index
            time_reminder4.tStart = t  # local t and not account for scr refresh
            time_reminder4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(time_reminder4, 'tStartRefresh')  # time at next scr refresh
            time_reminder4.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in DV_forgivenessComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "DV_forgiveness"-------
    for thisComponent in DV_forgivenessComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials_redo.addData('slider_forgiveness.response', slider_forgiveness.getRating())
    trials_redo.addData('slider_forgiveness.rt', slider_forgiveness.getRT())
    trials_redo.addData('slider_forgiveness.started', slider_forgiveness.tStartRefresh)
    trials_redo.addData('slider_forgiveness.stopped', slider_forgiveness.tStopRefresh)
    trials_redo.addData('text_forgiveness.started', text_forgiveness.tStartRefresh)
    trials_redo.addData('text_forgiveness.stopped', text_forgiveness.tStopRefresh)
    # check responses
    if key_forgiveness.keys in ['', [], None]:  # No response was made
        key_forgiveness.keys = None
    trials_redo.addData('key_forgiveness.keys',key_forgiveness.keys)
    if key_forgiveness.keys != None:  # we had a response
        trials_redo.addData('key_forgiveness.rt', key_forgiveness.rt)
    trials_redo.addData('key_forgiveness.started', key_forgiveness.tStartRefresh)
    trials_redo.addData('key_forgiveness.stopped', key_forgiveness.tStopRefresh)
    trials_redo.addData('slider_mad.response', slider_mad.getRating())
    trials_redo.addData('slider_mad.rt', slider_mad.getRT())
    trials_redo.addData('slider_mad.started', slider_mad.tStartRefresh)
    trials_redo.addData('slider_mad.stopped', slider_mad.tStopRefresh)
    trials_redo.addData('text_mad.started', text_mad.tStartRefresh)
    trials_redo.addData('text_mad.stopped', text_mad.tStopRefresh)
    trials_redo.addData('text_19.started', text_19.tStartRefresh)
    trials_redo.addData('text_19.stopped', text_19.tStopRefresh)
    trials_redo.addData('pairing_sub_cur_trial_4.started', pairing_sub_cur_trial_4.tStartRefresh)
    trials_redo.addData('pairing_sub_cur_trial_4.stopped', pairing_sub_cur_trial_4.tStopRefresh)
    trials_redo.addData('result_cur_trial_4.started', result_cur_trial_4.tStartRefresh)
    trials_redo.addData('result_cur_trial_4.stopped', result_cur_trial_4.tStopRefresh)
    trials_redo.addData('time_reminder4.started', time_reminder4.tStartRefresh)
    trials_redo.addData('time_reminder4.stopped', time_reminder4.tStopRefresh)
    # the Routine "DV_forgiveness" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trials_redo'


# ------Prepare to start Routine "check_redo"-------
continueRoutine = True
# update component parameters for each repeat
redo_flag = 1
# keep track of which components have finished
check_redoComponents = []
for thisComponent in check_redoComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
check_redoClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "check_redo"-------
while continueRoutine:
    # get current time
    t = check_redoClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=check_redoClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in check_redoComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "check_redo"-------
for thisComponent in check_redoComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "check_redo" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "ave_img_end"-------
continueRoutine = True
# update component parameters for each repeat
print(f"Before presenting aversive images, show share choice: \n {share_choice}")

if len(incompleteTrials) == 0 or redo_flag == 1:
    # all trials are completed, escape
    continueRoutine = True
    #Remove None values from the list
    cleaned_share_choice = [x for x in share_choice if x is not None]
    share_choice_mean = sum(cleaned_share_choice)/len(cleaned_share_choice)
    print(f"share choice mean is:{share_choice_mean}")
else:
    continueRoutine = False
    share_choice_mean = 0 # skip this trial
# keep track of which components have finished
ave_img_endComponents = [text_4, ave_img2, text_5]
for thisComponent in ave_img_endComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
ave_img_endClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "ave_img_end"-------
while continueRoutine:
    # get current time
    t = ave_img_endClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=ave_img_endClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_4* updates
    if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_4.frameNStart = frameN  # exact frame index
        text_4.tStart = t  # local t and not account for scr refresh
        text_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
        text_4.setAutoDraw(True)
    if text_4.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_4.tStartRefresh + 4-frameTolerance:
            # keep track of stop time/frame for later
            text_4.tStop = t  # not accounting for scr refresh
            text_4.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_4, 'tStopRefresh')  # time at next scr refresh
            text_4.setAutoDraw(False)
    
    # *ave_img2* updates
    if ave_img2.status == NOT_STARTED and tThisFlip >= 4-frameTolerance:
        # keep track of start time/frame for later
        ave_img2.frameNStart = frameN  # exact frame index
        ave_img2.tStart = t  # local t and not account for scr refresh
        ave_img2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(ave_img2, 'tStartRefresh')  # time at next scr refresh
        ave_img2.setAutoDraw(True)
    if ave_img2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > ave_img2.tStartRefresh + share_choice_mean-frameTolerance:
            # keep track of stop time/frame for later
            ave_img2.tStop = t  # not accounting for scr refresh
            ave_img2.frameNStop = frameN  # exact frame index
            win.timeOnFlip(ave_img2, 'tStopRefresh')  # time at next scr refresh
            ave_img2.setAutoDraw(False)
    
    # *text_5* updates
    if text_5.status == NOT_STARTED and tThisFlip >= 4-frameTolerance:
        # keep track of start time/frame for later
        text_5.frameNStart = frameN  # exact frame index
        text_5.tStart = t  # local t and not account for scr refresh
        text_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
        text_5.setAutoDraw(True)
    if text_5.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_5.tStartRefresh + share_choice_mean-frameTolerance:
            # keep track of stop time/frame for later
            text_5.tStop = t  # not accounting for scr refresh
            text_5.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_5, 'tStopRefresh')  # time at next scr refresh
            text_5.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ave_img_endComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "ave_img_end"-------
for thisComponent in ave_img_endComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_4.started', text_4.tStartRefresh)
thisExp.addData('text_4.stopped', text_4.tStopRefresh)
thisExp.addData('ave_img2.started', ave_img2.tStartRefresh)
thisExp.addData('ave_img2.stopped', ave_img2.tStopRefresh)
thisExp.addData('text_5.started', text_5.tStartRefresh)
thisExp.addData('text_5.stopped', text_5.tStopRefresh)
# the Routine "ave_img_end" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "holistic_impression"-------
continueRoutine = True
# update component parameters for each repeat
print(f"all complete? {incompleteTrials}")

if len(incompleteTrials) == 0 or redo_flag == 1:
    # all trials are completed, escape
    continueRoutine = True
else:
    continueRoutine = False # skip this trial
slider_friendly.reset()
slider_trustworthy.reset()
slider_competence.reset()
slider_critical.reset()
key_resp.keys = []
key_resp.rt = []
_key_resp_allKeys = []
# keep track of which components have finished
holistic_impressionComponents = [text_20, text_friendly, slider_friendly, text_trustworthy, slider_trustworthy, text_21, slider_competence, text_22, slider_critical, text_space, key_resp]
for thisComponent in holistic_impressionComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
holistic_impressionClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "holistic_impression"-------
while continueRoutine:
    # get current time
    t = holistic_impressionClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=holistic_impressionClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    logic5=(slider_friendly.getRating()!=None) and \
    (slider_trustworthy.getRating()!=None) and \
    (slider_competence.getRating()!=None) and \
    (slider_critical.getRating()!=None)
    
    if logic5:
       
        state_complete = 1
    
    
    # *text_20* updates
    if text_20.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_20.frameNStart = frameN  # exact frame index
        text_20.tStart = t  # local t and not account for scr refresh
        text_20.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_20, 'tStartRefresh')  # time at next scr refresh
        text_20.setAutoDraw(True)
    
    # *text_friendly* updates
    if text_friendly.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_friendly.frameNStart = frameN  # exact frame index
        text_friendly.tStart = t  # local t and not account for scr refresh
        text_friendly.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_friendly, 'tStartRefresh')  # time at next scr refresh
        text_friendly.setAutoDraw(True)
    
    # *slider_friendly* updates
    if slider_friendly.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_friendly.frameNStart = frameN  # exact frame index
        slider_friendly.tStart = t  # local t and not account for scr refresh
        slider_friendly.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_friendly, 'tStartRefresh')  # time at next scr refresh
        slider_friendly.setAutoDraw(True)
    
    # *text_trustworthy* updates
    if text_trustworthy.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_trustworthy.frameNStart = frameN  # exact frame index
        text_trustworthy.tStart = t  # local t and not account for scr refresh
        text_trustworthy.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_trustworthy, 'tStartRefresh')  # time at next scr refresh
        text_trustworthy.setAutoDraw(True)
    
    # *slider_trustworthy* updates
    if slider_trustworthy.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_trustworthy.frameNStart = frameN  # exact frame index
        slider_trustworthy.tStart = t  # local t and not account for scr refresh
        slider_trustworthy.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_trustworthy, 'tStartRefresh')  # time at next scr refresh
        slider_trustworthy.setAutoDraw(True)
    
    # *text_21* updates
    if text_21.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_21.frameNStart = frameN  # exact frame index
        text_21.tStart = t  # local t and not account for scr refresh
        text_21.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_21, 'tStartRefresh')  # time at next scr refresh
        text_21.setAutoDraw(True)
    
    # *slider_competence* updates
    if slider_competence.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_competence.frameNStart = frameN  # exact frame index
        slider_competence.tStart = t  # local t and not account for scr refresh
        slider_competence.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_competence, 'tStartRefresh')  # time at next scr refresh
        slider_competence.setAutoDraw(True)
    
    # *text_22* updates
    if text_22.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_22.frameNStart = frameN  # exact frame index
        text_22.tStart = t  # local t and not account for scr refresh
        text_22.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_22, 'tStartRefresh')  # time at next scr refresh
        text_22.setAutoDraw(True)
    
    # *slider_critical* updates
    if slider_critical.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        slider_critical.frameNStart = frameN  # exact frame index
        slider_critical.tStart = t  # local t and not account for scr refresh
        slider_critical.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(slider_critical, 'tStartRefresh')  # time at next scr refresh
        slider_critical.setAutoDraw(True)
    
    # *text_space* updates
    if text_space.status == NOT_STARTED and state_complete==1:
        # keep track of start time/frame for later
        text_space.frameNStart = frameN  # exact frame index
        text_space.tStart = t  # local t and not account for scr refresh
        text_space.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_space, 'tStartRefresh')  # time at next scr refresh
        text_space.setAutoDraw(True)
    
    # *key_resp* updates
    waitOnFlip = False
    if key_resp.status == NOT_STARTED and state_complete==1:
        # keep track of start time/frame for later
        key_resp.frameNStart = frameN  # exact frame index
        key_resp.tStart = t  # local t and not account for scr refresh
        key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp.status == STARTED and not waitOnFlip:
        theseKeys = key_resp.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_allKeys.extend(theseKeys)
        if len(_key_resp_allKeys):
            key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
            key_resp.rt = _key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in holistic_impressionComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "holistic_impression"-------
for thisComponent in holistic_impressionComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_20.started', text_20.tStartRefresh)
thisExp.addData('text_20.stopped', text_20.tStopRefresh)
thisExp.addData('text_friendly.started', text_friendly.tStartRefresh)
thisExp.addData('text_friendly.stopped', text_friendly.tStopRefresh)
thisExp.addData('slider_friendly.response', slider_friendly.getRating())
thisExp.addData('slider_friendly.rt', slider_friendly.getRT())
thisExp.addData('slider_friendly.started', slider_friendly.tStartRefresh)
thisExp.addData('slider_friendly.stopped', slider_friendly.tStopRefresh)
thisExp.addData('text_trustworthy.started', text_trustworthy.tStartRefresh)
thisExp.addData('text_trustworthy.stopped', text_trustworthy.tStopRefresh)
thisExp.addData('slider_trustworthy.response', slider_trustworthy.getRating())
thisExp.addData('slider_trustworthy.rt', slider_trustworthy.getRT())
thisExp.addData('slider_trustworthy.started', slider_trustworthy.tStartRefresh)
thisExp.addData('slider_trustworthy.stopped', slider_trustworthy.tStopRefresh)
thisExp.addData('text_21.started', text_21.tStartRefresh)
thisExp.addData('text_21.stopped', text_21.tStopRefresh)
thisExp.addData('slider_competence.response', slider_competence.getRating())
thisExp.addData('slider_competence.rt', slider_competence.getRT())
thisExp.addData('slider_competence.started', slider_competence.tStartRefresh)
thisExp.addData('slider_competence.stopped', slider_competence.tStopRefresh)
thisExp.addData('text_22.started', text_22.tStartRefresh)
thisExp.addData('text_22.stopped', text_22.tStopRefresh)
thisExp.addData('slider_critical.response', slider_critical.getRating())
thisExp.addData('slider_critical.rt', slider_critical.getRT())
thisExp.addData('slider_critical.started', slider_critical.tStartRefresh)
thisExp.addData('slider_critical.stopped', slider_critical.tStopRefresh)
thisExp.addData('text_space.started', text_space.tStartRefresh)
thisExp.addData('text_space.stopped', text_space.tStopRefresh)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
thisExp.addData('key_resp.keys',key_resp.keys)
if key_resp.keys != None:  # we had a response
    thisExp.addData('key_resp.rt', key_resp.rt)
thisExp.addData('key_resp.started', key_resp.tStartRefresh)
thisExp.addData('key_resp.stopped', key_resp.tStopRefresh)
thisExp.nextEntry()
# the Routine "holistic_impression" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "end"-------
continueRoutine = True
routineTimer.add(8.000000)
# update component parameters for each repeat
# keep track of which components have finished
endComponents = [text_13]
for thisComponent in endComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
endClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "end"-------
while continueRoutine and routineTimer.getTime() > 0:
    # get current time
    t = endClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=endClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_13* updates
    if text_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_13.frameNStart = frameN  # exact frame index
        text_13.tStart = t  # local t and not account for scr refresh
        text_13.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_13, 'tStartRefresh')  # time at next scr refresh
        text_13.setAutoDraw(True)
    if text_13.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > text_13.tStartRefresh + 8-frameTolerance:
            # keep track of stop time/frame for later
            text_13.tStop = t  # not accounting for scr refresh
            text_13.frameNStop = frameN  # exact frame index
            win.timeOnFlip(text_13, 'tStopRefresh')  # time at next scr refresh
            text_13.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in endComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "end"-------
for thisComponent in endComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_13.started', text_13.tStartRefresh)
thisExp.addData('text_13.stopped', text_13.tStopRefresh)

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
